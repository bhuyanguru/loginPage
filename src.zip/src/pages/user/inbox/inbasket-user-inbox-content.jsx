import _ from "lodash";
import React from "react";
import {Link, Redirect} from 'react-router-dom';
import {Col, Row} from "reactstrap";
import {InbasketTemplateContentController} from "../../../api/inbasket";
import InbasketProjectUserMapperContentReadController
    from "../../../api/inbasket/inbasket-projectusermappercontentread-controller";
import {
    InbasketMailLegend,
    InbasketUserInboxTimerView,
    InbasketUserMaterialView,
    InbasketUserReplyView
} from "../../../views/partials";

import {translate} from "react-i18next";
import conf_prop from "../../../properties/properties";
import queryString from 'query-string';

import {WebcamProctor} from "../../../component/utils";
import {findProjectUserByPumId} from "../../../service";
import InbasketWelcome from "../../../views/partials/inbasket-welcome";
import Moment from "react-moment";
import LoaderSpinner from "../../../views/loader/loader-spinner";

const route_path = conf_prop.get("route_path");


class InbasketUserInboxContaintView extends React.Component {
    constructor(props) {
        super(props);
        const query = queryString.parse(props.location.search);

        const pumId = query.pum;
        const pumId_ENCRYPTED = query.pum;
        const projectUserMapper = query

        const templateContentId_ENCRYPTED = props.match.params.templateContentId_ENCRYPTED;


        this.state = {
            pumId: pumId,
            showReply: false,
            responseAction: "",
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            templateContentId_ENCRYPTED: templateContentId_ENCRYPTED,
            isLoaded: false,
            templateContents: {},
            templateContent: {},
            template: {},
            projectUserMapper: projectUserMapper,
            projectUserMapperContentRead: {}
        };

        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.toggleReply = this.toggleReply.bind(this);
        this.templateContentByTemplateContentId = this.templateContentByTemplateContentId.bind(this);
        this.insertProjectUserContentRead = this.insertProjectUserContentRead.bind(this);

    }

    toggleReply(responseAction) {
        this.setState({
            responseAction: responseAction
        });
    }


    async templateContentByTemplateContentId() {
        await InbasketTemplateContentController.getTemplateContentByContaintId(this.state.templateContentId_ENCRYPTED)
            .then(
                result => {

                    const projectUserMapperContentRead = {
                        projectUserMapper: this.state.projectUserMapper,
                        templateContent: result
                    }

                    //console.log(projectUserMapperContentRead)
                    this.setState({

                        templateContent: result

                    });

                    this.insertProjectUserContentRead(projectUserMapperContentRead)


                }).catch(error => console.error(error));
    }


    async insertProjectUserContentRead(projectUserMapperContentRead) {
        //console.log(projectUserMapperContentRead)

        await InbasketProjectUserMapperContentReadController.insertProjectUserMapperContentRead(projectUserMapperContentRead).then(
            result => {


            }).catch(error => console.error(error));

    }


    async componentDidMount() {

        await this.findProjectUserByPumId();
        await this.templateContentByTemplateContentId();
        this.setState({
            isLoaded: true,
        })
    }


    render() {

        if (!this.state.isLoaded) {
            // return (
            //     <InbasketLoader/>
            // )
            return (
                <div className="text-center" style={{marginTop: '15%'}}>
                    <LoaderSpinner/>
                    {/*<h2 className="mb-3">Loading Please Wait ...</h2>*/}
                </div>
            )
        }else {
            if (this.state.projectUserMapper.submissionStatus === 'Y') {
                return <Redirect to={`${route_path}/user/thankyou/${this.state.pumId_ENCRYPTED}`}/>

            }
            const contentToCcFromMappers = _.groupBy(this.state.templateContent.contentMailerMappers, function (x) {
                return x.relation;
            });

            const toMappers = _.isEmpty(contentToCcFromMappers.TO) ? [] : contentToCcFromMappers.TO;
            const fromMappers = _.isEmpty(contentToCcFromMappers.FROM) ? [] : contentToCcFromMappers.FROM;
            const ccMappers = _.isEmpty(contentToCcFromMappers.CC) ? [] : contentToCcFromMappers.CC;


            const {t, i18n} = this.props;


            return (
                <div>
                    <InbasketWelcome pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                    <Row>
                        <Col md={12}>
                            <Row className="mt-3 mb-3">
                                <Col md={3}>
                                </Col>
                                <Col md={9} sm={12} xs={12}>

                                    <div className="text-right" id="timer-box-container">
                                        <InbasketUserInboxTimerView pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                                    </div>

                                </Col>
                            </Row>

                        </Col>

                    </Row>
                    <Row>

                        <Col md={3}>


                            <InbasketMailLegend pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                            <InbasketUserMaterialView pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>


                        </Col>
                        <Col md={9}>
                            <Link to={`${route_path}/user/inbox/${this.state.pumId_ENCRYPTED}`}
                                  style={{cursor: 'pointer', color: '#5E5E5E'}} id={"inbox-link"}><i
                                className="fas fa-angle-left mr-1"></i>{t("inbasket.inbox")}
                            </Link>
                            {/*<div className=" font-20 "><strong>{this.state.templateContent.subject}</strong></div>*/}
                            <hr></hr>
                            <Row>
                                <Col md={10}>
                                    <div className=" page_title "
                                         style={{fontSize: '16px'}}>{this.state.templateContent.subject}</div>
                                </Col>
                                <Col md={2}>
                                    {/*{!_.isEmpty(this.state.templateContent) && (
                                    <InbasketUserReplyView
                                        templateContent={this.state.templateContent}
                                        pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                                )}*/}
                                    <a style={{cursor: 'pointer', fontSize: '16px', color: '#5E5E5E'}}>
                                        <i className="fas fa-reply mr-3" onClick={() => this.toggleReply("REPLY")}
                                           title="reply"></i>
                                        <i className="fas fa-reply-all mr-3"
                                           onClick={() => this.toggleReply("REPLY_ALL")}
                                           title="reply-all"></i>
                                        <i className="mdi mdi-forward" onClick={() => this.toggleReply("FORWARD")}
                                           title="forward"></i>
                                    </a>
                                </Col>
                            </Row>
                            {/*<div className="d-flex mt-2">*/}
                            {/*<div>*/}
                            {/*    <img className="round" src={userImg}/>*/}
                            {/*</div>*/}


                            <div className="mt-3">
                                <Row>
                                    <Col md={8}>
                                        <div>
                                            {!_.isEmpty(fromMappers) &&
                                                <span>{t("inbasket.composemail.from")} :
                                                    {fromMappers.map((fromMapper, index) => (
                                                        <span
                                                            key={index}> {fromMapper.templateMailer.mailerName} &lt;{fromMapper.templateMailer.mailerEmail}&gt;</span>
                                                    ))}
                                                </span>
                                            }
                                        </div>
                                        <div>
                                            {!_.isEmpty(toMappers) &&
                                                <span>{t("inbasket.composemail.to")} :
                                                    {toMappers.map((toMapper, index) => (
                                                        <span
                                                            key={index}>{toMapper.templateMailer.mailerName} &lt;{toMapper.templateMailer.mailerEmail}&gt;</span>
                                                    ))}
                                                </span>
                                            }
                                        </div>
                                        <div className="">
                                            {!_.isEmpty(ccMappers) &&
                                                <span>
                                                    <small> {t("inbasket.composemail.cc")} :  </small>
                                                    {ccMappers.map((ccMapper, index) => (
                                                        <span
                                                            key={index}><small>{ccMapper.templateMailer.mailerName} &lt;{ccMapper.templateMailer.mailerEmail}&gt;</small></span>
                                                    ))}
                                                </span>
                                            }
                                        </div>

                                    </Col>
                                    <Col md={4}><h6>
                                        <Moment
                                            locale={conf_prop.get("lng")}
                                            utc={true}
                                            titleFormat={this.state.template.contentTimeFlag === "Y" ? "D MMM YYYY hh:mm A" : "D MMM YYYY"}
                                            format={this.state.template.contentTimeFlag === "Y" ? "D MMM YYYY hh:mm A" : "D MMM YYYY"}

                                            withTitle>{this.state.templateContent.contentDateTime}</Moment>
                                    </h6></Col>
                                </Row>

                            </div>
                            {/*</div>*/}

                            <Row className="mt-3">
                                {/*<PerfectScrollbar>*/}
                                <Col md={12} translate="no"
                                     dangerouslySetInnerHTML={{__html: this.state.templateContent.content}}>

                                </Col>
                                {/*</PerfectScrollbar>*/}
                                {/*<Col md={12}>*/}
                                {/*    <pre*/}
                                {/*        style={{"word-wrap": "break-word"}}>  {this.state.templateContent.content}</pre>*/}
                                {/*</Col>*/}
                            </Row>

                            <br clear="all"/>

                            <hr></hr>
                            <br clear="all"/>
                            <div>
                                {!_.isEmpty(this.state.templateContent) && (
                                    <InbasketUserReplyView
                                        showReply={this.state.showReply}
                                        responseAction={this.state.responseAction}
                                        templateContent={this.state.templateContent}
                                        pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                                )}
                            </div>


                            <WebcamProctor file_id={this.state.pumId_ENCRYPTED}/>


                        </Col>

                    </Row>

                </div>
            );
        }
    }
}

export default translate("translations")(InbasketUserInboxContaintView);

