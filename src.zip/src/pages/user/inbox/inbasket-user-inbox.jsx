import _ from "lodash";
import React from "react";
import Moment from 'react-moment';
import 'moment/locale/tr';
import {Link, Redirect} from 'react-router-dom';
import {Card, CardBody, Col, Row} from "reactstrap";
import InbasketTemplateContentController from "../../../api/inbasket/inbasket-templatecontent-controller.jsx";
import InbasketProjectUserMapperContentReadController
    from "../../../api/inbasket/inbasket-projectusermappercontentread-controller";
import {
    InbasketMailLegend,
    InbasketUserInboxTimerView,
    InbasketUserMaterialView,
    InbasketWelcome
} from "../../../views/partials";

import conf_prop from "../../../properties/properties";
import {translate} from "react-i18next";
import {findProjectUserByPumId} from "../../../service";
import {WebcamProctor} from "../../../component/utils";
import classNames from "classnames";

import LoaderSpinner from "../../../views/loader/loader-spinner";
import InbasketProjectUserMapperController from "../../../api/inbasket/inbasket-projectusermapper-controller";


const route_path = conf_prop.get("route_path");


class InbasketUserInboxView extends React.Component {


    constructor(props) {
        super(props);
        const pumId = props.match.params.pumId_ENCRYPTED;
        const pumId_ENCRYPTED = props.match.params.pumId_ENCRYPTED;


        this.state = {
            pumId: pumId,
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            isLoaded: false,
            projectUserMapper: {},
            template: {},
            templateContents: [],
            templateContent: {contentMailerMappers: []},
            contentMailerMapper: {},


            ProjectUserMapperContentReadGroupByContent: [],
            writeTime: 0,
            readTime: 0

        };


        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.findTemplateContent = this.findTemplateContent.bind(this);
        this.findProjectUserContentReadByPumId = this.findProjectUserContentReadByPumId.bind(this);
        this.validatePumById = this.validatePumById.bind(this);
    }

    async findTemplateContent() {
        await InbasketTemplateContentController.getTemplateContent(this.state.template.templateId_ENCRYPTED)
            .then(
                result => {
                    ;
                    const templateContents = result.map(templateContent => {
                        templateContent.mailerFrom = templateContent.contentMailerMappers.find(contentMailerMapper => contentMailerMapper.relation === "FROM");
                        return templateContent;
                    });

                    this.setState({

                        templateContents: templateContents,

                    });

                }).catch(error => console.error(error));
    }


    async findProjectUserContentReadByPumId() {
        await InbasketProjectUserMapperContentReadController.findByProjectUserMapper(this.state.pumId_ENCRYPTED)
            .then(
                projectUserMapperContentRead => {


                    const ProjectUserMapperContentReadGroupByContentId = _.groupBy(projectUserMapperContentRead.map(x => {
                        x.templateContentId = x.templateContent.templateContentId;
                        return x
                    }), "templateContentId")


                    this.setState({

                        ProjectUserMapperContentReadGroupByContent: ProjectUserMapperContentReadGroupByContentId,

                    });
                }).catch(error => console.error(error));
    }
    async validatePumById() {
        await InbasketProjectUserMapperController.validateById(this.state.pumId_ENCRYPTED)
            .then(response => {
                console.log(response);
            }).catch(error => {
                console.error(error);
                window.location = `${conf_prop.get("domainUrl")}${conf_prop.get("route_path")}/notification/error-unauthorized`;

            });
    }

    async componentDidMount() {
        await this.validatePumById();
        await this.findProjectUserByPumId();

        await this.findProjectUserContentReadByPumId();
        await this.findTemplateContent();
        this.setState({
            isLoaded: true,
        });
        this.intervalId = setInterval(this.setReadTime, 1000);
    }


    componentWillUnmount() {
        clearInterval(this.intervalId);
    }


    render() {

        const {t, i18n} = this.props
        if (!this.state.isLoaded) {
            // return (
            //     <InbasketLoader/>
            // )
            return (
                <div className="text-center" style={{marginTop: '15%'}}>
                    <LoaderSpinner/>
                    {/*<h2 className="mb-3">Loading Please Wait ...</h2>*/}
                </div>
            )
        }

        if (this.state.projectUserMapper.submissionStatus === 'Y') {
            return <Redirect to={`${route_path}/user/thankyou/${this.state.pumId_ENCRYPTED}`}/>

        }

        return (
            <div>
                <Row>
                    <Col md={12}>

                        <InbasketWelcome pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>


                        <Row className="mt-3 mb-3">
                            <Col md={3}>
                            </Col>
                            <Col md={9} sm={12} xs={12}>

                                <div className="text-right">
                                    {!_.isEmpty(this.state.projectUserMapper) && (
                                        <InbasketUserInboxTimerView pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}
                                                                    projectUserMapper={this.state.projectUserMapper}/>
                                    )}
                                </div>

                            </Col>
                        </Row>

                    </Col>

                </Row>
                <Row>

                    <Col md={3}>


                        <InbasketMailLegend pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}
                                            pumContentReadCount={this.state.pumContentReadCount}/>

                        <div className="p-0">
                            {!_.isEmpty(this.state.template) && (
                                <InbasketUserMaterialView pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                            )}
                        </div>


                    </Col>

                    <Col md={9}>

                        <Card className="bordered_card">
                            <CardBody>
                                <div className=" page_title " style={{fontSize: '16px'}}>{t("inbasket.inbox")}</div>
                                {_.orderBy(this.state.templateContents, ['contentDateTime'], ['desc']).map((curTemplateContent, index) => (

                                    <Link key={index}
                                          to={`${route_path}/user/inbox-content/${curTemplateContent.templateContentId_ENCRYPTED}?pum=${this.state.pumId_ENCRYPTED}`}>
                                        <div className="border-bottom mb-2 p-3 mt-3 email_content_hover">
                                            <Row
                                                className={classNames("text-secondary font-medium", {"mail-unread": _.isEmpty(this.state.ProjectUserMapperContentReadGroupByContent[curTemplateContent.templateContentId])})}>
                                                <Col md={1}>
                                                    {_.isEmpty(this.state.ProjectUserMapperContentReadGroupByContent[curTemplateContent.templateContentId]) &&
                                                    <i className="fas fa-circle" style={{color: '#238EE9'}}/>}</Col>

                                                <Col md={2}>
                                                    <h6>{_.isObject(curTemplateContent.mailerFrom) ? curTemplateContent.mailerFrom.templateMailer.mailerName : ""}</h6>
                                                </Col>
                                                <Col md={6}><h6

                                                    translate="no">{curTemplateContent.subject} </h6>
                                                </Col>
                                                <Col md={3}>
                                                    <h6>
                                                        <Moment
                                                            locale={conf_prop.get("lng")}
                                                         //   utc={true}
                                                            titleFormat={this.state.template.contentTimeFlag==="Y" ?  "D MMM YYYY hh:mm A" :"D MMM YYYY" }
                                                            format={this.state.template.contentTimeFlag==="Y" ?  "D MMM YYYY hh:mm A" :"D MMM YYYY" }

                                                            withTitle>{curTemplateContent.contentDateTime}</Moment>
                                                    </h6>

                                                </Col>
                                            </Row>
                                        </div>
                                    </Link>
                                ))}

                                    <WebcamProctor file_id={this.state.pumId_ENCRYPTED}/>
                            </CardBody>
                        </Card>

                    </Col>



                </Row>

            </div>
        );
    }
}

export default translate("translations")(InbasketUserInboxView);

