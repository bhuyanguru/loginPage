import React from "react";
import {Redirect} from 'react-router-dom';
import Select from 'react-select';
import {Button, Card, CardBody, Col, Input, Modal, ModalBody, ModalHeader, Row} from "reactstrap";
import InbasketUserMailResponseUtil
    from "../../component/inbasket/inbasket-user/inheritance/inbasket-user-mail-response-util";
import {
    InbasketMailLegend,
    InbasketUserInboxTimerView,
    InbasketUserMaterialView,
    InbasketWelcome
} from "../../views/partials";


import {translate} from "react-i18next";


import {findProjectUserByPumId} from "../../service";
import {WebcamProctor} from "../../component/utils";

import LoaderSpinner from "../../views/loader/loader-spinner";
import conf_prop from "../../properties/properties";
import InbasketProjectUserMapperController from "../../api/inbasket/inbasket-projectusermapper-controller";
import 'suneditor/dist/css/suneditor.min.css';
import SunEditor from "suneditor-react";
import ButtonWithLoader from "../../component/utils/button-with-loader";
import ButtonOutLineWithLoader from "../../component/utils/button-outline-with-loader";
import {basicSunEditorOptions, basicSunEditorOptionsWithoutLink} from "../../config/suneditor-config";

const route_path = conf_prop.get("route_path");


class InbasketUserComposeView extends InbasketUserMailResponseUtil {
    constructor(props) {
        super(props);
        const pumId = props.match.params.pumId_ENCRYPTED;
        const pumId_ENCRYPTED = props.match.params.pumId_ENCRYPTED;
        this.state = {
            pumId: pumId,
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            decryptedPumId: null,
            theme: 'snow',
            isLoaded: false,
            template: {},
            templatemailers: [],
            ccMailers: [],
            toMailers: [],
            bccMailers: [],
            newResponse: {},
            mailermappers: [],
            projectUserMapper: {},
            writeTime: 0,
            readTime: 0,
            discardModal: false,
            buttonDisabled: true,
            sendButtonDisabled: true,
            draftButtonDisabled: true,


        };

        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.handleCopy = this.handleCopy.bind(this);
        this.handlePaste = this.handlePaste.bind(this);
        this.discardDraftModal = this.discardDraftModal.bind(this);
        this.validatePumById = this.validatePumById.bind(this);
    }
    handleCopy(event) {
        event.preventDefault();

}
    handlePaste(event) {
        event.preventDefault();

    }

    discardDraftModal() {

        this.setState({
            discardModal: !this.state.discardModal
        });
    }

    async validatePumById() {
        await InbasketProjectUserMapperController.validateById(this.state.pumId_ENCRYPTED)
            .then(response => {
                console.log(response);
            }).catch(error => {
                console.error(error);
                window.location = `${conf_prop.get("domainUrl")}${conf_prop.get("route_path")}/notification/error-unauthorized`;

            });
    }

    async componentDidMount() {
        await this.validatePumById();
        await this.findProjectUserByPumId();
        await this.templateMailerBytemplate();
        this.writeTimeIntervalId = setInterval(this.setWriteTime, 1000);
        // this.intervalId = setInterval(this.setReadTime, 1000);
        this.setState({
            isLoaded:true
        })
    }


    componentWillUnmount() {
        clearInterval(this.writeTimeIntervalId);
    }


    render() {

        if (!this.state.isLoaded) {
            return (
                // <InbasketLoader/>
                <div className="text-center" style={{marginTop: '15%'}}>
                    <LoaderSpinner/>
                    {/*<h2 className="mb-3">Loading Please Wait ...</h2>*/}
                </div>
            )
        }else {

            if (this.state.projectUserMapper.submissionStatus === 'Y') {
                return <Redirect to={`${route_path}/user/thankyou/${this.state.pumId_ENCRYPTED}`}/>

            }


            if (this.state.inboxRedirect) {
                // console.log(`${route_path}/inbasket-user/inbox/${this.state.pumId_ENCRYPTED}`)
                return <Redirect to={`${route_path}/user/inbox/${this.state.pumId_ENCRYPTED}`}/>
            }
            const {t, i18n} = this.props;
            return (
                <div>
                    <InbasketWelcome pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                    <Row>
                        <Col md={12}>
                            <Row className="mt-3 mb-3">
                                <Col md={4}>
                                </Col>
                                <Col md={8} sm={12} xs={12}>

                                    <div className="text-right">
                                        <InbasketUserInboxTimerView pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                                    </div>

                                </Col>
                            </Row>

                        </Col>

                    </Row>
                    <Row>

                        <Col md={3}>

                            <InbasketMailLegend pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                            <InbasketUserMaterialView pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>


                        </Col>
                        <Col md={9}>
                            <Card className="bordered_card">
                                <CardBody>
                                    <div className="p-3">
                                        <Row className="mb-1">
                                            <Col md={1}>
                                                {/*<div className="text-left"><i className=" mdi mdi-pencil"></i></div>*/}
                                            </Col>

                                            <Col md={10}></Col>
                                            <Col md={1}>
                                                <div className="text-right" style={{cursor: 'pointer'}}>
                                                    <i className="fas fa-trash-alt" title="Discard draft"
                                                        // onClick={()=>this.onDiscardChange("INBOX")}
                                                       onClick={this.discardDraftModal}></i></div>
                                            </Col>

                                        </Row>
                                        <Row>
                                            <Col className="text-right compose-text" md={1}>
                                                <label className="mt-2">{t("inbasket.composemail.to")}</label>
                                            </Col>
                                            <Col md={10}>
                                                <Select
                                                    placeholder={t("inbasket.select.placeholder")}
                                                    required
                                                    isMulti
                                                    name="mailerName"
                                                    options={this.state.templatemailers}
                                                    className="basic-multi-select"
                                                    classNamePrefix="next_select"
                                                    onChange={(templatemailers) => this.onToMailerchange(templatemailers, "TO")}
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="mt-3">
                                            <Col className="text-right compose-text" md={1}>
                                                <label className="mt-2">{t("inbasket.composemail.cc")}</label>
                                            </Col>
                                            <Col md={10}>
                                                <Select
                                                    placeholder={t("inbasket.select.placeholder")}
                                                    required
                                                    isMulti
                                                    name="colors"
                                                    options={this.state.templatemailers}
                                                    className="basic-multi-select"
                                                    classNamePrefix="next_select"
                                                    onChange={(templatemailers) => this.onCcMailerchange(templatemailers, "CC")}
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="mt-3">
                                            <Col className="text-right compose-text" md={1}>
                                                <label className="mt-2">{t("inbasket.composemail.bcc")}</label>
                                            </Col>
                                            <Col md={10}>
                                                <Select
                                                    placeholder={t("inbasket.select.placeholder")}
                                                    required
                                                    isMulti
                                                    name="colors"
                                                    options={this.state.templatemailers}
                                                    className="basic-multi-select"
                                                    classNamePrefix="next_select"
                                                    onChange={(templatemailers) => this.onBccMailerchange(templatemailers, "BCC")}
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="mt-3">
                                            <Col className="text-right compose-text" md={1}>
                                                <label className="mt-2">{t("inbasket.composemail.subject")}</label>
                                            </Col>
                                            <Col md={10}>
                                                <Input type="text" className="input-text-next" name="subject"
                                                       onCopy={this.handleCopy}
                                                       onPaste={this.handlePaste}
                                                       onChange={this.onSubjectChange}></Input>
                                            </Col>
                                        </Row>
                                        <Row className="mt-3">
                                            <Col md={1}>

                                            </Col>
                                            <Col md={10} className={"comment_summernote"}>
                                                <SunEditor

                                                    defaultValue={this.state.newResponse.response}
                                                    // hideToolbar={true}
                                                    setOptions={{
                                                        mode: 'classic',
                                                        height: "200px",
                                                        resizingBar: true,
                                                        showPathLabel: false,
                                                        "buttonList": [basicSunEditorOptionsWithoutLink]
                                                    }}
                                                    onChange={this.onUpdateResponseTextChange}
                                                    onCopy={this.handleCopy}
                                                    onPaste={this.handlePaste}
                                                    // onBlur={(event, editorContents) => this.onNoteBlur(event, editorContents, statement)}
                                                    setDefaultStyle="font-family: Poppins , sans-serif; font-size: 14px;"
                                                    // onPaste={this.handlePaste}
                                                />



                                            </Col>
                                        </Row>

                                        <Row className="mt-3">
                                            <Col md={1}></Col>
                                            <Col md={10}>
                                                <div>


                                                    <ButtonWithLoader loading={!this.state.sendButtonDisabled}
                                                                      disabled={!this.state.sendButtonDisabled}
                                                                      onClick={() => this.onSaveResponse("inbox", "SENT", "COMPOSE")}
                                                                      text={t("inbasket.mailsend")}/> {''}

                                                    <ButtonOutLineWithLoader loading={!this.state.draftButtonDisabled}
                                                                             disabled={!this.state.draftButtonDisabled}
                                                                             onClick={() => this.onSaveResponse("inbox", "DRAFT", "COMPOSE")}
                                                                             text={t("inbasket.maildraft")}/>
                                                </div>
                                            </Col>
                                        </Row>


                                    </div>

                                    <WebcamProctor file_id={this.state.pumId_ENCRYPTED}/>


                                    <Modal
                                        isOpen={this.state.discardModal}
                                        toggle={this.discardDraftModal}
                                        backdrop={true}
                                        // className="discard-draft-modal"
                                        size="md"
                                    >
                                        <ModalHeader toggle={this.discardDraftModal}>
                                            <b>{t("inbasket.maildiscard.conformbox.title")}</b>
                                        </ModalHeader>
                                        <ModalBody>
                                            <div className="text-center p-4">
                                                <h6>{t("inbasket.maildiscard.conformbox.msg")}
                                                </h6>
                                            </div>
                                            <Row>
                                                <Col md={5}></Col>
                                                <Col md={7} className="text-right">
                                                    <Button className="next_cancel_btn next_btn_lg mr-2"
                                                            onClick={this.discardDraftModal}>{t("inbasket.maildiscard.conformbox.cancel")}</Button>
                                                    <Button className="next_accent2_btn next_btn_lg"
                                                            onClick={() => this.onDiscardChange("INBOX")}>
                                                        {t("inbasket.maildiscard.conformbox.confirm")}
                                                    </Button>
                                                </Col>
                                            </Row>

                                        </ModalBody>

                                    </Modal>

                                </CardBody>
                            </Card>
                        </Col>

                    </Row>

                </div>
            );
        }
    }
}

export default translate("translations")(InbasketUserComposeView);

