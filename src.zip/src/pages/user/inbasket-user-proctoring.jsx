import _ from "lodash";
import React from "react";

import Webcam from "react-webcam";
import {Button, Card, CardBody, Col, Row} from "reactstrap";
import ApiUtils from '../../api/ApiUtils';
import {InbasketProjectUserMapperController, InbasketTemplateInstructionController} from "../../api/inbasket";
import {translate} from "react-i18next";
import {removeLocalStorage} from "../../service";
import {toastify} from "../../component/utils/toastify";
import conf_prop from "../../properties/properties";


class InbasketUserProctoringView extends React.Component {
    constructor(props) {
        super(props);
        const pumId = props.match.params.pumId_ENCRYPTED;
        const pumId_ENCRYPTED = props.match.params.pumId_ENCRYPTED;
        //console.log(pumId)
        removeLocalStorage();


        this.state = {
            pumId: pumId,
            isLoaded: false,
            projectUserMapper: {project: {clientTemplateMapper: {template: {}}}},
            webcamRef: {},
            imageSrc: null,
            templateInstruction: {},


        };

        this.onChange = this.onChange.bind(this);
        this.capture = this.capture.bind(this);
        this.onNextPage = this.onNextPage.bind(this);
        this.getTemplateInstruction = this.getTemplateInstruction.bind(this);
        this.setRef = this.setRef.bind(this);
        this.findProjectUserByPumId = this.findProjectUserByPumId.bind(this);
        this.validatePumById = this.validatePumById.bind(this);

    }

    onNextPage() {
        const {t, i18n} = this.props;
        if (_.isNull(this.state.imageSrc)) {
            toastify("error", t("inbasket.proctoring.toas.msg.capture.picture"), t("inbasket.proctoring.toas.msg.capture.picture"));


        } else {
            this.props.history.push('/user/instruction/' + this.state.pumId);
        }
    }

    setRef(webcam) {
        this.webcam = webcam;
    };


    async capture() {
        const {t, i18n} = this.props;
        let imageSrc = this.webcam.getScreenshot();
        this.setState({imageSrc: imageSrc});
        const webcamRecord = {projectUserMapper: this.state.projectUserMapper, base64Url: imageSrc};
        // console.log(webcamRecord)
        await InbasketProjectUserMapperController.saveUserImage(webcamRecord).then(
            result => {
                toastify("success", t("inbasket.proctoring.toas.msg.image.saved"), t("inbasket.proctoring.toas.msg.image.saved"));


            }).catch(error => console.error(error));
    };

    async findProjectUserByPumId() {

        await InbasketProjectUserMapperController.getProjectClient(this.state.pumId)
            .then(
                projectUserMapper => {


                    this.setState({

                        projectUserMapper: projectUserMapper,


                    });


                    ApiUtils.setLocalStorage("projectUserMapper", JSON.stringify(this.state.projectUserMapper));

                    // console.log("projectUserMapper", this.state.projectUserMapper)
                }).catch(error => console.error(error));
    }

    async getTemplateInstruction() {

        await InbasketTemplateInstructionController.findByTemplate(this.state.projectUserMapper.project.clientTemplateMapper.template.templateId_ENCRYPTED).then(
            result => {


                this.setState({

                    templateInstruction: result,


                });


            }).catch(error => console.error(error));
    }


    onChange(e) {
        this.setState({value: e.target.value});

    }

    async validatePumById() {
        await InbasketProjectUserMapperController.validateById(this.state.pumId_ENCRYPTED)
            .then(response => {
                console.log(response);
            }).catch(error => {
                console.error(error);
                window.location = `${conf_prop.get("domainUrl")}${conf_prop.get("route_path")}/notification/error-unauthorized`;

            });
    }


    async componentDidMount() {
        await this.validatePumById();
        await this.findProjectUserByPumId();
        await this.getTemplateInstruction();
        this.setState({
            isLoaded: true,
        })


    }


    render() {
        const {t, i18n} = this.props;
        return (
            <div>
                <Row>
                    <Col md={12}>
                        <Card>
                            <span className="lstick"/>
                            <CardBody>
                                <Row>

                                    <Col md={12}>
                                        <h4>Instruction</h4>
                                    </Col>
                                </Row>

                            </CardBody>
                        </Card>
                    </Col>

                </Row>
                <Row>

                    <Col md={12}>
                        <Card>
                            <CardBody>
                                <Row>
                                    <Col md={12}>

                                        <p>
                                            An Inbasket exercise is an assessment tool used to evaluate managerial level
                                            competencies like planning, execution and time management etc. Through
                                            organization charts and other information material, participants are first
                                            given a scenario which closely resembles their actual work environment and
                                            then asked to prioritise between or respond to a number of situations or
                                            issues.
                                        </p>
                                        <p>
                                            You have 10 minutes to complete reading the detailed instructions for this
                                            exercise and the briefing material given on the left side of the screen.
                                        </p>


                                    </Col>

                                </Row>
                                <Row>
                                    <Col md={12} style={{display: (!_.isNull(this.state.imageSrc) ? 'none' : 'block')}}
                                         className="text-center">

                                        <div>
                                            <Webcam
                                                audio={false}
                                                height={240}
                                                ref={this.setRef}
                                                screenshotFormat="image/png"
                                                width={320}
                                                // videoConstraints={videoConstraints}
                                            />

                                        </div>
                                        <div>
                                            <Button className="btn btn-info " style={{marginTop: '10px'}}
                                                    onClick={this.capture}>Capture photo</Button>
                                        </div>


                                    </Col>
                                    <Col md={12} style={{display: (_.isNull(this.state.imageSrc) ? 'none' : 'block')}}
                                         className="text-center">
                                        <div>
                                            <img src={this.state.imageSrc}></img>
                                            <h4 className="text-success" style={{marginTop: '15px'}}># Captured
                                                Image</h4>
                                        </div>
                                    </Col>
                                </Row>


                            </CardBody>
                        </Card>
                    </Col>
                    <Col md={12}>
                        <Card>
                            <CardBody>
                                <Row>
                                    <Col md={12}>
                                        <div className="text-right"><Button className="btn btn-info"
                                                                            onClick={this.onNextPage}
                                        >Continue</Button></div>
                                    </Col>
                                </Row>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>


            </div>

        );
    }
}

export default translate("translations")(InbasketUserProctoringView);

