import React from "react";
import {Card, CardBody, Col, Row} from "reactstrap";
import {translate} from "react-i18next";
import {findProjectUserByPumId, redirectTool} from "../../service";
import conf_prop from "../../properties/properties";
import img from "../../component/inbasket/assets/images/instruction-page.png";
import {InbasketVideosection} from "../../views/partials";
import queryString from "query-string";
import ApiUtils, {decodeJwtString} from "../../api/ApiUtils";
import _ from 'lodash'
import {Redirect} from "react-router-dom";
import LoaderSpinner from "../../views/loader/loader-spinner";
import {clearTimer} from "../../service/localstorage-service";
import InbasketProjectUserMapperController from "../../api/inbasket/inbasket-projectusermapper-controller";


const route_path = conf_prop.get("route_path");

class InbasketUserIntroductionsView extends React.Component {
    constructor(props) {
        super(props);
        const query = queryString.parse(props.location.search);

        const redirectJsonData = _.isEmpty(query.redirectJsonData) ? "" : decodeJwtString(query.redirectJsonData)
        ApiUtils.setLocalStorage("redirectJsonData", redirectJsonData);
        const pumId_ENCRYPTED = props.match.params.pumId_ENCRYPTED;


        this.state = {
            // pumId: pumId,
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            redirectData: {},
            isLoaded: false,
            projectUserMapper: {project: {clientTemplateMapper: {template: {}}}},
            redirectJsonData: redirectJsonData,
            instruction: {},
            isError:false
        };
        this.redirectTool = redirectTool.bind(this);
        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.clearTimer = clearTimer.bind(this);
        this.validatePumById = this.validatePumById.bind(this);
    }

    async validatePumById() {
        await InbasketProjectUserMapperController.validateById(this.state.pumId_ENCRYPTED)
            .then(response => {
                console.log(response);
            }).catch(error => {
                console.error(error);
                window.location = `${conf_prop.get("domainUrl")}${conf_prop.get("route_path")}/notification/error-unauthorized`;

            });
    }

    async componentDidMount() {
        await this.validatePumById();
        this.clearTimer();
        await this.redirectTool();
        await this.findProjectUserByPumId();
        this.setState({
            isLoaded: true,
        })

    }


    render() {

        // console.log("instruction",instruction)
        const {t, i18n} = this.props;
        const {template, redirectData, instruction} = this.state;

        if (this.state.projectUserMapper.submissionStatus === 'Y') {
            return <Redirect to={`${route_path}/user/thankyou/${this.state.pumId_ENCRYPTED}`}/>

        }
        if (!this.state.isLoaded) {

            return (
                <div className="text-center" style={{marginTop: '15%'}}>
                    <LoaderSpinner/>
                    {/*<h2 className="mb-3">Loading Please Wait ...</h2>*/}
                </div>
            )
        }
        return (
            <div>

                <div className=" instruction_wrapper ">
                    <div className="mb-3 text_next_color font-12"><a className="text-white font-12"
                                                                     href={redirectData.redirectUrl}><i
                        className="fas fa-angle-left"/>{' '} {t(`inbasket.back.${redirectData.integrationName}`)}
                    </a>
                    </div>
                    <div className="page_title" style={{color: '#6835FF'}}>
                        {redirectData.itemName}

                    </div>
                </div>

                <Row>

                    <Col>


                        <Card className="next_radious mt-4">
                            <CardBody>
                                <Row>
                                    <Col lg="9" md="9" sm="9">
                                        <div style={{fontSize: '14px', marginTop: '3%'}}>
                                            <div translate="no"
                                                 dangerouslySetInnerHTML={{__html: instruction.templateInstruction}}>
                                            </div>
                                        </div>
                                    </Col>
                                    <Col lg="3" md="3" sm="3" className="text-center">

                                        <img className="img-fluid intro-img mob_img_none" src={img}/>
                                    </Col>
                                </Row>


                            </CardBody>
                        </Card>

                        {(_.isEmpty(instruction) || _.isEmpty(instruction.videoInstructionStatus) || instruction.videoInstructionStatus === "N" )  ? " " :
                            <div className="mt-3 text-center container_lg">
                                <InbasketVideosection instruction={this.state.instruction}/>
                            </div>
                        }


                        <div className="text-center" style={{marginTop: '3%'}}>
                            <a
                                href={`${route_path}/user/instruction/` + this.state.pumId_ENCRYPTED}
                                className="next_btn next_btn_lg text-white">
                                {t("inbasket.introduction.start")}</a>
                        </div>
                    </Col>

                </Row>
            </div>
        )
    }
}


export default translate("translations")(InbasketUserIntroductionsView);

