import _ from "lodash";
import React from "react";
import {Col, Row} from "reactstrap";
import {InbasketProjectUserMapperResponseController} from "../../../api/inbasket";
import {
    InbasketMailLegend,
    InbasketUserInboxTimerView,
    InbasketUserMaterialView,
    InbasketUserResponseReplyView,
    InbasketWelcome
} from "../../../views/partials";

import {translate} from "react-i18next";
import conf_prop from "../../../properties/properties";

import queryString from "query-string";
import {WebcamProctor} from "../../../component/utils";
import {findProjectUserByPumId} from "../../../service";

import Moment from "react-moment";
import LoaderSpinner from "../../../views/loader/loader-spinner";
import {Redirect} from "react-router-dom";

const route_path = conf_prop.get("route_path");

class InbasketUserSentContaintView extends React.Component {
    constructor(props) {
        super(props);
        const query = queryString.parse(props.location.search);

        const pumId = query.pum;
        const pumId_ENCRYPTED = query.pum;
        const pumrId = props.match.params.pumrId_ENCRYPTED;
        this.state = {
            pumId: pumId,
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            pumrId: pumrId,
            isLoaded: false,
            responseAction: "",
            projectusermapperSentresponse: {},
            projectUserResponseMailerMapper: {UserResponseToMailer: {}, UserResponseCCMailer: {}},
            projectusermapperresponseRelationGroups: [],
            templatemailers: [],
            projectUserMapper: {}
        };

        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.projectUserMapperSentResponseByPumrId = this.projectUserMapperSentResponseByPumrId.bind(this);
        this.toggleReply = this.toggleReply.bind(this);


    }

    toggleReply(responseAction) {
        this.setState({
            responseAction: responseAction
        });
    }


    async projectUserMapperSentResponseByPumrId() {
        //console.log.log(this.state.pumrId)
        await InbasketProjectUserMapperResponseController.getProjectUserMapperResponseBypumrId(this.state.pumrId)
            .then(
                result => {

                    this.setState({
                        isLoaded: true,
                        projectusermapperSentresponse: result
                    });

                    //console.log.log("sentcontaint", this.state.projectusermapperSentresponse)

                }).catch(error => {
                    this.setState({
                        isLoaded: true,
                        error: error
                    });
                console.error(error);
                });
    }


    async componentDidMount() {
        await this.findProjectUserByPumId();
        await this.projectUserMapperSentResponseByPumrId(this.state.pumrId);
    }


    render() {

        const {projectusermapperSentresponse, pumId_ENCRYPTED, projectUserMapper} = this.state;
        if (!this.state.isLoaded) {
            // return (
            //     <InbasketLoader/>
            // )
            return (
                <div className="text-center" style={{marginTop: '15%'}}>
                    <LoaderSpinner/>
                    {/*<h2 className="mb-3">Loading Please Wait ...</h2>*/}
                </div>
            )
        }else {


            if (this.state.projectUserMapper.submissionStatus === 'Y') {
                return <Redirect to={`${route_path}/user/thankyou/${this.state.pumId_ENCRYPTED}`}/>

            }

            const projectusermapperSentresponseMailer = _.groupBy(projectusermapperSentresponse.projectUserResponseMailerMappers, function (x) {
                return x.relation;
            });

            const {t, i18n} = this.props;

            const toMappers = _.isEmpty(projectusermapperSentresponseMailer.TO) ? [] : projectusermapperSentresponseMailer.TO;
            // const fromMappers = _.isEmpty(projectusermapperSentresponseMailer.FROM) ? [] : projectusermapperSentresponseMailer.FROM;
            const ccMappers = _.isEmpty(projectusermapperSentresponseMailer.CC) ? [] : projectusermapperSentresponseMailer.CC;
            const bccMappers = _.isEmpty(projectusermapperSentresponseMailer.BCC) ? [] : projectusermapperSentresponseMailer.BCC;


            return (

                <div>
                    <InbasketWelcome pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                    <Row>

                        <Col md={12} className="text-right mt-3 mb-3">

                            <InbasketUserInboxTimerView pumId_ENCRYPTED={pumId_ENCRYPTED}
                                                        projectUserMapper={this.state.projectUserMapper}/>


                        </Col>

                    </Row>
                    <Row>

                        <Col md={3}>


                            <InbasketMailLegend pumId_ENCRYPTED={pumId_ENCRYPTED}/>
                            <InbasketUserMaterialView pumId_ENCRYPTED={pumId_ENCRYPTED}/>


                        </Col>
                        <Col md={9}>

                            <Row className="mt-3">
                                <Col md={10}>
                                    <div className=" page_title "
                                         style={{fontSize: '16px'}}>{projectusermapperSentresponse.subject}</div>

                                </Col>
                                <Col md={2}>
                                    {/*{!_.isEmpty(this.state.templateContent) && (
                                    <InbasketUserReplyView
                                        templateContent={this.state.templateContent}
                                        pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                                )}*/}
                                    <span style={{cursor: 'pointer'}}>
                                    <i className="fas fa-reply mr-3" onClick={() => this.toggleReply("REPLY")}
                                       title="reply"></i>
                                    <i className="fas fa-reply-all mr-3" onClick={() => this.toggleReply("REPLY_ALL")}
                                       title="reply-all"></i>
                                    <i className="mdi mdi-forward" onClick={() => this.toggleReply("FORWARD")}
                                       title="forward"></i>
                                </span>
                                </Col>
                            </Row>


                            {/*<div className="d-flex mt-4">*/}
                            <div className="mt-4">
                                <Row>
                                    <Col md={8}>
                                        <div className="text-muted">
                                        <span>
                                            {!_.isEmpty(toMappers) &&
                                                <span>
                                                    <strong>{t("inbasket.composemail.to")} : </strong>
                                                    {toMappers.map((toMapper, index) => (
                                                        <span key={index}><strong
                                                            className="ml-1">{toMapper.templateMailer.mailerName}&lt;{toMapper.templateMailer.mailerEmail}&gt;</strong></span>
                                                    ))}
                                                </span>
                                            }
                                        </span>

                                            <div className="">
                                                {!_.isEmpty(ccMappers) &&
                                                    <span>
                                                    <small>{t("inbasket.composemail.cc")} : </small>
                                                        {ccMappers.map((ccMapper, index) => (
                                                            <span key={index}><small
                                                                className="ml-1">{ccMapper.templateMailer.mailerName}&lt;{ccMapper.templateMailer.mailerEmail}&gt;</small></span>
                                                        ))}

                                                </span>
                                                }
                                            </div>
                                            <div>
                                                {!_.isEmpty(bccMappers) &&
                                                    <span>
                                                    <small>{t("inbasket.composemail.bcc")} :</small>
                                                        {bccMappers.map((bccMapper, index) => (
                                                            <span key={index}><small
                                                                className="ml-1"> {bccMapper.templateMailer.mailerName}&gt;{bccMapper.templateMailer.mailerEmail}&gt;</small></span>
                                                        ))}
                                                </span>
                                                }
                                            </div>

                                        </div>
                                    </Col>
                                    <Col md={4}>
                                        <h6 className=" text-secondary font-medium">

                                            <Moment locale={conf_prop.get("lng")}
                                                    utc={false}
                                                    titleFormat="D MMM YYYY hh:mm A"
                                                    format="D MMM YYYY HH:mm"
                                                    withTitle>{this.state.projectusermapperSentresponse.genDate}</Moment>
                                        </h6>
                                    </Col>
                                </Row>

                            </div>
                            <Row className="p-5">
                                <Col md={12} translate="no"
                                     dangerouslySetInnerHTML={{__html: this.state.projectusermapperSentresponse.response}}>

                                </Col>
                            </Row>

                            <hr></hr>
                            {!_.isEmpty(this.state.projectusermapperSentresponse) && (
                                <InbasketUserResponseReplyView
                                    responseAction={this.state.responseAction}
                                    responseReply={this.state.projectusermapperSentresponse}
                                    projectUserMapper={this.state.projectUserMapper}
                                    pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                            )}
                            {(!_.isEmpty(projectUserMapper.project) && projectUserMapper.project.proctoringStatus === "Y") && (
                                <WebcamProctor file_id={this.state.pumId_ENCRYPTED}/>
                            )}

                        </Col>

                    </Row>

                </div>
            );
        }
    }
}

export default translate("translations")(InbasketUserSentContaintView);

