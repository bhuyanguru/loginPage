import _ from "lodash";
import React from "react";
import {Redirect} from 'react-router-dom';


import {Button, Card, CardBody, Col, CustomInput, ListGroup, ListGroupItem, Row} from "reactstrap";
import conf_prop from '../../properties/properties'
import {InbasketTemplateInstructionController} from "../../api/inbasket";

import {translate} from "react-i18next";
import {findProjectUserByPumId, findTemplateMaterialByTempId, redirectTool} from "../../service";

import {InbasketUserTimerView, InbasketWelcome} from "../../views/partials";
import LoaderSpinner from "../../views/loader/loader-spinner";
import ApiUtils from "../../api/ApiUtils";
import classNames from "classnames";
import {WebcamProctor} from "../../component/utils";
import InbasketProjectUserMapperController from "../../api/inbasket/inbasket-projectusermapper-controller";


const route_path = conf_prop.get("route_path");


class InbasketUserInstructionView extends React.Component {
    constructor(props) {
        super(props);
        const pumId = props.match.params.pumId_ENCRYPTED;
        const pumId_ENCRYPTED = props.match.params.pumId_ENCRYPTED;
        //console.log(pumId)

        const redirectJsonData = ApiUtils.getLocalStorage("redirectJsonData");

        this.state = {
            pumId: pumId,
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            isLoaded: false,
            projectUserMapper: {project: {clientTemplateMapper: {template: {}}}},
            webcamRef: {},
            imageSrc: null,
            templateInstruction: {},
            templateMaterial: {},
            agree: false,
            redirectData: {},
            template:{}


        };

        this.onChange = this.onChange.bind(this);
        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.findTemplateMaterialByTempId = findTemplateMaterialByTempId.bind(this);
        this.setMaterial = this.setMaterial.bind(this);
        this.check = this.check.bind(this);


        this.getTemplateInstruction = this.getTemplateInstruction.bind(this);
        this.redirectTool = redirectTool.bind(this);
        this.validatePumById = this.validatePumById.bind(this);

    }


    async getTemplateInstruction() {

        await InbasketTemplateInstructionController.findByTemplate(this.state.projectUserMapper.project.clientTemplateMapper.template.templateId_ENCRYPTED).then(
            result => {


                this.setState({
                    templateInstruction: result,


                });


            }).catch(error => console.error(error));
    }


    setMaterial(templateMaterial) {

        this.setState({
            templateMaterial: templateMaterial,

        })
    }

    check(check) {
        // console.log(check)
        this.setState({
            agree: check
        })
    }

    onChange(e) {
        this.setState({value: e.target.value});

    }
    async validatePumById() {
        await InbasketProjectUserMapperController.validateById(this.state.pumId_ENCRYPTED)
            .then(response => {
                console.log(response);
            }).catch(error => {
                console.error(error);
                window.location = `${conf_prop.get("domainUrl")}${conf_prop.get("route_path")}/notification/error-unauthorized`;

            });
    }


    async componentDidMount() {
        await this.validatePumById();
        await this.findProjectUserByPumId();
        await this.redirectTool();
        await this.getTemplateInstruction();
        await this.findTemplateMaterialByTempId();
        this.setState({
            isLoaded: true,
        })

    }


    render() {
        const {templateMaterial, isLoaded, projectUserMapper, templateInstruction, templateMaterials} = this.state;
        // if (!isLoaded) {
        //     return (
        //         <InbasketLoader/>
        //     )
        // }
        if (!this.state.isLoaded) {

            return (
                <div className="text-center" style={{marginTop: '15%'}}>
                    <LoaderSpinner/>
                    {/*<h2 className="mb-3">Loading Please Wait ...</h2>*/}
                </div>
            )
        }
        const {t, i18n} = this.props;


        if (this.state.projectUserMapper.submissionStatus === 'Y') {
            return <Redirect to={`${route_path}/user/thankyou/${this.state.pumId_ENCRYPTED}`}/>

        }

        return (
            <div>
                <InbasketWelcome pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                <Row>
                    <Col md={12}>

                        <Row>
                            <Col md={3}>
                            </Col>
                            <Col md={9}>
                                <Row className="mt-4">
                                    <Col md={3}>
                                        {/*<div className="page_title"><span>Reading Material</span></div>*/}
                                    </Col>
                                    <Col md={6}></Col>
                                    <Col lg={3} md={3} sm={12} xs={12}>
                                        <div className="text-right instruction-timer">
                                            {!_.isEmpty(projectUserMapper.project.clientTemplateMapper.template) && (
                                                <InbasketUserTimerView
                                                    projectUserMapper={projectUserMapper}

                                                    pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                                            )}
                                        </div>
                                    </Col>
                                </Row>
                            </Col>
                        </Row>

                        <Row className="mt-3">
                            <Col md={3}>


                                <Card className="bordered_card" style={{width: '90%'}}>
                                    <div className="next_card_title text-center"><b
                                        style={{fontSize: '16px'}}>{t("inbasket.usermaterial.information")}</b></div>
                                    <hr/>
                                    {/*<CardBody>*/}
                                    {!_.isEmpty(projectUserMapper.project.clientTemplateMapper.template) && (


                                        <ListGroup>
                                            {this.state.templateMaterials.map((curTemplateMaterial, index) => (

                                                <ListGroupItem key={index} style={{cursor: 'pointer'}} action
                                                               active={templateMaterial.materialId === curTemplateMaterial.materialId}
                                                               className="justify-content-between feed-item-info"
                                                               onClick={() => this.setMaterial(curTemplateMaterial)}> {curTemplateMaterial.materialName}
                                                    {" "}</ListGroupItem>
                                            ))}

                                        </ListGroup>


                                    )}
                                    {/*</CardBody>*/}
                                </Card>
                            </Col>
                            <Col md={9}>

                                <Card className="bordered_card">
                                    <CardBody>


                                        <div className=" page_title mb-4"
                                             style={{fontSize: '16px'}}>{templateMaterial.materialName}</div>


                                        {templateMaterial.materialMime == "application/pdf" ? <iframe
                                            src={`https://pdf-viewer.thinktalentws48.click/web/viewer.html?file=${templateMaterial.materialLink}#toolbar=0`}
                                            frameBorder="0"
                                            style={{
                                                position: "relative",
                                                display: "block",
                                                height: "100vh",
                                                width: "100%"
                                            }}/> : <div
                                            dangerouslySetInnerHTML={{__html: templateMaterial.materialContent}}></div>}


                                        <Row className="mt-5">
                                            <Col lg={8} md={8} sm={12} xs={12}>
                                                <div className="next_checkbox mt-3">
                                                    <CustomInput type="checkbox" id="exampleCustomCheckbox1"
                                                                 onChange={e => this.check(e.target.checked)}
                                                                 label={t("inbasket.insrturction.chekbox.message")}/>
                                                </div>
                                                {/*label={curTemplateInstruction.instructionCheckmessage}*/}
                                            </Col>

                                            <Col lg={4} md={4} sm={12} xs={12}>
                                                <div
                                                    className="text-right readytostart_btn">{projectUserMapper.submissionStatus === 'Y' ?
                                                    <Button disabled
                                                            className="next_btn"
                                                            style={{fontSize: '12px'}}>{t("inbasket.userdashboard.completed")}</Button> :
                                                    <span
                                                        title={!this.state.agree ? t("inbasket.instruction.checkbox.tooltip") : false}>
                                                                <a href={`${route_path}/user/inbox/${this.state.pumId_ENCRYPTED}`}

                                                                    // className={"mob_next_btn next_btn"}
                                                                   className={classNames("start_next_btn", {
                                                                       "link-disabled": !this.state.agree,
                                                                       "next_btn": this.state.agree
                                                                   })}
                                                                    // disabled={this.state.agree === false}
                                                                   style={{fontSize: '14px'}}>{t("inbasket.userinstruction.start")}</a></span>}</div>
                                                {/* <div
                                                    className="text-right readytostart_btn">{projectUserMapper.submissionStatus === 'Y' ?
                                                    <Button disabled
                                                            className="next_btn"
                                                            style={{fontSize: '12px'}}>{t("inbasket.userdashboard.completed")}</Button> :
                                                    <Button tag={"a"}
                                                            disabled={!this.state.agree}
                                                            href={`${route_path}/user/inbox/${this.state.pumId_ENCRYPTED}`}
                                                        // title={!this.state.agree ?  : ""}
                                                            id={"instruction-tooltip"}
                                                            className="start_next_btn1 next_btn"
                                                            style={{fontSize: '14px'}}
                                                    >

                                                        {t("inbasket.userinstruction.start")}</Button>}
                                                    <UncontrolledTooltip
                                                        placement={"top"}

                                                        target={"instruction-tooltip"}

                                                    >
                                                        {t("inbasket.instruction.checkbox.tooltip")}
                                                    </UncontrolledTooltip>
                                                </div>*/}

                                            </Col>

                                        </Row>

                                    </CardBody>
                                </Card>

                            </Col>
                        </Row>


                    </Col>

                </Row>

                <WebcamProctor file_id={this.state.pumId_ENCRYPTED}/>


            </div>

        );
    }
}

export default translate("translations")(InbasketUserInstructionView);

