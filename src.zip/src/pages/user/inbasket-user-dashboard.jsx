import React from "react";
import {Col, Row} from "reactstrap";
import {InbasketUserInfoController} from "../../api/inbasket";
import ApiUtils from '../../api/ApiUtils';
import {translate} from "react-i18next";
import conf_prop from "../../properties/properties";
import {removeLocalStorage} from "../../service";
import img from '../../component/inbasket/assets/images/3.jpg'
import LoaderSpinner from "../../views/loader/loader-spinner";

const route_path = conf_prop.get("route_path");

class InbasketUserDashboardView extends React.Component {
    constructor(props) {
        super(props);

        removeLocalStorage();

        const userInfo = ApiUtils.getLocalStorage("userInfo");
        this.state = {
            userInfo: userInfo,
            isLoaded: false,
            userClientMappers: [],

            userClientMapper: {projectUserMappers: []},
            projectUserMapper: {project: {}},


        };

        this.findUserByUserId = this.findUserByUserId.bind(this);

    }


    async findUserByUserId() {
        await InbasketUserInfoController.getUserClient(this.state.userInfo.userId_ENCRYPTED)
            .then(
                result => {

                    this.setState({
                        userClientMappers: result.userClientMappers,
                        isLoaded: true,
                    });


                }).catch(error => {
                    this.setState({
                        isLoaded: true,
                        error: error
                    });
                console.error(error);
                });
    }

    async componentDidMount() {
        removeLocalStorage();
        await this.findUserByUserId(this.state.userInfo.userId_ENCRYPTED);

    }


    render() {
        const {t, i18n} = this.props;
        if (!this.state.isLoaded) {

            return (
                <div className="text-center" style={{marginTop: '15%'}}>
                    <LoaderSpinner/>
                    {/*<h2 className="mb-3">Loading Please Wait ...</h2>*/}
                </div>
            )
        }
        return (
            <div>
                <Row>
                    <Col md={12}>
                        <div><Row>
                            {this.state.userClientMappers.flatMap(x => x.projectUserMappers).map((curprojectUserMapper, index) => (
                                <Col key={index} md={3}>
                                    <div className="next_card " key={index}>

                                        <div className="img_trim">
                                            <img className="next_card_img img-fluid" src={img}/>

                                        </div>
                                        <div className="next_cardbody">
                                            <div
                                                className="next_card_title ">{curprojectUserMapper.project.projectName}</div>

                                            <Row className="mt-3">

                                                <Col md="12" className=" text-right">
                                                    {curprojectUserMapper.submissionStatus === "N" ?
                                                        (curprojectUserMapper.proctorStatus === "N" ?
                                                                (
                                                                    <a
                                                                        href={`${route_path}/user/introduction/` + curprojectUserMapper.pumId_ENCRYPTED}
                                                                        className="next_btn text-white">{t("inbasket.userdashboard.access")}</a>
                                                                ) : (<a
                                                                    href={`${route_path}/user/proctoring/` + curprojectUserMapper.pumId_ENCRYPTED}
                                                                    className="next_btn text-white">{t("inbasket.userdashboard.access")}</a>)
                                                        ) : (
                                                            <a className="next_btn_success text-white">{t("inbasket.userdashboard.completed")}</a>)}
                                                </Col>
                                            </Row>

                                        </div>
                                    </div>

                                </Col>
                            ))}
                        </Row>
                        </div>


                        {/*<Card>*/}
                        {/*    <span className="lstick"></span>*/}
                        {/*    <CardBody>*/}
                        {/*        <h4>{t("inbasket.userdashboard.welcome")} : {this.state.userInfo.name}</h4>*/}

                        {/*    </CardBody>*/}
                        {/*</Card>*/}
                    </Col>

                </Row>
                {/*<Row className="text-center">*/}
                {/*    {this.state.userClientMappers.flatMap(x => x.projectUserMappers).map((curprojectUserMapper, index) => (*/}
                {/*        <Col key={index} md={4}>*/}

                {/*            <Card key={index}>*/}
                {/*                <CardBody>*/}
                {/*                    <h4><strong>{curprojectUserMapper.project.projectName}</strong>*/}
                {/*                    </h4>{curprojectUserMapper.status === "N" ?*/}
                {/*                    (curprojectUserMapper.proctorStatus === "N" ?*/}
                {/*                            (*/}
                {/*                                <Link*/}
                {/*                                    to={`${route_path}/user/instruction/` + curprojectUserMapper.pumId_ENCRYPTED}*/}
                {/*                                    className="btn btn-info btn-sm mt-3">{t("inbasket.userdashboard.access")}</Link>*/}
                {/*                            ) : (<Link*/}
                {/*                                to={`${route_path}/user/proctoring/` + curprojectUserMapper.pumId_ENCRYPTED}*/}
                {/*                                className="btn btn-info btn-sm mt-3">{t("inbasket.userdashboard.access")}</Link>)*/}
                {/*                    ) : (<Button disabled color="success"*/}
                {/*                                 className="btn btn-success btn-sm mt-3">{t("inbasket.userdashboard.completed")}</Button>)}*/}


                {/*                </CardBody>*/}
                {/*            </Card>*/}
                {/*        </Col>*/}
                {/*    ))}*/}

                {/*</Row>*/}

            </div>
        );
    }
}

export default (translate("translations")(InbasketUserDashboardView));
