import React from "react";
import {Col, Row} from "reactstrap";
import {translate} from "react-i18next";
import thankyou from '../../component/inbasket/assets/images/thankyou.png';

import {findProjectUserByPumId, redirectTool} from "../../service";
import {clearTimer} from "../../service/localstorage-service";
import InbasketProjectUserMapperController from "../../api/inbasket/inbasket-projectusermapper-controller";
import conf_prop from "../../properties/properties";


class InbasketThankYou extends React.Component {
    constructor(props) {
        super(props);
        const pumId_ENCRYPTED = props.match.params.pumId_ENCRYPTED;
        // const projectUserMapper = ApiUtils.getLocalStorage("projectUserMapper");
        //
        // const pumId_ENCRYPTED = projectUserMapper.pumId_ENCRYPTED;

        this.state = {
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            projectUserMapper: {},
            template: {},
            timer: 10,
            redirectData: {},
        };
        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.redirectTool = redirectTool.bind(this);
        this.clearTimer = clearTimer.bind(this);
        this.redirectFunction = this.redirectFunction.bind(this);
        this.validatePumById = this.validatePumById.bind(this);
    }


    redirectFunction() {
        const redirectUrl = `${this.state.redirectData.redirectUrl}`;
        window.location = redirectUrl;
    }

    async validatePumById() {
        await InbasketProjectUserMapperController.validateById(this.state.pumId_ENCRYPTED)
            .then(response => {
                console.log(response);
            }).catch(error => {
                console.error(error);
                window.location = `${conf_prop.get("domainUrl")}${conf_prop.get("route_path")}/notification/error-unauthorized`;

            });
    }


    async componentDidMount() {
        await this.validatePumById();
        this.clearTimer();

        await this.redirectTool();
        const redirectUrl = `${this.state.redirectData.redirectUrl}`;
        //console.log(redirectUrl);
        this.interval = setInterval(() => {
            const {timer} = this.state;
            if (timer < 1) {
                clearInterval(this.interval)
                window.location = redirectUrl;
            } else {
                this.setState(prevState => ({
                    timer: prevState.timer - 1
                }));
            }


        }, 1000);
       /* this.interval = setInterval(() => {
            this.setState(prevState => ({
                timer: prevState.timer - 1
            }));
            if (this.state.timer === 0) {
                window.location = redirectUrl;
            }
        }, 1000);*/
    }

    componentWillUnmount() {
        clearInterval(this.interval)
    }


    render() {

        // console.log(this.state.pumId_ENCRYPTED)
        const {t, i18n} = this.props;
        const {template, timer,redirectData} = this.state;
        // const redirectUrl = `${this.state.redirectData.redirectUrl}`;

        return (

            <Row style={{marginTop: '6%'}}>

                <Col>
                    <div className="text-center">

                        <img src={thankyou} alt="homepage" className=" img-fluid"/>
                        <h2 className="text-center"
                            style={{fontWeight: '900'}}>{t("inbasket.thankyoupage.thankyou")}!</h2>
                        <h6 className="text-center">{t("inbasket.thankyoupage.comment")}</h6>
                        {/*<h5 className="mt-3">Redirecting in <span className="text-info">{timer}</span></h5>*/}
                        <h5 className="mt-3" style={{fontWeight: '700'}}>{t("inbasket.thankyoupage.redirectin")} <span
                            style={{color: 'blue', fontSize: '15px'}}>{timer}</span></h5>
                        {/*{!_.isEmpty(this.state.projectUserMapper) && (*/}
                        {/*    (!_.isEmpty(template)&&!_.isNull(template.thankMessage))?*/}
                        {/*    <div className={"m-5"}*/}
                        {/*         dangerouslySetInnerHTML={{__html: template.thankMessage}}/>:<h4 className="text-center" translate="no">{t("inbasket.thankyoupage.thankyoumessage")}</h4>*/}
                        {/*)}*/}
                        {/*<div className="text-center mt-4">Don't want to wait? <span*/}
                        {/*    onClick={this.redirectFunction} className={'text_accent1'} style={{cursor:'pointer'}}>Click here </span>*/}
                        {/*</div>*/}
                        <h6 className="text-center mt-4">{t("inbasket.user.thankyou.wait.msg")}{' '}<a href={redirectData.redirectUrl} className={'text_accent1'}>{t("inbasket.user.thankyou.click.here")} </a></h6>

                        {/*<div>xyz<span onClick={this.redirectFunction}>vfghty</span></div>*/}
                    </div>
                </Col>

            </Row>

        )
    }
}


export default translate("translations")(InbasketThankYou);

