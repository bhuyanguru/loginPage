import _ from "lodash";
import React from "react";
import {Redirect} from 'react-router-dom';
import Select from 'react-select';
import {Card, CardBody, Col, Input, Row} from "reactstrap";
import {InbasketProjectUserMapperResponseController} from "../../../api/inbasket";
import InbasketUserMailResponseUtil
    from "../../../component/inbasket/inbasket-user/inheritance/inbasket-user-mail-response-util";
import {
    InbasketMailLegend,
    InbasketUserInboxTimerView,
    InbasketUserMaterialView,
    InbasketWelcome
} from "../../../views/partials";


import {translate} from "react-i18next";

import queryString from "query-string";
import {findProjectUserByPumId} from "../../../service";
import {WebcamProctor} from "../../../component/utils";
import conf_prop from "../../../properties/properties";
import LoaderSpinner from "../../../views/loader/loader-spinner";
import SunEditor from "suneditor-react";
import 'suneditor/dist/css/suneditor.min.css';
import ButtonWithLoader from "../../../component/utils/button-with-loader";
import {basicSunEditorOptionsWithoutLink} from "../../../config/suneditor-config";

const route_path = conf_prop.get("route_path");

class InbasketUserDraftContaintView extends InbasketUserMailResponseUtil {
    constructor(props) {
        super(props);
        const query = queryString.parse(props.location.search);

        const pumId = query.pum;
        const pumId_ENCRYPTED = query.pum;
        const pumrId = props.match.params.pumrId_ENCRYPTED;
        this.state = {
            pumId: pumId,
            pumId_ENCRYPTED: pumId_ENCRYPTED,

            template: {},
            pumrId: pumrId,
            isLoaded: false,
            projectusermapperDraftresponse: {},
            projectusermapperresponseMailerGroup: [],
            templatemailers: [],
            newResponse: {},
            ccMailers: [],
            toMailers: [],
            bccMailers: [],
            readTime: 0,
            writeTime: 0,
            buttonDisabled: true,
            sendButtonDisabled: true,


        };
        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.projectUserMapperDraftResponseByPumrId = this.projectUserMapperDraftResponseByPumrId.bind(this);

        this.getValidArray = this.getValidArray.bind(this)
    }

    getValidArray(mailers) {

        if (!_.isEmpty(mailers)) {
            const templateMailers = mailers.map(x => {
                const templateMailer = x.templateMailer;

                templateMailer.label = `${templateMailer.mailerName} <${templateMailer.mailerEmail}>`;
                templateMailer.value = templateMailer.mailerId;
                return templateMailer;
            });
            // console.log(mailers);
            return templateMailers;
        } else {
            return [];
        }
        // return _.isEmpty(arr) ? [] : arr;
    }

    //     this.setState({
    //         newResponse: update(this.state.newResponse, { subject: { $set: `${subjectPrefix}: ${this.state.projectusermapperresponse.subject}` },response:{$set:null} })
    // })


    async projectUserMapperDraftResponseByPumrId() {
        await InbasketProjectUserMapperResponseController.getProjectUserMapperResponseBypumrId(this.state.pumrId)
            .then(
                result => {

                    this.setState({
                        isLoaded: true,
                        projectusermapperDraftresponse: result,
                        projectusermapperresponseMailerGroup: _.groupBy(result.projectUserResponseMailerMappers, function (x) {
                            return x.relation;
                        }),

                        newResponse: {subject: result.subject, response: result.response},


                    });

                    this.setState({
                        ccMailers: this.getValidArray(this.state.projectusermapperresponseMailerGroup.CC),
                        toMailers: this.getValidArray(this.state.projectusermapperresponseMailerGroup.TO),
                        bccMailers: this.getValidArray(this.state.projectusermapperresponseMailerGroup.BCC)

                    });

                }).catch(
                error => {
                    this.setState({
                        isLoaded: true,
                        error: error
                    });
                    console.error(error);
                });
    }


    async componentDidMount() {
        await this.findProjectUserByPumId();
        await this.templateMailerBytemplate();
        await this.projectUserMapperDraftResponseByPumrId();
        this.readTimeIntervalId = setInterval(this.setReadTime, 1000);
        this.writeTimeIntervalId = setInterval(this.setWriteTime, 1000);
        this.setState({
            isLoaded: true,
        });

    }


    UNSAFE_componentWillMount() {
        clearInterval(this.readTimeIntervalId);
        clearInterval(this.writeTimeIntervalId);
    }

    render() {
        if (!this.state.isLoaded) {
            // return (
            //     <InbasketLoader/>
            // )

            return (
                <div className="text-center" style={{marginTop: '15%'}}>
                    <LoaderSpinner/>
                    {/*<h2 className="mb-3">Loading Please Wait ...</h2>*/}
                </div>
            )
        }else {
            if (this.state.projectUserMapper.submissionStatus === 'Y') {
                return <Redirect to={`${route_path}/user/thankyou/${this.state.pumId_ENCRYPTED}`}/>

            }
            if (this.state.draftRedirect) {
                return <Redirect to={`/inbasket-user/user/draft/${this.state.pumId_ENCRYPTED}`}/>
            }
            const {t, i18n} = this.props;
            return (
                <div>
                    <InbasketWelcome pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                    <Row>
                        <Col md={12} className="text-right mt-3 mb-3">


                            <InbasketUserInboxTimerView pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}
                                                        projectUserMapper={this.state.projectUserMapper}/>


                        </Col>

                    </Row>
                    <Row>

                        <Col md={3}>


                            <InbasketMailLegend pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                            <InbasketUserMaterialView pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>

                        </Col>
                        <Col md={9}>
                            <Card>
                                <CardBody>


                                    <div classNames="p-3">
                                        <Row className="mb-1">
                                            <Col md={1}>
                                                <div className="text-left"><i
                                                    className="fas fa-reply"></i></div>
                                            </Col>

                                            <Col md={10}></Col>
                                            <Col md={1}>
                                              </Col>

                                        </Row>
                                        <Row>
                                            <Col className="text-right compose-text" md={1}>
                                                <label className="mt-2">{t("inbasket.composemail.to")}</label>
                                            </Col>
                                            <Col md={10}>
                                                <Select
                                                    placeholder={t("inbasket.select.placeholder")}
                                                    value={this.state.toMailers}
                                                    isMulti
                                                    name="mailerName"
                                                    options={this.state.templatemailers}
                                                    className="basic-multi-select"
                                                    classNamePrefix="next_select"
                                                    onChange={(templatemailers) => this.onToMailerchange(templatemailers, "TO")}
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="mt-3">
                                            <Col className="text-right compose-text" md={1}>
                                                <label className="mt-2">{t("inbasket.composemail.cc")}</label>
                                            </Col>
                                            <Col md={10}>
                                                <Select
                                                    value={this.state.ccMailers}
                                                    placeholder={t("inbasket.select.placeholder")}
                                                    isMulti
                                                    name="colors"
                                                    options={this.state.templatemailers}
                                                    className="basic-multi-select"
                                                    classNamePrefix="next_select"
                                                    onChange={(templatemailers) => this.onCcMailerchange(templatemailers, "CC")}
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="mt-3">
                                            <Col className="text-right compose-text" md={1}>
                                                <label className="mt-2">{t("inbasket.composemail.bcc")}</label>
                                            </Col>
                                            <Col md={10}>
                                                <Select
                                                    value={this.state.bccMailers}
                                                    placeholder={t("inbasket.select.placeholder")}
                                                    isMulti
                                                    name="colors"
                                                    options={this.state.templatemailers}
                                                    className="basic-multi-select"
                                                    classNamePrefix="next_select"
                                                    onChange={(templatemailers) => this.onBccMailerchange(templatemailers, "BCC")}
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="mt-3">
                                            <Col className="text-right compose-text" md={1}>
                                                <label className="mt-2">{t("inbasket.composemail.subject")}</label>
                                            </Col>
                                            <Col md={10}>
                                                <Input type="text" className="input-text-next" name="subject"
                                                       value={this.state.newResponse.subject}
                                                       onChange={this.onSubjectChange}></Input>
                                            </Col>
                                        </Row>
                                        <Row className="mt-3">
                                            <Col md={1}>

                                            </Col>
                                            <Col md={10} className={"comment_summernote"}>

                                                <SunEditor

                                                    defaultValue={this.state.newResponse.response}
                                                    // hideToolbar={true}
                                                    setOptions={{
                                                        mode: 'classic',
                                                        height: "200px",
                                                        resizingBar: true,
                                                        showPathLabel: false,
                                                        "buttonList": [basicSunEditorOptionsWithoutLink]
                                                    }}
                                                    onChange={this.onUpdateResponseTextChange}
                                                    onCopy={this.handleCopy}
                                                    onPaste={this.handlePaste}
                                                    // onBlur={(event, editorContents) => this.onNoteBlur(event, editorContents, statement)}
                                                    setDefaultStyle="font-family: Poppins , sans-serif; font-size: 14px;"
                                                />


                                            </Col>
                                        </Row>
                                        <Row className="mt-5 ">
                                            <Col md={1}></Col>
                                            <Col md={10}>



                                                <ButtonWithLoader loading={!this.state.sendButtonDisabled} disabled={!this.state.sendButtonDisabled}
                                                                  onClick={() => this.onSaveResponse("draft", "SENT", "REPLY")}
                                                                  text={t("inbasket.mailsend")}/>
                                            </Col>
                                        </Row>

                                    </div>

                                    <hr></hr>


                                    <WebcamProctor file_id={this.state.pumId_ENCRYPTED}/>

                                </CardBody>
                            </Card>
                        </Col>

                    </Row>

                </div>
            );
        }
    }
}

export default translate("translations")(InbasketUserDraftContaintView);

