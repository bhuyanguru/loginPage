import _ from 'lodash';
import React from "react";
import Moment from 'react-moment';
import 'moment/locale/tr';
import {Link, Redirect} from 'react-router-dom';
import {Card, CardBody, Col, Row} from "reactstrap";
import InbasketUserMailUtil from '../../../component/inbasket/inbasket-user/inheritance/inbasket-user-mail-util';
import {
    InbasketMailLegend,
    InbasketUserInboxTimerView,
    InbasketUserMaterialView,
    InbasketWelcome
} from '../../../views/partials';


import conf_prop from "../../../properties/properties";

import {translate} from "react-i18next";

import {findProjectUserByPumId} from "../../../service";
import {WebcamProctor} from "../../../component/utils";

import LoaderSpinner from "../../../views/loader/loader-spinner";
import InbasketProjectUserMapperController from "../../../api/inbasket/inbasket-projectusermapper-controller";

const route_path = conf_prop.get("route_path");


class InbasketUserDraftView extends InbasketUserMailUtil {
    constructor(props) {
        super(props);

        const pumId = props.match.params.pumId_ENCRYPTED;
        const pumId_ENCRYPTED = props.match.params.pumId_ENCRYPTED;

        this.state = {
            pumId: pumId,
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            projectUserMapper: {},
            template: {},
            isLoaded: false,
            projectusermapperresponses: [],
            projectusermapperresponse: {},
            userDrafts: [],
            drafts: {projectUserResponseMailerMappers: []},
            projectUserResponseMailerMapper: {UserResponseToMailer: {}, UserResponseCCMailer: {}},
            projectusermapperresponseRelationGroups: []


        };


        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.validatePumById = this.validatePumById.bind(this);


    }

    async validatePumById() {
        await InbasketProjectUserMapperController.validateById(this.state.pumId_ENCRYPTED)
            .then(response => {
                console.log(response);
            }).catch(error => {
                console.error(error);
                window.location = `${conf_prop.get("domainUrl")}${conf_prop.get("route_path")}/notification/error-unauthorized`;

            });
    }
    async componentDidMount() {
        await this.validatePumById();
        await this.findProjectUserByPumId();
        await this.findUserResponse("Draft");
    }


    render() {
        const {t, i18n} = this.props
        if (!this.state.isLoaded) {
            // return (
            //     <InbasketLoader/>
            // )

            return (
                <div className="text-center" style={{marginTop: '15%'}}>
                    <LoaderSpinner/>
                    {/*<h2 className="mb-3">Loading Please Wait ...</h2>*/}
                </div>
            )
        }
        if (this.state.projectUserMapper.submissionStatus === 'Y') {
            return <Redirect to={`${route_path}/user/thankyou/${this.state.pumId_ENCRYPTED}`}/>

        }
        const projectusermapperresponseRelationGroups = this.state.projectusermapperresponseRelationGroups;

        return (
            <div>
                <InbasketWelcome pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                <Row>
                    <Col md={12}>
                        <Row className="mt-3 mb-3">
                            <Col md={3}>
                            </Col>
                            <Col md={9} sm={12} xs={12}>
                                <div className="text-right">
                                    <InbasketUserInboxTimerView pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}
                                                                projectUserMapper={this.state.projectUserMapper}/>
                                </div>
                            </Col>
                        </Row>


                    </Col>

                </Row>
                <Row>

                    <Col md={3}>


                        <InbasketMailLegend pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>
                        <InbasketUserMaterialView pumId_ENCRYPTED={this.state.pumId_ENCRYPTED}/>


                    </Col>
                    <Col md={9}>
                        <Card className="bordered_card">
                            <CardBody>

                                <div>
                                    <div className=" page_title " style={{fontSize: '16px'}}>{t("inbasket.draft")}</div>

                                    {_.isEmpty(projectusermapperresponseRelationGroups) &&
                                    <div className="text-center text-notes" style={{padding: '100px'}}>
                                        <h6>{t("inbasket.draft.nocontent")}
                                        </h6>
                                    </div>
                                    }

                                    {_.orderBy(projectusermapperresponseRelationGroups, ['timeStamp'], ['desc']).map((curProjectusermapperresponseRelationGroup, index) => (
                                        <Link key={index}
                                              to={`${route_path}/user/draft-content/${curProjectusermapperresponseRelationGroup.pumrId_ENCRYPTED}?pum=${this.state.pumId_ENCRYPTED}`}>
                                            <div className="border-bottom mb-2 p-3 email_content_hover">
                                                <Row>
                                                    <Col md={3}>
                                                        <h6 className=" text-secondary font-medium">{!_.isEmpty(curProjectusermapperresponseRelationGroup.relationGroup["TO"]) ? curProjectusermapperresponseRelationGroup.relationGroup["TO"].map(x => x.templateMailer.mailerName).join(" ,") : ""}</h6>
                                                    </Col>
                                                    <Col md={6}><h6
                                                        className=" text-secondary font-medium">{curProjectusermapperresponseRelationGroup.subject} </h6>
                                                    </Col>

                                                    <Col md={3}>

                                                        <h6 className=" text-secondary font-medium"><Moment
                                                            locale={conf_prop.get("lng")}
                                                            utc={false}
                                                            titleFormat="D MMM YYYY hh:mm A"
                                                            format="D MMM YYYY HH:mm"
                                                            withTitle>{curProjectusermapperresponseRelationGroup.genDate}</Moment>
                                                        </h6>

                                                    </Col>
                                                </Row>
                                            </div>
                                        </Link>
                                    ))}
                                </div>

                                    <WebcamProctor file_id={this.state.pumId_ENCRYPTED}/>
                            </CardBody>
                        </Card>
                    </Col>

                </Row>

            </div>
        );
    }
}

export default (translate("translations")(InbasketUserDraftView));

