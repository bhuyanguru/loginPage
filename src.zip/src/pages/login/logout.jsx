import React, {useEffect} from "react";
import Cookies from 'universal-cookie';
import conf_prop from "../../properties/properties";
import LoaderSpinner from "../../views/loader/loader-spinner";


function LogoutView(props) {


    function handleCookie() {
        const cookies = new Cookies();
        let allCookies = cookies.getAll();

        Object.entries(allCookies).forEach(([key, value]) => {

            cookies.remove(key, {path: '/'});

        });


    }

    useEffect(() => {
        localStorage.clear();
        sessionStorage.clear();
        handleCookie();
        window.location.replace(`${conf_prop.get("oauthServiceUrl")}/logout`);
    }, []);


    return (
        <div style={{marginTop: '15%'}}><LoaderSpinner/></div>
    );

}

export default LogoutView;
