import React, {useEffect} from "react";

import queryString from 'query-string';
import ApiUtils from "../../api/ApiUtils";
import {OauthController, UserInfoController} from "../../api/controller";
import conf_prop from '../../properties/properties';
import jwtDecode from 'jwt-decode';
import LoaderSpinner from "../../views/loader/loader-spinner";

const route_path = conf_prop.get("route_path");

function UserAuthorizedView(props) {


    const params = queryString.parse(props.location.search);


    function handleAccessTokenChange(accessToken) {
        ApiUtils.setCookie('accessToken', accessToken);

    }

    function find_user_info(userInfo) {
        UserInfoController.validata_user_email(userInfo).then(
            userInfo => {

                ApiUtils.setLocalStorage("userInfo", userInfo);
                ApiUtils.setLocalStorage("userClientMapper", userInfo.lastActiveUserClientMapper);


                props.history.push(`${route_path}/user/dashboard`);


            }
        ).catch(error => {
            console.error(error);
        });
    }


    function find_oauth_token_claim() {
        const oauth_config = conf_prop.get("oauth_config");
        // let params = queryString.parse(this.props.location.search);
        // console.log(params);
        OauthController.get_token_claim(params.code, oauth_config.redirect_uri).then(
            claim => {
                const id_token = claim.id_token;
                // console.log("tokenData", tokenData);

                handleAccessTokenChange(claim.bearer_token);
                const tokenJson = jwtDecode(id_token);
                // console.log("tokenJson", tokenJson);
                find_user_info(claim);
            }
        ).catch(error => {
            console.error(error);
        });
    }

    useEffect(() => {
        const params = queryString.parse(props.location.search);
        if (params.error === "access_denied") {
            props.history.push(`${route_path}/login/user`)
        }
        find_oauth_token_claim();
    }, []);


    return (
        <div style={{marginTop: '15%'}}><LoaderSpinner/></div>
    );

}

export default UserAuthorizedView;
