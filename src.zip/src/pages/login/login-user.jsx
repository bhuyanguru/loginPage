import React, {useEffect} from "react";
import conf_prop from "../../properties/properties";
import {translate} from "react-i18next";
import LoaderSpinner from "../../views/loader/loader-spinner";


function LoginUser(props) {


    useEffect(() => {
        localStorage.clear();

        const loginUrl = conf_prop.get("authorize_endpoint");


        window.location.replace(loginUrl);
    }, []);


    return (

        <div style={{marginTop: '15%'}}><LoaderSpinner/></div>
    );

}

export default (translate("translations")(LoginUser));

