'use strict';
const TerserPlugin = require('terser-webpack-plugin');
module.exports = {
    mode: 'production',
    optimization: {
        minimizer: [new TerserPlugin({ /* additional options here */})],
    },
    module: {
        rules: [{
            test: /\.jsx$|\.js$/,
            exclude: /node_modules|web_modules/,
            use: [{
                loader: 'babel-loader',
                query: {
                    presets: ['es2015', 'react']
                }
            }]
        }],

        plugins: [
            new UglifyJSPlugin(),
            // new TerserPlugin({ /* additional options here */ },
            new webpack.ProvidePlugin({
                $: "jquery",
                jQuery: "jquery"
            })
        ]
    }
};
