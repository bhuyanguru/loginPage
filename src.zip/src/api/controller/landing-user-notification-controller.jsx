import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties';
import "whatwg-fetch";

const NotificationController = {

    findById: function (unId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("landingServiceUrl")}/rest/notification/id/${unId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

            })
        }).then(ApiUtils.checkStatus);
    },

    findByUcmId: function (ucmId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("landingServiceUrl")}/rest/notification/userclientmapper/${ucmId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

            })
        }).then(ApiUtils.checkStatus);
    },

    findCountByUcm: function (ucmId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("landingServiceUrl")}/rest/notification/count-by-ucm/${ucmId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

            })
        }).then(ApiUtils.checkStatus);
    },

    updateNotificationReadTimeStamp: function (ucmId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("landingServiceUrl")}/rest/notification/update/${ucmId}`, {
            method: "post",

            // body: JSON.stringify(Notification),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

                // 'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },
};

export default NotificationController;