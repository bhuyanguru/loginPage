import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties';
import "whatwg-fetch";

const MasterAccessListController = {


    findAll: function () {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("nextServiceUrl")}/rest/masteraccesslist/all`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

            })
        }).then(ApiUtils.checkStatus);
    },

    findById: function (accessId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("nextServiceUrl")}/rest/masteraccesslist/id/${accessId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

            })
        }).then(ApiUtils.checkStatus);
    },

    insertMasterAccessList: function (MasterAccessList) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("nextServiceUrl")}/rest/masteraccesslist/insert`, {
            method: "post",

            body: JSON.stringify(MasterAccessList),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    updateMasterAccessList: function (MasterAccessList) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("nextServiceUrl")}/rest/masteraccesslist/update`, {
            method: "post",

            body: JSON.stringify(MasterAccessList),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    findByTool: function (toolId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("nextServiceUrl")}/rest/masteraccesslist/tool/${toolId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

            })
        }).then(ApiUtils.checkStatus);
    },

};

export default MasterAccessListController;
