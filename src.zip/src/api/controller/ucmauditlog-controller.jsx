import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties';
import "whatwg-fetch";

const UcmAuditLogController = {


  findAll: function() {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/ucmauditlog/all`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

  findByAdmin: function(adminId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/ucmauditlog/admin/${adminId}`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

  findById: function(auditId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/ucmauditlog/id/${auditId}`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

  updateUcmAuditLog: function(UcmAuditLog) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/ucmauditlog/update`, {
      method: "post",

      body: JSON.stringify(UcmAuditLog),

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

         'Content-Type': 'application/json'

      })
    }).then(ApiUtils.checkStatus);
  },

  insertUcmAuditLog: function(UcmAuditLog) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/ucmauditlog/insert`, {
      method: "post",

      body: JSON.stringify(UcmAuditLog),

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

         'Content-Type': 'application/json'

      })
    }).then(ApiUtils.checkStatus);
  },

  findByClientAdmin: function(clientAdminId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/ucmauditlog/clientadmin/${clientAdminId}`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

  findByUserClientMapper: function(ucmId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/ucmauditlog/userclientmapper/${ucmId}`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

};

export default UcmAuditLogController;
