import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties';
import "whatwg-fetch";

const LoginController = {


  welcome: function() {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

};

export default LoginController;
