import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties'

const NavigationController = {


    findByUserClientMapper: function (ucmId_ENCRYPTED) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("nextServiceUrl")}/rest/navigation/user-client-mapper/${ucmId_ENCRYPTED}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

            })
        }).then(ApiUtils.checkStatus);
    },


};

export default NavigationController;