import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties';
import "whatwg-fetch";
import {JwtUtil} from "@devopsthink/react-security-util";


const UserInfoController = {


  findAll: function() {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userinfo/all`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

  findById: function(userId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userinfo/id/${userId}`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

  insertUserInfo: function(UserInfo) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userinfo/insert`, {
      method: "post",

      body: JSON.stringify(UserInfo),

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

         'Content-Type': 'application/json'

      })
    }).then(ApiUtils.checkStatus);
  },

  updateUserInfo: function(UserInfo) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userinfo/update`, {
      method: "post",

      body: JSON.stringify(UserInfo),

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

         'Content-Type': 'application/json'

      })
    }).then(ApiUtils.checkStatus);
  },

  validata_user_email: function(UserInfo) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userinfo/validate-user-email`, {
      method: "post",

      body: JSON.stringify(UserInfo),

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

         'Content-Type': 'application/json'

      })
    }).then(ApiUtils.checkStatus).then(res=> JSON.parse(JwtUtil.decompressFflate(res.payload)));
  },

  updateLastUcmId: function (ucmId) {
    const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userinfo/update-last-active/${ucmId}`, {
      method: "post",

      // body: JSON.stringify(UserInfo),

      headers: new Headers({
        Authorization: `Bearer ${access_token}`,

        // 'Content-Type': 'application/json'

      })
    }).then(ApiUtils.checkStatus);
  },

};

export default UserInfoController;
