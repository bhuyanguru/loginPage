import conf_prop from '../../properties/properties';
import "whatwg-fetch";
import ApiUtils from "../../api/ApiUtils";


const OauthController = {


    access_token: function (code) {
        const oauth_config = conf_prop.get("oauth_config");
        let params = {
            "grant_type": "authorization_code",
            "client_id": oauth_config.clientId,
            "redirect_uri": oauth_config.redirect_uri,
            "client_secret": oauth_config.clientSecret,
            "code": code
        };
        const query_params = ApiUtils.queryString(params);
        return fetch(`${conf_prop.get("oauthServiceUrl")}/oauth/token?${query_params}`, {
            method: "get",

            headers: new Headers({
                Authorization: "Bearer fake-jwt-token",
                "Accept": "application/x-www-form-urlencoded"

            })
        }).then(ApiUtils.checkStatus);
    },

    refresh_token: function (redirect_uri) {
        const oauth_config = conf_prop.get("oauth_config");
        let params = {
            "grant_type": "refresh_token",
            "client_id": oauth_config.clientId,
            "redirect_uri": redirect_uri,
            "client_secret": oauth_config.clientSecret,
            "refresh_token": ApiUtils.getCookie("accessToken").refresh_token
        };
        const query_params = ApiUtils.queryString(params);
        return fetch(`${conf_prop.get("oauthServiceUrl")}/oauth/token?${query_params}`, {
            method: "get",

            headers: new Headers({
                Authorization: "Bearer fake-jwt-token",
                "Accept": "application/x-www-form-urlencoded"

            })
        }).then(ApiUtils.checkStatus);
    },

    email_api: function () {
        const access_token = ApiUtils.getCookie("accessToken");
        return fetch(`${conf_prop.get("oauthServiceUrl")}/api/email`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

            })
        }).then(ApiUtils.checkStatus);
    },

    get_token_claim: function (code, redirect_uri) {
        const oauth_config = conf_prop.get("oauth_config");
        //console.log(oauth_config);

        let params = {
            "grant_type": "authorization_code",
            "client_id": oauth_config.clientId,
            "redirect_uri": redirect_uri,
            "client_secret": oauth_config.clientSecret,
            "code": code
        };

        return fetch(`${conf_prop.get("oauthServiceUrl")}/login-code-claim/${oauth_config.clientId}`, {
            method: "post",
            body: JSON.stringify(params),
            headers: new Headers({
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },
    update_token: function (params) {
        return fetch(`${conf_prop.get("oauthServiceUrl")}/update-token`, {
            method: "post",
            body: JSON.stringify(params),
            headers: new Headers({
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

};


export default OauthController;


