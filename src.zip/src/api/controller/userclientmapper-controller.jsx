import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties';
import "whatwg-fetch";

const UserClientMapperController = {


  findAll: function() {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userclientmapper/all`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

  findById: function(ucmId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userclientmapper/id/${ucmId}`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

  insertUserClientMapper: function(UserClientMapper) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userclientmapper/insert`, {
      method: "post",

      body: JSON.stringify(UserClientMapper),

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

         'Content-Type': 'application/json'

      })
    }).then(ApiUtils.checkStatus);
  },

  updateUserClientMapper: function(UserClientMapper) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userclientmapper/update`, {
      method: "post",

      body: JSON.stringify(UserClientMapper),

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

         'Content-Type': 'application/json'

      })
    }).then(ApiUtils.checkStatus);
  },

  findByUserInfo: function(userId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userclientmapper/userinfo/${userId}`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

  findByClient: function(clientId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userclientmapper/client/${clientId}`, {
      method: "get",

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

      })
    }).then(ApiUtils.checkStatus);
  },

  userMailingService: function(UserClientMapper) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("nextServiceUrl")}/rest/userclientmapper/user/send-email`, {
      method: "post",

      body: JSON.stringify(UserClientMapper),

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

         'Content-Type': 'application/json'

      })
    }).then(ApiUtils.checkStatus);
  },

};

export default UserClientMapperController;
