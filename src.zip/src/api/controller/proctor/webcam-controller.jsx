import ApiUtils from '../../ApiUtils';
import conf_prop from '../../../properties/properties';
import "whatwg-fetch";

const WebcamController = {

  insertProctorImage: function(image_data) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("proctorServiceUrl")}/webcam/insert`, {
      method: "post",

      body: JSON.stringify(image_data),

      headers: new Headers({
         Authorization: `Bearer ${access_token}`,

         'Content-Type': 'application/json'

      })
    }).then(ApiUtils.checkStatus);
  },



};

export default WebcamController;
