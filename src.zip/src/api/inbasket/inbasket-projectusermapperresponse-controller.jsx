import ApiUtils, {encodeApiJwtString} from '../ApiUtils';
import conf_prop from '../../properties/properties'

const InbasketProjectUserMapperResponseController = {


    getProjectUserMapperResponse: function (pumId, responseType) {
        const access_token = ApiUtils.getCookie("accessToken");

        let params = {
            "responseType": responseType,
        };
        const query_params = ApiUtils.queryString(params);

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/project-user-mapper-response/pum/${pumId}?${query_params}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    getProjectUserMapperResponseCount: function (pumId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/project-user-mapper-response/pum/response/count/${pumId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    getProjectUserMapperResponseBypumrId: function (pumrId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/project-user-mapper-response/${pumrId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    insertProjectUserMapperResponse: function (ProjectUserMapperResponse) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/project-user-mapper-response/insert`, {
            method: "post",

            body: encodeApiJwtString({payload:JSON.stringify(ProjectUserMapperResponse)}),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    updateProjectUserMapperResponse: function (ProjectUserMapperResponse) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/project-user-mapper-response/update`, {
            method: "post",

            body: encodeApiJwtString({payload:JSON.stringify(ProjectUserMapperResponse)}),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

};

export default InbasketProjectUserMapperResponseController;
