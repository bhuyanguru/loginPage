import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties'

var ProjectUserMapperContentReadController = {


  findAll: function() {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermappercontentread/all`, {
      method: "get",
      
      headers: new Headers({
         Authorization: `Bearer ${access_token}`,
        'Content-Type': 'application/json'
        
      })
    }).then(ApiUtils.checkStatus);
  },

  findById: function(pcrId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermappercontentread/id/${pcrId}`, {
      method: "get",
      
      headers: new Headers({
         Authorization: `Bearer ${access_token}`,
        'Content-Type': 'application/json'
        
      })
    }).then(ApiUtils.checkStatus);
  },

  insertProjectUserMapperContentRead: function(ProjectUserMapperContentRead) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermappercontentread/insert`, {
      method: "post",
      
      body: JSON.stringify(ProjectUserMapperContentRead),
      
      headers: new Headers({
         Authorization: `Bearer ${access_token}`,
        
         'Content-Type': 'application/json'
        
      })
    }).then(ApiUtils.checkStatus);
  },

  updateProjectUserMapperContentRead: function(ProjectUserMapperContentRead) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermappercontentread/update`, {
      method: "post",
      
      body: JSON.stringify(ProjectUserMapperContentRead),
      
      headers: new Headers({
         Authorization: `Bearer ${access_token}`,
        
         'Content-Type': 'application/json'
        
      })
    }).then(ApiUtils.checkStatus);
  },

  findByProjectUserMapper: function(pumId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermappercontentread/projectusermapper/${pumId}`, {
      method: "get",
      
      headers: new Headers({
         Authorization: `Bearer ${access_token}`,
        'Content-Type': 'application/json'
        
      })
    }).then(ApiUtils.checkStatus);
  },

  findByTemplateContent: function(templateContentId) {
  const access_token = ApiUtils.getCookie("accessToken");

    return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermappercontentread/templatecontent/${templateContentId}`, {
      method: "get",
      
      headers: new Headers({
         Authorization: `Bearer ${access_token}`,
        'Content-Type': 'application/json'
        
      })
    }).then(ApiUtils.checkStatus);
  },

};

export default ProjectUserMapperContentReadController;