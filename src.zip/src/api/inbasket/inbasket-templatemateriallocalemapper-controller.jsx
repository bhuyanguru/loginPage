import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties'

const InbasketTemplateMaterialLocaleMapperController = {


    findAll: function () {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/templatemateriallocalemapper/all`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    findById: function (tmlmId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/templatemateriallocalemapper/id/${tmlmId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    insertTemplateMaterialLocaleMapper: function (TemplateMaterialLocaleMapper) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/templatemateriallocalemapper/insert`, {
            method: "post",

            body: JSON.stringify(TemplateMaterialLocaleMapper),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    updateTemplateMaterialLocaleMapper: function (TemplateMaterialLocaleMapper) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/templatemateriallocalemapper/update`, {
            method: "post",

            body: JSON.stringify(TemplateMaterialLocaleMapper),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    findByLocale: function (languageId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/templatemateriallocalemapper/locale/${languageId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    findByTemplateMaterial: function (materialId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/templatemateriallocalemapper/templatematerial/${materialId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

};

export default InbasketTemplateMaterialLocaleMapperController;
