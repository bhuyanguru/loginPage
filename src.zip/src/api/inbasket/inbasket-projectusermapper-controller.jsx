import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties'

const InbasketProjectUserMapperController = {


    getProjectUserMapper: function (cumId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/user/${cumId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    getUsers: function (projectId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/project/${projectId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    getInstructionTimer: function (pumId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/instructiontimer/${pumId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    validateById: function (pumId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/validate-id/${pumId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

            })
        }).then(ApiUtils.checkStatus);
    },

    getIntegrationRedirect: function (pumId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/integration-redirect/${pumId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },
    getPumContentReadCount: function (pumId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/pumcontentcount/${pumId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    getInboxTimer: function (pumId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/mailtimer/${pumId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    insertProjectUserMapper: function (ProjectUserMapper) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/insert`, {
            method: "post",

            body: JSON.stringify(ProjectUserMapper),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    insertPums: function (ProjectUserMapper) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/insert-bulk`, {
            method: "post",

            body: JSON.stringify(ProjectUserMapper),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    updateProjectUserMapperStatus: function (ProjectUserMapper) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/status-update`, {
            method: "post",

            body: JSON.stringify(ProjectUserMapper),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    userMailingService: function (ProjectUserMapper) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/user/send-email`, {
            method: "post",

            body: JSON.stringify(ProjectUserMapper),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    saveUserImage: function (webcamRecord) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/user/savephoto`, {
            method: "post",

            body: JSON.stringify(webcamRecord),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    getProjectClient: function (pumId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/id/${pumId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },
    getIntegrationProctoring: function (pumId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/projectusermapper/integration-proctoring/${pumId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

};

export default InbasketProjectUserMapperController;
