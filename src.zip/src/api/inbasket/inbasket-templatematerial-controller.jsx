import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties'

const InbasketTemplateMaterialController = {


    getTemplateMaterial: function (tempId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/template-material/template/${tempId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    insertTemplateMaterial: function (TemplateMaterial) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/template-material/insert`, {
            method: "post",

            body: JSON.stringify(TemplateMaterial),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },
    updateTemplateMaterialorder: function(TemplateMaterial) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/template-material/update/materialorder`, {
            method: "post",

            body:JSON.stringify(TemplateMaterial),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

};

export default InbasketTemplateMaterialController;
