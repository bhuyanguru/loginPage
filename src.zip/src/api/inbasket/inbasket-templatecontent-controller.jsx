import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties'

const InbasketTemplateContentController = {


    getTemplateContent: function (tempId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/template-content/template/${tempId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    getTemplateContentByContaintId: function (tempContaintId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/template-content/${tempContaintId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

};

export default InbasketTemplateContentController;
