import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties'

const InbasketTemplateInstructionLocaleController = {


    findAll: function () {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/templateinstructionlocale/all`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    findById: function (tempinstLocaleId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/templateinstructionlocale/id/${tempinstLocaleId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    insertTemplateInstructionLocale: function (TemplateInstructionLocale) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/templateinstructionlocale/insert`, {
            method: "post",

            body: JSON.stringify(TemplateInstructionLocale),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    updateTemplateInstructionLocale: function (TemplateInstructionLocale) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/templateinstructionlocale/update`, {
            method: "post",

            body: JSON.stringify(TemplateInstructionLocale),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

};

export default InbasketTemplateInstructionLocaleController;
