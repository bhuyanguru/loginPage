import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties'

const InbasketPumBrowserTrackController = {


    insertPumBrowserTrack: function (ProjectUserTimeBackUp) {
        const access_token = ApiUtils.getCookie("accessToken");
        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/pum-browser-track/insert`, {
            method: "post",

            body: JSON.stringify(ProjectUserTimeBackUp),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    findByProjectUserMapper: function (pumId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/pum-browser-track/pum/${pumId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,

            })
        }).then(ApiUtils.checkStatus);
    },


};

export default InbasketPumBrowserTrackController;
