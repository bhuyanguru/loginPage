import ApiUtils from '../ApiUtils';
import conf_prop from '../../properties/properties'

const InbasketLocaleController = {


    findAll: function () {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/locale/all`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    findById: function (languageId) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/locale/id/${languageId}`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

    insertLocale: function (Locale) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/locale/insert`, {
            method: "post",

            body: JSON.stringify(Locale),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    updateLocale: function (Locale) {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/locale/update`, {
            method: "post",

            body: JSON.stringify(Locale),

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'


            })
        }).then(ApiUtils.checkStatus);
    },

    findLanguage: function () {
        const access_token = ApiUtils.getCookie("accessToken");

        return fetch(`${conf_prop.get("inbasketServiceUrl")}/rest/locale/selected/language`, {
            method: "get",

            headers: new Headers({
                Authorization: `Bearer ${access_token}`,
                'Content-Type': 'application/json'

            })
        }).then(ApiUtils.checkStatus);
    },

};

export default InbasketLocaleController;
