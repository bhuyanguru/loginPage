import "whatwg-fetch";
import {obfuscate} from "javascript-obfuscator";
import jwt from "jwt-simple";

import SecureLS from "secure-ls";

const secret = "ThinkLocalStorage@13972684";
const apiJwtSecret = "thinktalentnext";
const secureStorage = new SecureLS({encodingType: 'aes', encryptionSecret: secret});


export function secureCode(code) {
    return obfuscate(
        code,
        {
            compact: true,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 1,
            numbersToExpressions: true,
            simplify: true,
            shuffleStringArray: true,
            splitStrings: true,
            stringArrayThreshold: 1
        }
    );

}

export function encodeJwtString(jsonObject) {
    return jwt.encode(jsonObject, secret);
}

export function encodeApiJwtString(jsonObject) {
    return jwt.encode(jsonObject, apiJwtSecret);
}

export function decodeJwtString(string) {
    return jwt.decode(string, secret);
}

const ApiUtils = {
    checkStatus: async function (response) {
        let responseJson;
        const contentType = response.headers.get('content-type');

        // Check if the response content type is JSON before parsing
        if (contentType && contentType.includes('application/json')) {
            responseJson = await response.json();
        } else {
            responseJson = await response.text();
        }

        return new Promise((resolve, reject) => {
            if (response.ok) {
                resolve(responseJson);
            } else {
                let error = new Error(response.statusText);
                error.response = response;
                error.responseJson = responseJson;

                // Check specifically for a 403 Forbidden error
                if (response.status === 403) {
                    error.message = 'Access Denied';
                }

                reject(error);
            }
        });
    },
    checkResponse: function (response) {


        if (response.ok) {
            return response;
        } else {

            let error = new Error(response.statusText);
            error.response = response;
            throw error;
        }
    },
    queryString: function (params) {
        return Object.entries(params).map(([key, value]) => {
            return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
        }).join('&');
    },

    getCookie: function (cookieName) {

        try {
            return secureStorage.get(cookieName);
        } catch (err) {
            return null;
        }


    },
    setCookie: function (cookieName, cookieVal) {

        secureStorage.set(cookieName, cookieVal);
    },
    getLocalStorage: function (cookieName) {
        try {
            return secureStorage.get(cookieName);
        } catch (err) {
            return null;
        }

    },
    setLocalStorage: function (cookieName, cookieVal) {
        // const cookieVar = jwt.encode(cookieVal, secret);
        secureStorage.set(cookieName, cookieVal);
    }
};

export default ApiUtils;
