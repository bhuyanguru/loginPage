const aesjs = require('aes-js');


const key = [84, 104, 101, 66, 101, 115, 116, 83, 101, 99, 114, 101, 116, 75, 101, 121];//"TheBestSecretKey";
const key_final = [66, 97, 112, 97, 114, 97, 83, 97, 109, 112, 97, 116, 105, 78, 117, 97];//"BaparaSampatiNua";
const aes = new aesjs.AES(key);
const aes_final = new aesjs.AES(key_final);

const AESEncryption = {};

AESEncryption.decrypt_raw = function (encryptedHex, aes) {
    const encryptedBytes = aesjs.utils.hex.toBytes(encryptedHex);
    const decryptedBytes = aes.decrypt(encryptedBytes);
    // console.log(decryptedBytes);
    const decryptedText = aesjs.utils.utf8.fromBytes(decryptedBytes);
    // console.log(decryptedText);
    return decryptedText.trim();
};


AESEncryption.encrypt = function (text) {
    const textAsBytes = aesjs.utils.utf8.toBytes(text);
    // console.log(textAsBytes);
    const encryptedBytes = aes_final.encrypt(textAsBytes);
    // console.log(encryptedBytes);
    const encryptedHex = aesjs.utils.hex.fromBytes(encryptedBytes);
    // console.log(encryptedHex);
    return encryptedHex;
};


AESEncryption.decrypt = function (encryptedHex) {
    try {
        return AESEncryption.decrypt_raw(encryptedHex, aes_final).trim();
    } catch (error) {
        return AESEncryption.decrypt_raw(encryptedHex, aes).trim();
    }
};

// var hw = AESEncryption.decrypt("0BF5B2AF53FC8DCC5EC0A97670F37089");
// console.log(hw);
// outputs hello world
// console.log(AESEncryption.encrypt(hw));

export default AESEncryption;
