import properties from '../js/properties'

let conf = new Map();

let conf_prop = new Map([...conf, ...properties]);


conf_prop.set("route_path", `/inbasket-user`);


const oauth_config = {
    endpoint: conf_prop.get("oauthServiceUrl"),
    baseUrl: conf_prop.get("oauthServiceUrl") + "/api",
    clientId: "next",
    clientSecret: "next",
    redirect_uri: `${conf_prop.get("domainUrl")}${conf_prop.get("route_path")}/login/user-authorized`,

    authorizePath: '/oauth/authorize',
    tokenPath: '/oauth/token',
    revokePath: '/oauth/revoke'
};
conf_prop.set("oauth_config", oauth_config);
conf_prop.set("proctor_path", "proctor/INBASKET");


// conf_prop.set("port", 3006);
conf_prop.set("authorize_endpoint", conf_prop.get("oauthServiceUrl") + oauth_config.authorizePath + "?response_type=code&client_id=" + oauth_config.clientId + "&redirect_uri=" + oauth_config.redirect_uri + "&scope=email&USER_TYPE=USER");

conf_prop.set("cdn_path", "https://cdn.thinktalentws48.click");
export default conf_prop;
