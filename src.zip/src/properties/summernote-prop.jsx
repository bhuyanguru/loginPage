const summerprop = {
    with_toolbar: {
        placeholder: "Please share what's on your mind",
        lang: 'en-EN',
        height: 70,
        dialogsInBody: true,
        popover: {
            image: [],
            link: [],
            air: []
        },
        toolbar: [

            ['font', ['bold', 'italic', 'underline']],

            ['para', ['ul', 'ol', 'paragraph']],

            ['insert', ['link']],

        ]
    },
    without_toolbar: {
        placeholder: "Please share what's on your mind",
        lang: 'en-EN',
        height: 70,
        dialogsInBody: true,
        popover: {
            image: [],
            link: [],
            air: []
        },
        toolbar: false
    }
};

export default summerprop;
