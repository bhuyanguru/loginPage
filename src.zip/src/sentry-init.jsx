import * as Sentry from "@sentry/react";
import conf_prop from "./properties/properties";
import {Integrations} from "@sentry/tracing";
import {
    CaptureConsole as CaptureConsoleIntegration,
    Dedupe as DedupeIntegration,
    ExtraErrorData as ExtraErrorDataIntegration,
    ReportingObserver as ReportingObserverIntegration
} from "@sentry/integrations";
import SentryRRWeb from "@sentry/rrweb";
import {history} from "./jwt/_helpers";

export function sentryInit() {
    Sentry.init({
        dsn: conf_prop.get("sentry_dsn"),
        integrations: [
            new Integrations.BrowserTracing({
                routingInstrumentation: Sentry.reactRouterV5Instrumentation(history),
            }),
            new DedupeIntegration(),
            new ExtraErrorDataIntegration(
                {
                    // Limit of how deep the object serializer should go. Anything deeper than limit will
                    // be replaced with standard Node.js REPL notation of [Object], [Array], [Function] or
                    // a primitive value. Defaults to 3.
                    // When changing this value, make sure to update `normalizeDepth` of the whole SDK
                    // to `depth + 1` in order to get it serialized properly - https://docs.sentry.io/platforms/javascript/configuration/options/#normalize-depth
                    depth: 3
                }
            ),
            new CaptureConsoleIntegration(
                {
                    // array of methods that should be captured
                    // defaults to ['log', 'info', 'warn', 'error', 'debug', 'assert']
                    levels: ['error']
                }
            ),
            new ReportingObserverIntegration(
                {
                    types: ['crash', 'deprecation', 'intervention']
                }
            ),
            new SentryRRWeb({
                // ...options
            })
        ],

        // Set tracesSampleRate to 1.0 to capture 100%
        // of transactions for performance monitoring.
        // We recommend adjusting this value in production
        tracesSampleRate: 0.1,
        environment: conf_prop.get("ENV"),
        release: conf_prop.get("sentry_release"),
    });
}
