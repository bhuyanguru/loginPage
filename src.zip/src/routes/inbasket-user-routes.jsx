import {lazy} from "react";
import Loadable from "../layouts/loader/Loadable";
import conf_prop from "../properties/properties";

const InbasketUserProctoringView = Loadable(lazy(() => import("../pages/user/inbasket-user-proctoring")));

const InbasketUserDashboardView = Loadable(lazy(() => import("../pages/user/inbasket-user-dashboard")));
const InbasketUserIntroductionsView = Loadable(lazy(() => import("../pages/user/inbasket-user-introduction")));
const InbasketUserInstructionView = Loadable(lazy(() => import("../pages/user/inbasket-user-instruction")));
const InbasketUserInboxView = Loadable(lazy(() => import("../pages/user/inbox/inbasket-user-inbox")));
const InbasketUserDraftView = Loadable(lazy(() => import("../pages/user/draft/inbasket-user-draft")));
const InbasketUserComposeView = Loadable(lazy(() => import("../pages/user/inbasket-user-compose")));
const InbasketUserSentMailView = Loadable(lazy(() => import("../pages/user/sent/inbasket-user-sent-mail")));
const InbasketUserInboxContaintView = Loadable(lazy(() => import("../pages/user/inbox/inbasket-user-inbox-content")));
const InbasketUserDraftContaintView = Loadable(lazy(() => import("../pages/user/draft/inbasket-user-draft-content")));
const InbasketUserSentContaintView = Loadable(lazy(() => import("../pages/user/sent/inbasket-user-sent-content")));
const InbasketThankYou = Loadable(lazy(() => import("../pages/user/inbasket-user-thankyou")));


const route_path = conf_prop.get("route_path");
var InbasketUserRoutes = [

    {
        path: `${route_path}/user/dashboard`,
        name: 'Dashboard',
        icon: '',
        component: InbasketUserDashboardView,
        sidebar: true
    },

    {
        path: `${route_path}/user/proctoring/:pumId_ENCRYPTED`,
        name: 'Dashboard',
        icon: '',
        component: InbasketUserProctoringView,
        sidebar: false
    },

    {
        path: `${route_path}/user/introduction/:pumId_ENCRYPTED`,
        name: 'introduction',
        icon: '',
        component: InbasketUserIntroductionsView,
        sidebar: false
    },
    {
        path: `${route_path}/user/instruction/:pumId_ENCRYPTED`,
        name: 'instruction',
        icon: '',
        component: InbasketUserInstructionView,
        sidebar: false
    },

    {
        path: `${route_path}/user/inbox/:pumId_ENCRYPTED`,
        name: 'UserInboxView',
        icon: '',
        component: InbasketUserInboxView,
        sidebar: false
    },
    {
        path: `${route_path}/user/draft/:pumId_ENCRYPTED`,
        name: 'UserDraftView',
        icon: '',
        component: InbasketUserDraftView,
        sidebar: false
    },
    {
        path: `${route_path}/user/sent/:pumId_ENCRYPTED`,
        name: 'UserSentMailView',
        icon: '',
        component: InbasketUserSentMailView,
        sidebar: false
    },
    {
        path: `${route_path}/user/compose/:pumId_ENCRYPTED`,
        name: 'UserComposeView',
        icon: '',
        component: InbasketUserComposeView,
        sidebar: false
    },
    {
        path: `${route_path}/user/inbox-content/:templateContentId_ENCRYPTED`,
        name: 'UserInboxContaintView',
        icon: '',
        component: InbasketUserInboxContaintView,
        sidebar: false
    },
    {
        path: `${route_path}/user/draft-content/:pumrId_ENCRYPTED`,
        name: 'UserDraftContaintView',
        icon: '',
        component: InbasketUserDraftContaintView,
        sidebar: false
    },
    {
        path: `${route_path}/user/sent-content/:pumrId_ENCRYPTED`,
        name: 'UserSentContaintView',
        icon: '',
        component: InbasketUserSentContaintView,
        sidebar: false
    },
    {
        path: `${route_path}/user/thankyou/:pumId_ENCRYPTED`,
        name: 'ThankYou',
        icon: '',
        component: InbasketThankYou,
        sidebar: false
    },

];

export default InbasketUserRoutes;
