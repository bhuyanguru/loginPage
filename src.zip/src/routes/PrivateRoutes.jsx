import React from 'react';
import {Route} from 'react-router-dom';
import AppUtils from "../api/ApiUtils";
import {update_bearer_token} from "../utils/bearer_token_util";
import conf_prop from "../properties/properties";
import _ from 'lodash'


export const PrivateRoute = ({component: Component, ...rest}) => (
    <Route {...rest} render={props => {
        const accessToken = AppUtils.getCookie("accessToken");
        const url = props.location.pathname;

        if (url.includes('/user/')) {
            update_bearer_token();
        }

        if (url.includes('/user/') && _.isEmpty(accessToken)) {
            //     // not logged in so redirect to login page with the return url
            // return <Redirect
            //     to={{pathname: `${conf_prop.get("landingDomainUrl")}/login/user`, state: {from: props.location}}}/>
            window.location = `${conf_prop.get("landingDomainUrl")}/login/user`;
        }
        // authorised so return component
        return <Component {...props} />
    }
    }/>
);

