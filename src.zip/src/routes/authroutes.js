import Loadable from "../layouts/loader/Loadable";
import conf_prop from "../properties/properties";
import {lazy} from "react";

const LogoutView = Loadable(lazy(() => import( "../pages/login/logout")));
const LoginUser = Loadable(lazy(() => import( "../pages/login/login-user")));
const UserAuthorizedView = Loadable(lazy(() => import( "../pages/login/user-authorized")));

const route_path = conf_prop.get("route_path");
const authRoutes = [
    {
        path: `${route_path}/login/user`,
        name: 'LoginUser',
        icon: 'mdi mdi-account-key',
        component: LoginUser,
        sidebar: false,
    },

    {
        path: `${route_path}/login/user-authorized`,
        name: 'UserOauth',
        icon: 'mdi mdi-account-key',
        component: UserAuthorizedView,
        sidebar: false,
    },
    {
        path: `${route_path}/login/logout`,
        name: 'Logout',
        icon: 'mdi mdi-account-key',
        component: LogoutView,
        sidebar: true,
    }


];
export default authRoutes;
