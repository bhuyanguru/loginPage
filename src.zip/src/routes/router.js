import authRoutes from "./authroutes";

import InbasketUserRoutes from "./inbasket-user-routes";


import conf_prop from "../properties/properties";
import notificationRoutes from "./notificationRoutes";

const route_path = conf_prop.get("route_path");

const ThemeRoutes = [{
    navlabel: true,
    name: "",
    icon: "",
},


    {
        path: `${route_path}/login`,
        name: 'User',
        icon: 'mdi mdi-account-circle',

        child: authRoutes,
        collapse: true,
        sidebar: false
    },

    {
        path: `${route_path}/user`,
        name: 'Inbasket',
        icon: 'mdi mdi-account-circle',

        child: InbasketUserRoutes,
        collapse: true,
        sidebar: true
    },

    {
        path: `${route_path}/notification`,
        name: 'Notification',
        icon: 'mdi mdi-account-circle',

        child: notificationRoutes,
        collapse: true,
        sidebar: false
    },


    {
        path: '/',
        pathTo: `${route_path}/login/user`,
        name: 'redirect',
        redirect: true,
        sidebar: false
    },


];
export default ThemeRoutes;
