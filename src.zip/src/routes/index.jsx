import {lazy} from "react";
import conf_prop from "../properties/properties";
// import UserFulllayout from '../layouts/userfulllayout';
// import Blanklayout from '../layouts/blanklayout.js';


const UserFulllayout = lazy(() => import("../layouts/userfulllayout"));
const Blanklayout = lazy(() => import("../layouts/blanklayout.js"));
export const notificationFullLayout = lazy(() => import("../layouts/notificationfulllayout"))

const route_path = conf_prop.get("route_path");

const indexRoutes = [

    {path: `${route_path}/login`, name: "Authentication", component: Blanklayout},
    {path: `${route_path}/pi-user`, name: 'TTPI', component: UserFulllayout},
    {path: `${route_path}/inbasket-user`, name: 'Inbasket', component: UserFulllayout},
    {path: `${route_path}/vdc-user`, name: 'Vdc', component: UserFulllayout},
    {path: `${route_path}/casestudy-user`, name: 'Casestudy', component: UserFulllayout},
    {path: `${route_path}/anchor-user`, name: 'Anchor', component: UserFulllayout},
    {path: `${route_path}/roleplay-user`, name: 'Roleplay', component: UserFulllayout},
    {path: `${route_path}/notification`, name: 'notification', component: notificationFullLayout},
    {path: `${route_path}`, name: 'Home', component: UserFulllayout},

    /*{path: `${route_path}/login`, name: "Authentication", component: Blanklayout},
    {path: `${route_path}/user`, name: 'TTPI', component: UserFulllayout},
    {path: `${route_path}/notification`, name: 'notification', component: notificationFullLayout},
    {path: `${route_path}`, name: 'Home', component: UserFulllayout},*/


];

export default indexRoutes;
