import conf_prop from "../properties/properties";

import ErrorBoundary401 from "../ErrorBoundary401";
const route_path = conf_prop.get("route_path");

const NotificationRoutes = [



    {
        path: `${route_path}/notification/error-unauthorized`,
        name: 'sidebar.client.list',
        icon: 'mdi mdi-account-key',
        component: ErrorBoundary401,
        sidebar: false,
        sidebarDisplay: "mini"


    },


];
export default NotificationRoutes;
