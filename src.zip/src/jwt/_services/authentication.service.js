import {BehaviorSubject} from 'rxjs';


const currentUserSubject = new BehaviorSubject(JSON.parse(ApiUtils.getLocalStorage('currentUser')));

export const authenticationService = {
    login,
    logout,
    currentUser: currentUserSubject.asObservable(),
    get currentUserValue() {
        return currentUserSubject.value
    }
};

function login(userinfo) {


    ApiUtils.setLocalStorage('currentUser', JSON.stringify(userinfo));
    currentUserSubject.next(userinfo);

    return userinfo;

}

function logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    currentUserSubject.next(null);
}
