import _ from 'lodash';
import "whatwg-fetch";
import ApiUtils from "../../api/ApiUtils";

// import {fetch as fetchPolyfill} from 'whatwg-fetch';

export function configureFakeBackend() {

    let realFetch = window.fetch;

    window.fetch = function (url, opts) {

        const isLoggedIn = _.isEmpty(opts.headers) ? false : _.isEmpty(opts.headers.Authorization);
        ApiUtils.setLocalStorage("idleTime", 3600);

        return new Promise((resolve, reject) => {
            // wrap in timeout to simulate server api call
            setTimeout(() => {
                // authenticate - public


                // get users - secure
                if (url.includes('/user/') && opts.method === 'GET') {

                    if (!isLoggedIn) return unauthorised();
                    return ok({});
                }

                if (url.includes('/client/') && opts.method === 'GET') {

                    if (!isLoggedIn) return unauthorised();
                    return ok({});
                }

                // pass through any requests not handled above
                realFetch(url, opts).then(response => resolve(response));

                // private helper functions

                function ok(body) {
                    resolve({ok: true, text: () => Promise.resolve(JSON.stringify(body))})
                }

                function unauthorised() {
                    resolve({status: 401, text: () => Promise.resolve(JSON.stringify({message: 'Unauthorised'}))})
                }

                function error(message) {
                    resolve({status: 400, text: () => Promise.resolve(JSON.stringify({message}))})
                }
            }, 500);
        });
    }
}