import ApiUtils from '../../api/ApiUtils';

export function authHeader() {
    const accessToken = ApiUtils.getCookie("accessToken");
    // return authorization header with jwt token
    if (accessToken !== null) {
        return {Authorization: `Bearer ${accessToken.access_token}`};
    } else {
        return {};
    }
}
