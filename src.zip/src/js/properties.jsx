var properties = new Map();

var config = {

    serviceUrl: "https://nextv3.thinktalent.info",
    // serviceUrl: "http://localhost:8080",
    // serviceUrl: "https://app.thinktalentnext.com",
    // serviceUrl: "https://app.elemetrik.co",
    // serviceUrl: "https://nevgelisim.thinktalentnext.com",
    domainUrl: 'http://localhost:3004',


    video_endpoint: "https://media.thinktalentws48.click"
};
properties.set("serviceUrl", config.serviceUrl);
properties.set("domainUrl", config.domainUrl);
properties.set("pdfViewerUrl", "https://pdf-viewer.thinktalent.info/web/viewer.html");
properties.set("inbasketServiceUrl", `${properties.get("serviceUrl")}/inbasket-user-service`);
//properties.set("inbasketServiceUrl", `http://localhost:8080`);



properties.set("nextServiceUrl", `${properties.get("serviceUrl")}/next-service`);
// properties.set("nextServiceUrl", `http://localhost:8080`);



properties.set("oauthServiceUrl", `${properties.get("serviceUrl")}/oauth-service`);
// properties.set("oauthServiceUrl", `http://localhost:9982`);

properties.set("langServiceUrl", `${properties.get("serviceUrl")}/lang-service`);

properties.set("proctorServiceUrl", `${config.serviceUrl}/proctor-service`);

properties.set("landingServiceUrl", `${config.serviceUrl}/landing-user-service`);
properties.set("landingDomainUrl", `${config.serviceUrl}/landing-user`);
properties.set("langServiceUrl", `${config.serviceUrl}/lang-service`);

properties.set("video_endpoint", config.video_endpoint);


properties.set("port", 2006);
properties.set("cookieSecure", true);

properties.set("displayLang", true);
properties.set("lng", "en");

// properties.set("login_video",`<iframe src="https://player.vimeo.com/video/467021876" width="640" height="360" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>`);

properties.set("sentry_dsn", "https://c07384b522ce4a599be10e3243b43f29@sentry-error.thinktalentws48.click/1002");
properties.set("sentry_release", "development");

properties.set("idleTime", 9 * 60 * 60);
properties.set("idleCountDown", 60);

properties.set("logo", "logo-tatap.png");

properties.set("embedJavascript", [

    {"innerHTML": 'window.userpilotSettings = {token: "63ro99j3"}'},
    {"src": 'https://js.userpilot.io/sdk/latest.js'},


    {
        "innerHTML": `window.fwSettings={'widget_id':42000000609};
    !function(){if("function"!=typeof window.FreshworksWidget){var n=function(){n.q.push(arguments)};n.q=[],window.FreshworksWidget=n}}() ;
  FreshworksWidget('hide');
`
    },
    {"src": 'https://widget.freshworks.com/widgets/42000000609.js'},

    {"src": 'https://cdn.jsdelivr.net/npm/secure-ls@1.2.6/dist/secure-ls.min.js'},
    {
        "innerHTML": `setTimeout(() => {
var embedString = "ThinkLocalStorage@13972684";
var secureStorage = new SecureLS({encodingType: "aes", encryptionSecret: embedString});

var userInfo = secureStorage.get("userInfo");
var userClientMapper = secureStorage.get("userClientMapper");

            if (!_.isUndefined(window.FreshworksWidget) && !_.isEmpty(userInfo)) {
                window.FreshworksWidget("identify", "ticketForm", {
                    name: userInfo.name,
                    email: userInfo.email,
                });
                window.FreshworksWidget("prefill", "ticketForm", {

                    custom_fields: {
                        cf_user_id: userInfo.userId,
                        cf_ucm_id: userClientMapper.ucmId,
                        cf_client_id: userClientMapper.client.clientId,
                        cf_client_name: userClientMapper.client.name,                        
                        cf_current_url: window.location.href

                    }
                });
                window.FreshworksWidget("hide", "ticketForm", [
                    "custom_fields.cf_user_id",
                    "custom_fields.cf_ucm_id",
                    "custom_fields.cf_client_id",
                    "custom_fields.cf_client_name",
                    "custom_fields.cf_current_url",
                ]);
            }
},1000);`

    },
    {
        "innerHTML": `
   setTimeout(() => {
if (!_.isUndefined(window.userpilot)) {
var embedString = "ThinkLocalStorage@13972684";
var secureStorage = new SecureLS({encodingType: "aes", encryptionSecret: embedString});

var userInfo = secureStorage.get("userInfo");
var userClientMapper = secureStorage.get("userClientMapper");
            window.userpilot.identify(
                userInfo.userId_ENCRYPTED, // Used to identify users
                {
                    //name: userinfo.NAME, // Full name
                    email: userInfo.userId_ENCRYPTED, // Email address
                    //created_at: userInfo.genDate, // Signup date as a Unix timestamp
                    company:  // optional
                        {
                            id: userClientMapper.client.clientId_ENCRYPTED, // Company Unique ID
                            //created_at: userClientMapper.client.name // Signup date as a Unix timestamp
                        }
                    // Additional user properties
                    // plan: "free",
                    // trialEnds: '2019-10-31T09:29:33.401Z'"

                }
            );
        }
},1000);
    `
    },


]);


export const logo = require("../assets/images/logo/logo.png");
export default properties;
