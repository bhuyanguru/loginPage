var properties = new Map();

var config = {

    serviceUrl: "https://nextv3.thinktalent.info",
    domainUrl: 'https://nextv3.thinktalent.info',


    video_endpoint: "https://media.thinktalentws48.click"
};
properties.set("serviceUrl", config.serviceUrl);
properties.set("domainUrl", config.domainUrl);


properties.set("serviceUrl", config.serviceUrl);
properties.set("inbasketServiceUrl", `${config.serviceUrl}/inbasket-user-service`);

properties.set("nextServiceUrl", `${config.serviceUrl}/next-service`);

properties.set("oauthServiceUrl", `${config.serviceUrl}/oauth-service`);

properties.set("video_endpoint", config.video_endpoint);
properties.set("logo", "logo.png");

properties.set("port", 2006);
properties.set("cookieSecure", true);

properties.set("displayLang", true);

properties.set("sentry_dsn", "{{SENTRY_DSN}}");
properties.set("sentry_release", "{{SENTRY_RELEASE}}");

export const logo = require("../assets/images/logo/logo.png");
export default properties;
