var properties = new Map();

var config = {

    serviceUrl: "https://nevgelisim.thinktalentnext.com",
    domainUrl: 'https://nevgelisim.thinktalentnext.com',


    $test_video_endpoint: "https://media.thinktalentws48.click",
    $prod_video_endpoint: "https://media.thinktalentws48.click",
    video_endpoint: "https://media.thinktalentws48.click"
};
properties.set("serviceUrl", config.serviceUrl);
properties.set("domainUrl", config.domainUrl);

properties.set("ttpiServiceUrl", `${properties.get("serviceUrl")}/pi-user-service`);
properties.set("inbasketServiceUrl", `${properties.get("serviceUrl")}/inbasket-user-service`);
properties.set("vdcServiceUrl", `${properties.get("serviceUrl")}/vdc-service`);
properties.set("nextServiceUrl", `${properties.get("serviceUrl")}/next-service`);
properties.set("casestudyServiceUrl", `${properties.get("serviceUrl")}/casestudy-user-service`);
properties.set("roleplayServiceUrl", `${properties.get("serviceUrl")}/roleplay-user-service`);
properties.set("anchorServiceUrl", `${properties.get("serviceUrl")}/anchor-user-service`);
properties.set("oauthServiceUrl", `${properties.get("serviceUrl")}/oauth-service`);

properties.set("video_endpoint", config.video_endpoint);
properties.set("logo", "logo-nev.jpg");

properties.set("port", 2006);
properties.set("cookieSecure", true);
properties.set("displayLang", false);

properties.set("sentry_dsn", "{{SENTRY_DSN}}");
properties.set("sentry_release", "{{SENTRY_RELEASE}}");

export const logo = require("../assets/images/logo/logo-nev.jpg");
export default properties;
