import inbasket_en_resource from "../component/inbasket/inbasket-user/i18n/inbasket_user_en.json"

import sidebar_en_resource from "../i18/sidebar_en.json"

const en_resource = {

    ...inbasket_en_resource,

    ...sidebar_en_resource,

};

export default en_resource;
