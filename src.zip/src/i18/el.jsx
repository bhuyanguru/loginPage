import inbasket_el_resource from "../component/inbasket/inbasket-user/i18n/inbasket_user_el.json";

import sidebar_el_resource from "../i18/sidebar_el.json"

const el_resource = {

    ...inbasket_el_resource,

    ...sidebar_el_resource,

};

export default el_resource;
