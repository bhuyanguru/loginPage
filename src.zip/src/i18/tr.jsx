import inbasket_user_tr_resource from "../component/inbasket/inbasket-user/i18n/inbasket_user_tr.json"

import sidebar_tr_resource from "../i18/sidebar_tr.json"

const tr_resource = {

    ...inbasket_user_tr_resource,

    ...sidebar_tr_resource
};

export default tr_resource;
