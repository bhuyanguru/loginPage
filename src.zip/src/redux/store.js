import {applyMiddleware, compose, createStore} from 'redux';
import {createLogger} from 'redux-logger';
import reducers from './reducers';
import * as Sentry from "@sentry/react";

const sentryReduxEnhancer = Sentry.createReduxEnhancer({
    // Optionally pass options listed below
});
const logger = createLogger();

export function configureStore(initialState) {


    const middlewares = [logger];

    return createStore(
        reducers,
        initialState,

        compose(applyMiddleware(...middlewares), sentryReduxEnhancer)
    );
}
