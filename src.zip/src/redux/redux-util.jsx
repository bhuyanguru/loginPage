export const mapStateToProps = (state, ownProps) => ({
    // ... computed data from state and optionally ownProps

});

/*function mapStateToProps(state, ownProps) {
    // ... computed data from state and optionally ownProps
    // console.log(state, ownProps);
};*/

export const mapDispatchToProps = {
    // ... normally is an object full of action creators
};
