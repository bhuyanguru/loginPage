// export {default as ActivityView} from "./activity";
import {lazy} from "react";


export const NotificationView = lazy(() => import("./notification"));
