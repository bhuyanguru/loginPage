import React from "react";
import Loader from 'react-loader-spinner'

export default class LoaderSpinner extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            isLoaded: false
        };
    }

    render() {
        if (!this.props.isLoaded) {
            return (
                <div className="text-center">
                    <Loader
                        type="TailSpin"
                        color="#00BFFF"
                        height={40}
                        width={40}
                        timeout={5000} //3 secs

                    />
                </div>

            );

        } else {
            return (
                <div>&nbsp;</div>
            )

        }
    }
}
