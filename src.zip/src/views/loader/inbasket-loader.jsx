import React from "react";
import ContentLoader from "react-content-loader";
import {Card, CardBody} from 'reactstrap';

export default class InbasketLoader extends React.Component {

    constructor(props) {
        super(props);

        this.state = {};
    }

    render() {

        return (
            <div className="text-center pt-2 ">
                <Card>
                    <CardBody>


                        <ContentLoader
                            viewBox="0 0 400 160"
                            height={160}
                            width={400}
                            speed={2}


                        >
                            <circle cx="150" cy="86" r="8"/>
                            <circle cx="194" cy="86" r="8"/>
                            <circle cx="238" cy="86" r="8"/>
                        </ContentLoader>
                    </CardBody>
                </Card>
            </div>

        );


    }
}






