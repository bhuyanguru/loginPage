import React from "react";
import {Card, CardBody} from "reactstrap";
import {translate} from "react-i18next";
import InbasketFancyBox from "./inbasket-fancybox";
import {findProjectUserByPumId, findTemplateMaterialByTempId} from "../../service";

class InbasketUserMaterialView extends React.Component {
    constructor(props) {
        super(props);


        const {pumId_ENCRYPTED} = this.props
        /*  const projectUserMapper = this.props.projectUserMapper ;
          const template = projectUserMapper.project.clientTemplateMapper.template;*/
        this.state = {
            projectUserMapper: {},
            template: {},
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            templateMaterials: [],
            templateMaterial: {},
            isLoaded: false,
        };


        this.findTemplateMaterialByTempId = findTemplateMaterialByTempId.bind(this);
        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);


    }


    async componentDidMount() {
        await this.findProjectUserByPumId();
        await this.findTemplateMaterialByTempId();

    }

    render() {
        const {t, i18n} = this.props;
        return (
            <div>
                <Card className="bordered_card" style={{width: '90%'}}>

                    <div className="next_card_title text-center"><b
                        style={{fontSize: '16px'}}>{t("inbasket.usermaterial.information")}</b></div>

                    <CardBody className="p-0">
                        <hr/>
                        {/*<h4 className="card-title">{t("inbasket.usermaterial.information")}</h4>*/}
                        <div className="feed-widget">
                            <ul className="list-style-none feed-body">
                                {this.state.templateMaterials.map((curtemplateMaterial, index) => (
                                    <li style={{cursor: 'pointer'}} key={index}
                                        className="feed-item-info">
                                        <InbasketFancyBox templateMaterial={curtemplateMaterial} index={index}/>
                                        {/*  {curtemplateMaterial.materialMime.includes("pdf") ?
                                        <InbasketFancyBox templateMaterial={curtemplateMaterial}/> :  <div>
                                                <a data-fancybox data-src="#hidden-content" >
                                                    <div className="feed-icon bg-light-secondary">{curtemplateMaterial.materialName}</div>
                                                </a>
                                                <div style={{ display: "none", height: "100vh",
                                                    width: "100%"}} id="hidden-content">
                                                    <div  dangerouslySetInnerHTML={{__html: curtemplateMaterial.materialContent}}></div>
                                                </div>
                                            </div> }*/}
                                    </li>
                                ))}

                            </ul>


                        </div>


                    </CardBody>
                </Card>


            </div>
        );
    }
}

export default (translate("translations")(InbasketUserMaterialView));
