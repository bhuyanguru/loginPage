import '@fancyapps/fancybox/dist/jquery.fancybox';
import $ from 'jquery';
import React from 'react';
import '@fancyapps/fancybox/dist/jquery.fancybox.min.css';
import conf_prop from "../../properties/properties";


export default class InbasketFancyBox extends React.Component {
    constructor(props) {
        super(props);

    }

    componentDidMount() {
        $.fancybox.defaults.arrows = false;
        $.fancybox.defaults.keyboard = false;
        $.fancybox.defaults.closeExisting = false;
        $("[data-fancybox]").fancybox({
            // arrows: false,
            // closeExisting: false,
            // keyboard: false,
            buttons: ['slideshow',
                'zoom',
                'fullscreen',
                'close'],
            thumb: {
                autostart: true
            }

        });

    }

    render() {

        const {index,templateMaterial} = this.props;
        return (

            <div>



                {templateMaterial.materialMime.includes("text") && (


                    <div>
                        <a data-fancybox data-src={`#hidden-content-${index}`} >
                            <div className="feed-icon bg-light-secondary">{templateMaterial.materialName}</div>
                        </a>
                        <div style={{ display: "none", height: "100vh", width: "100%"}} id={`hidden-content-${index}`}>

                            <div  dangerouslySetInnerHTML={{__html: templateMaterial.materialContent}}></div>
                        </div>
                    </div>

                )}

                {templateMaterial.materialMime.includes("pdf") && (
                    <div>
                        <a data-fancybox data-type="iframe"
                           data-src={`${conf_prop.get("pdfViewerUrl")}?file=${templateMaterial.materialLink}#toolbar=0`}
                        >
                            {templateMaterial.materialName}
                        </a>
                        {/*<a data-fancybox data-src={`#pdf-material-${templateMaterial.materialId}`}>
                            <div className="feed-icon bg-light-secondary"><i
                                className="mr-2 mdi mdi-file-multiple"></i>{templateMaterial.materialName}
                            </div>
                        </a>
                        <div style={{display: "none"}} id={`pdf-material-${templateMaterial.materialId}`}>
                            <PDFReader url={templateMaterial.materialLink}/>
                        </div>*/}
                    </div>
                )}


            </div>

        )
    }


}



