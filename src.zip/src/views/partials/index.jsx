import {lazy} from "react";

export const NotificationView = lazy(() => import("./notification"));
export const InbasketFancyBox = lazy(() => import("./inbasket-fancybox"));
export const InbasketMailLegend = lazy(() => import("./inbasket-mail-legend"));
export const InbasketSummerNote = lazy(() => import("./inbasket-summer-note"));
export const InbasketUserInboxTimerView = lazy(() => import("./inbasket-user-inboxtimer"));
export const InbasketUserInformationView = lazy(() => import("./inbasket-user-information"));
export const InbasketUserMaterialView = lazy(() => import("./inbasket-user-material"));
export const InbasketUserReplyView = lazy(() => import("./inbasket-user-reply"));
export const InbasketUserResponseReplyView = lazy(() => import("./inbasket-user-response-reply"));
export const InbasketUserTimerView = lazy(() => import("./inbasket-user-timer"));
export const InbasketVideosection = lazy(() => import("./inbasket-videosection"));
export const InbasketWelcome = lazy(() => import("./inbasket-welcome"));