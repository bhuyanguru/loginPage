import React, {Component} from 'react';
import update from 'immutability-helper';

import ReactSummernote from 'react-summernote';

import {summernoteFullToolbar} from "../../component/utils/summer-note"; // import styles


class InbasketSummerNote extends Component {

    constructor(props) {
        super(props);

        // console.log(props);
        // console.log(this.props.setState);
    }

    onChange(content) {
        this.props.setState({
            [this.props.updateState]: update([this.props.updateState], {[this.props.name]: {$set: content}})
        });
        // console.log(this.props.updateState);
    }


    render() {
        return (
            <ReactSummernote


                value={this.props.placeholder}
                name={this.props.name}
                options={{
                    lang: 'en-EN',
                    height: 70,
                    dialogsInBody: true,
                    popover: {
                        image: [],
                        link: [],
                        air: []
                    },
                    toolbar: summernoteFullToolbar
                }}
                onChange={this.onChange}

            />

        );
    }
}

export default InbasketSummerNote;
