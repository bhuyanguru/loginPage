import _ from 'lodash';
import React, {useEffect, useRef} from "react";
import {InbasketProjectUserMapperController, InbasketProjectUserTimeBackUpController} from '../../api/inbasket';

import {translate} from "react-i18next";
// import {findProjectUserByPumId} from "../../service";
import conf_prop from "../../properties/properties";
import ApiUtils from "../../api/ApiUtils";
import {Redirect} from "react-router-dom";
// import InbasketTemplateInstructionController from "../../api/inbasket/inbasket-templateinstruction-controller";

const route_path = conf_prop.get("route_path");

function InbasketUserTimerView(props) {

    const masterAccessList = _.isEmpty(ApiUtils.getLocalStorage("masterAccessList")) ? [] : ApiUtils.getLocalStorage("masterAccessList");

    const {pumId_ENCRYPTED, t, i18, projectUserMapper} = props;


    const [second, set_second] = React.useState(_.isNull(localStorage.getItem(`timeInstructionBackup-${pumId_ENCRYPTED}`)) ? null : localStorage.getItem(`timeInstructionBackup-${pumId_ENCRYPTED}`));

    const [isLoaded, set_isLoaded] = React.useState(false);
    const [isTimerComplete, setIsTimerComplete] = React.useState(false);
    const [projectUserTimeBackUp, setProjectUserTimeBackUp] = React.useState({});
    const [online, setOnline] = React.useState(navigator.onLine);
    const intervalRef = useRef(null);
    const updateInterval = useRef(null);


    async function getInstructionTime() {
        await InbasketProjectUserMapperController.getInstructionTimer(pumId_ENCRYPTED).then(
            result => {

                    set_second(result);

            }).catch(error => {
            console.error(error);
        });
    }


    async function saveOrUpdateProjectUserTimmerBackup() {
        const timebackup = second;
        const newProjectUserTimeBackUp = {
            projectUserMapper: {pumId: projectUserMapper.pumId},
            instructionTimeBackup: timebackup
        };
        if (masterAccessList.includes("DEMO_INBASKET_USER_SUBMIT_RESTRICT")) {

        } else {
            await InbasketProjectUserTimeBackUpController.insertProject(newProjectUserTimeBackUp).then(
                result => {

                    set_isLoaded(true);

                }).catch(error => {
                set_isLoaded(true);

                console.error(error);
            });
        }

    }

    function countDown() {

        if (!_.isUndefined(online) && !online) {
            return;
        }

        let second_input = second;

        set_second(second_prev => {
            if(second_prev <= 0){
                clearInterval(intervalRef.current);
                clearInterval(updateInterval.current);
                // setIsTimerComplete(isTimerComplete_prev => !isTimerComplete_prev);
                return 0;
            }else{
                second_input = second_prev - 1;
                localStorage.setItem(`timeInstructionBackup-${props.pumId_ENCRYPTED}`, second_input);
                return second_input;
            }

        });



    }

    useEffect(() => {
        window.addEventListener('online', () => {
            setOnline(true)
        });
        window.addEventListener('offline', () => {
            setOnline(false)
        });

        async function fetchData() {

            // await findProjectUserByPumId();
            if (_.isNaN(parseInt(localStorage.getItem(`timeInstructionBackup-${pumId_ENCRYPTED}`)))) {
                await getInstructionTime();
            } else {
                set_second(parseInt(localStorage.getItem(`timeInstructionBackup-${pumId_ENCRYPTED}`)));


            }

            set_isLoaded(true);
            intervalRef.current = setInterval(countDown, 1000);
            updateInterval.current = setInterval(saveOrUpdateProjectUserTimmerBackup, 60 * 1000);


            return () => {
                clearInterval(intervalRef.current);
                clearInterval(updateInterval.current);
                // window.removeEventListener('beforeunload', handleBeforeUnload);
            };
        }

        fetchData();
    }, []);


    const formatTime = (time) => time < 10 ? "0" + time : time;

    let hh = formatTime(Math.floor(second / 3600));
    let mm = formatTime(Math.floor((second % 3600) / 60));
    let ss = formatTime(second % 60);


    if (isTimerComplete) {
        return (<p>test</p>)
        // return <Redirect to={`${route_path}/user/inbox/${pumId_ENCRYPTED}`}/>
    }else{
        return (


            <div>
                <span className="next_btn_timer " style={{cursor: 'text'}}><span
                    style={{fontSize: '14px'}}>{t("inbasket.exerciseendsin")} : </span>{' '} <span
                    style={{fontSize: '14px'}}> {hh}:{mm}:{ss}</span></span>
            </div>
        );
    }




}

export default translate("translations")(InbasketUserTimerView);

