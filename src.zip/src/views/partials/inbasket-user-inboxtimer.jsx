import _ from 'lodash';
import React, {useEffect, useState,useRef} from "react";
import {Redirect} from 'react-router-dom';
import {Button, Col, Form, Modal, ModalBody, ModalHeader, Row} from "reactstrap";
import confirm from "reactstrap-confirm-by-jdionicio";

import {InbasketProjectUserMapperController, InbasketProjectUserTimeBackUpController} from '../../api/inbasket';
import {translate} from "react-i18next";
import conf_prop from "../../properties/properties";
import {toastify} from "../../component/utils/toastify";
import Loader from "react-loader-spinner";
import classNames from "classnames";
import ApiUtils from "../../api/ApiUtils";
import LoaderSpinner from "../loader/loader-spinner";
import InbasketProjectUserMapperResponseController
    from "../../api/inbasket/inbasket-projectusermapperresponse-controller";

const route_path = conf_prop.get("route_path");

function InbasketUserInboxTimerView(props) {

    const masterAccessList = _.isEmpty(ApiUtils.getLocalStorage("masterAccessList")) ? [] : ApiUtils.getLocalStorage("masterAccessList");
    const {pumId_ENCRYPTED, t, i18n,projectUserMapper} = props;
    const [second, set_second] = useState(parseInt(localStorage.getItem(`timebackup-${pumId_ENCRYPTED}`)));

    const [updateModal, set_updateModal] = useState(false);
    const [isLoaded, set_isLoaded] = useState(false);
    const [buttonDisabled, setButtonDisabled] = useState(true);
    const [submitExercise, setSubmitExercise] = useState(false);
    const [redirect, set_redirect] = useState(false);
    // const [projectUserMapper, set_projectUserMapper] = useState({props.projectUserMapper});
    const [projectUserTimeBackUp, set_projectUserTimeBackUp] = useState({});
    const [templateTimer, set_templateTimer] = useState({});
    const [online, setOnline] = useState(navigator.onLine);
    const intervalRef = useRef(null);
    const updateInterval = useRef(null);


    function updateModalToggle() {
        set_updateModal(updateModal_prev => !updateModal_prev);

    }

    async function getInboxTime() {
        await InbasketProjectUserMapperController.getInboxTimer(pumId_ENCRYPTED).then(
            result => {

                set_templateTimer(result);
                set_second(result);

                if (_.isNumber(result) && result <= 0) {
                    onSurveySubmit()
                }


            }).catch(error => {

            console.error(error);
        });
    }


    async function onTimeCompleteSurveySubmit() {
        const flag = await confirm({
            title: (
                t("inbasket.user.time.out.title")

            ),
            closedforContent: false,
            message: t("inbasket.user.time.out.msg"),
            confirmText: t("inbasket.user.time.out.confirm.btn"),
            cancelText: null,
            buttonsComponent: null,
            confirmColor: "btn next_btn",
        });
        if (flag) {
            await onSurveySubmit()
        }
    }

    async function onSurveySubmit() {
        setButtonDisabled(false)

        await InbasketProjectUserMapperController.updateProjectUserMapperStatus(projectUserMapper).then(
            result => {


                set_redirect(redirect_prev => !redirect_prev)


                toastify("success", t("inbasket.submitted.successfully"), t("inbasket.submitted.successfully"))


            }).catch(error => {

            console.error(error)
        }).finally(() => {
            setButtonDisabled(true)
        });

    }

    async function saveOrUpdateProjectUserTimmerBackup() {

        let timebackup = second;
        const newProjectUserTimeBackUp = {
            projectUserMapper: {pumId: projectUserMapper.pumId},
            mailTimeBackup: timebackup
        };
        if (masterAccessList.includes("DEMO_INBASKET_USER_SUBMIT_RESTRICT")) {

        } else {
            await InbasketProjectUserTimeBackUpController.insertProject(newProjectUserTimeBackUp).then(
                result => {


                }).catch(error => console.error(error));
        }


    }

    function countDown() {
        if (!_.isUndefined(online) && !online) {
            return;
        }

        let second_input = second;


        set_second(second_prev => {
            if (second_prev <= 0) {
                clearInterval(intervalRef.current)
                clearInterval(updateInterval.current)
                return 0;
            }else{
                second_input = second_prev - 1;
                localStorage.setItem(`timebackup-${pumId_ENCRYPTED}`, second_prev - 1);
                return second_prev - 1;
            }

        });


        if (_.isNumber(second_input)) {
            switch (second_input) {
                case 900:
                    alert(t("inbasket.fifteenminutes.left"));
                    break;
                case 300:
                    alert(t("inbasket.fiveminutes.left"));
                    break;
                case 60:
                    alert(t("inbasket.user.time.remaining.text.msg.60.force.save"));
                    break;
                default:
                    if (second_input < 1) {

                        onTimeCompleteSurveySubmit();
                    }
            }
        }

    }

    async function findUserResponseCount() {

        await InbasketProjectUserMapperResponseController.getProjectUserMapperResponseCount(pumId_ENCRYPTED)
            .then(
                result => {

                    setSubmitExercise(_.isEqual(result.responseCount,0) ? true : false);
                //

                }).catch(error => {

                console.error(error);
            });
    }


    useEffect(() => {

        window.addEventListener('online', () => {
            setOnline(true)
        });
        window.addEventListener('offline', () => {
            setOnline(false)
        });

        async function fetchData() {


            await findUserResponseCount();

            if (_.isNaN(parseInt(localStorage.getItem(`timebackup-${pumId_ENCRYPTED}`)))) {
                await getInboxTime();
            } else {
                set_second(parseInt(localStorage.getItem(`timebackup-${pumId_ENCRYPTED}`)))

            }

            set_isLoaded(true);
            intervalRef.current = setInterval(countDown, 1000);
            updateInterval.current = setInterval(saveOrUpdateProjectUserTimmerBackup, 60 * 1000);

            return () => {
                clearInterval(intervalRef.current);
                clearInterval(updateInterval.current);
            };
        }

        fetchData();
    }, []);




    if (!isLoaded) {
        return (
            <LoaderSpinner/>
        )
    } else {
        // const {masterAccessList, submitExercise} = state;
        let hh = Math.floor(second / 3600);
        if (hh < 10) hh = "0" + hh;


        let mm = Math.floor((second - (hh * 3600)) / 60);
        if (mm < 10) mm = "0" + mm;

        let ss = second - ((hh * 3600) + (mm * 60));
        if (ss < 10) ss = "0" + ss;

        if (redirect) {
            return <Redirect to={`${route_path}/user/thankyou/${pumId_ENCRYPTED}`}/>
        }


        return (

            <div>
                <div>
                    <span className="next_btn_timer inbox-timer mr-2 mt-2"><span
                        style={{fontSize: '14px'}}>{t("inbasket.exerciseendsin")}: </span>{' '}
                        <span className="text-white" style={{fontSize: '14px'}}> {hh}:{mm}:{ss}</span></span>
                    <Button type="button"
                            disabled={submitExercise || masterAccessList.includes("DEMO_INBASKET_USER_SUBMIT_RESTRICT")}
                            title={submitExercise ? t("inbasket.submit.exercise.button.tooltip") : ""}
                            className={classNames({
                                "link-disabled mt-2": submitExercise,
                                "next_btn mt-2": !submitExercise
                            })}
                            onClick={updateModalToggle}>
                        {/*<Loader type="Oval" color="#00BFFF" height={20} width={20}/>*/}
                        {t("inbasket.userinboxtimer.submirexercise")}</Button>
                </div>


                <Modal backdrop={"static"}
                       isOpen={updateModal}
                       toggle={updateModalToggle}
                       size="md"
                >
                    <Form>
                        <ModalHeader toggle={updateModalToggle}>
                            <b>{t("inbasket.userinboxtimer.submirexercise.modal.header")} </b></ModalHeader>

                        <ModalBody>
                            <div className="text-center p-5 ">
                                <h6>{t("inbasket.userinboxtimer.submirexercise.modal.message")}</h6>
                            </div>

                            <Row>
                                <Col md={5}></Col>
                                <Col md={7} className="text-right">
                                    <Button className="next_cancel_btn next_btn_lg mr-2"
                                            onClick={updateModalToggle}>{t("inbasket.userinboxtimer.submirexercise.modal.cancel")}</Button>
                                    <Button className="next_btn next_btn_lg"
                                            onClick={onSurveySubmit}>
                                        {buttonDisabled === false ? (
                                            <Loader type="Oval" color="#00BFFF" height={20} width={20}/>
                                        ) : (
                                            <span>{t("inbasket.userinboxtimer.submirexercise.modal.submit")}</span>
                                        )}</Button>
                                </Col>
                            </Row>
                        </ModalBody>
                    </Form>
                </Modal>


            </div>
        );
    }
}

export default (translate("translations")(InbasketUserInboxTimerView));
