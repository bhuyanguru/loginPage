import React from "react";
import {Button, Col, Modal, ModalBody, ModalHeader, Row} from "reactstrap";
import img from "../../component/inbasket/assets/images/inbasket-edited.png";
import {translate} from "react-i18next";
import {findProjectUserByPumId, redirectTool} from "../../service";

class InbasketWelcome extends React.Component {


    constructor(props) {
        super(props);
        const {pumId_ENCRYPTED} = this.props;
        this.state = {
            isLoaded: false,
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            projectUserMapper: {},
            instructionsModal: false,
            redirectData: {},
            instruction: {}


        };
        this.redirectTool = redirectTool.bind(this);
        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.ViewInstructionsModal = this.ViewInstructionsModal.bind(this);
    }

    ViewInstructionsModal() {
        this.setState(prevState => ({
            instructionsModal: !prevState.instructionsModal
        }));
    }

    async componentDidMount() {
        await this.findProjectUserByPumId();
        await this.redirectTool();
    }

    render() {
        const {t, i18n} = this.props;
        const {redirectData, instruction} = this.state;
        return (
            <div>


                <Row>
                    <Col md={12}>
                        <div className="assign_wraper pb-3">


                            <Row>
                                <Col md="9">
                                    <p><a className="text-white font-12"
                                          href={redirectData.redirectUrl}><i
                                        className="text-white fas fa-angle-left"/>{' '} {t(`inbasket.back.${redirectData.integrationName}`)}
                                    </a></p>
                                    <div className="page_title text-white">{redirectData.itemName}</div>

                                    <div className="text-white mt-1">
                                        <div><span onClick={this.ViewInstructionsModal} style={{cursor: 'pointer'}}><i
                                            className="ti-info-alt"/> {t("inbasket.view.instruction")}</span>
                                        </div>


                                    </div>
                                </Col>
                                <Col md="3" className="text-right">
                                    <img className=" mob_img_none" style={{width: "150px", marginBottom: "-15px"}}
                                         src={img}/>
                                </Col>
                            </Row>
                        </div>
                    </Col>
                </Row>


                <Modal backdrop="true"
                       isOpen={this.state.instructionsModal}
                    // fade={false}
                       toggle={this.ViewInstructionsModal}
                    // className="discard-draft-modal"
                       size="md"
                >

                    <ModalHeader toggle={this.ViewInstructionsModal}>
                        <span style={{color: '#6835FF'}}>{t("inbasket.instruction")}</span>
                    </ModalHeader>

                    <ModalBody>
                        {/*<div className="">
                            <h6>{t("inbasket.user.instruction")}</h6>
                        </div>*/}
                        <div translate="no"
                             dangerouslySetInnerHTML={{__html: instruction.templateInstruction}}>
                        </div>
                        <div className="text-center mt-3  ">
                            <Button className="next_outline_btn mob_next_btn" onClick={this.ViewInstructionsModal}>
                                {t("inbasket.close")}
                            </Button>
                        </div>
                        {/*<div className="text-right">*/}
                        {/*    <Button className="next_discard_cancel mr-3"*/}
                        {/*            onClick={this.ViewInstructionsModal}>{t("inbasket.userinboxtimer.submirexercise.modal.cancel")}</Button>*/}
                        {/*    <Button className="next_btn"*/}
                        {/*            onClick={this.ViewInstructionsModal}>{t("inbasket.userinboxtimer.submirexercise.modal.submit")}</Button>*/}
                        {/*</div>*/}
                    </ModalBody>

                </Modal>

            </div>
        );
    }
}

export default translate("translations")(InbasketWelcome);

