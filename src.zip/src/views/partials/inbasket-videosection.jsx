import React from "react";
import {translate} from "react-i18next";

import ReactPlayer from 'react-player'

class InbasketVideosection extends React.Component {


    constructor(props) {
        super(props);
        const {instruction} = this.props;

        this.state = {

            instruction: instruction

        };
        // this.redirectTool = redirectTool.bind(this);
    }

    // async componentDidMount() {
    //
    //    await this.redirectTool();
    // }
    render() {
        const {t, i18n} = this.props;
        const {instruction} = this.state;

        return (


            <div className="player-wrapper1">
                <ReactPlayer
                    url={instruction.instructionVideo}
                    className='react-player next_radious'
                    width='100%'
                    height="40vh"
                    pip={true}
                    playing={this.state.playing}
                    light={false}
                    controls
                    onPlay={() => this.setState({playing: false})}

                    fullscreen={"true"}
                    config={{transparent: true}}
                />
            </div>


        );
    }
}

export default translate("translations")(InbasketVideosection);

