import React from "react";
import {Card, CardBody, DropdownItem,} from "reactstrap";
import {translate} from "react-i18next";
import conf_prop from "../../properties/properties";
import {removeLocalStorage} from "../../service";
import _ from "lodash";
import InbasketFancyBox from "./inbasket-fancybox";

const route_path = conf_prop.get("route_path");

class InbasketUserInformationView extends React.Component {
    constructor(props) {
        super(props);
        const {pumId_ENCRYPTED, projectUserMapper, templateMaterial} = this.props;
        removeLocalStorage();

        // const userInfo = ApiUtils.getLocalStorage("userInfo");
        this.state = {
            isLoaded: false,
            projectUserMapper: projectUserMapper,
            templateMaterial: templateMaterial
        };

        // this.findUserByUserId = this.findUserByUserId.bind(this);

    }


    componentDidMount() {
        removeLocalStorage();


    }


    render() {
        const {t, i18n} = this.props;
        const {projectUserMapper, templateMaterial} = this.state;
        // console.log(templateMaterial)

        return (
            <div>
                <Card className="bordered_card">
                    <CardBody>
                        {/*<div className="next_card_title text-center"><b>Information</b></div><hr />*/}
                        {!_.isEmpty(projectUserMapper.project.clientTemplateMapper.template) && (

                            <div>
                                {/*<span className="lstick"></span>*/}
                                {templateMaterial.map((curTemplateMaterial, index) => (


                                    <DropdownItem key={index} tag="button" action
                                                  className="justify-content-between"
                                                  onClick={() => this.setMaterial(curTemplateMaterial)}>
                                        <InbasketFancyBox templateMaterial={curTemplateMaterial}/>
                                    </DropdownItem>
                                ))}

                            </div>


                        )}
                    </CardBody>
                </Card>
            </div>
        );
    }
}

export default (translate("translations")(InbasketUserInformationView));
