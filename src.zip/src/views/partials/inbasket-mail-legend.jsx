import React from 'react';
import {Link} from 'react-router-dom';
import {Card, CardBody} from "reactstrap";
import {translate} from "react-i18next";
import conf_prop from "../../properties/properties";
import {findProjectUserContentReadCountByPumId} from "../../service/pum-content-count";


const route_path = conf_prop.get("route_path");

class InbasketMailLegend extends React.Component {
    constructor(props) {
        super(props);

        const {pumId_ENCRYPTED} = this.props
        this.state = {

            pumId_ENCRYPTED: pumId_ENCRYPTED,

            pumContentReadCount: 0,

            sentCount: 0,

            draftCount: 0

        };
        this.findProjectUserContentReadCountByPumId = findProjectUserContentReadCountByPumId.bind(this);
    }

    async componentDidMount() {

        await this.findProjectUserContentReadCountByPumId();
    }

    render() {
        const {t, i18n} = this.props;
        return (
            <div>

                <Link to={`${route_path}/user/compose/${this.state.pumId_ENCRYPTED}`}
                      className="btn btn-lg btn-block compose-btn mb-3" style={{fontSize: '14px', width: '90%'}}><i
                    className="mr-3 mdi mdi-pencil"></i>{t("inbasket.compose")}</Link>
                <Card className="mb-3 bordered_card" style={{width: '90%'}}>
                    <CardBody className="p-0">

                        <div className="feed-widget">
                            <ul className="list-style-none feed-body">
                                <a className="feed-item" style={{cursor: 'pointer'}}
                                   href={`${route_path}/user/inbox/${this.state.pumId_ENCRYPTED}`}>
                                <span className="feed-icon text-white"
                                      style={{backgroundColor: '#63B8FF', fontSize: '21px'}}>
                                    <i className="mdi mdi-email-outline"></i></span>
                                    {t("inbasket.inbox")} <span className="content-count"
                                                                style={{backgroundColor: '#63b8ffa3'}}>{this.state.pumContentReadCount}</span>
                                </a>
                                <a className="feed-item" style={{cursor: 'pointer'}}
                                   href={`${route_path}/user/draft/${this.state.pumId_ENCRYPTED}`}>
                                    <span className="feed-icon text-white"
                                          style={{backgroundColor: '#F2C94C', fontSize: '21px'}}><i
                                        className="mdi mdi-inbox"></i></span>
                                    {t("inbasket.draft")} <span className="content-count"
                                                                style={{backgroundColor: '#f2c94cad'}}>{this.state.draftCount}</span>
                                </a>
                                <a className="feed-item" style={{cursor: 'pointer'}}
                                   href={`${route_path}/user/sent/${this.state.pumId_ENCRYPTED}`}>
                                    <span className="feed-icon text-white"
                                          style={{backgroundColor: '#6FCF97', fontSize: '21px'}}><i
                                        className="mdi mdi-send"></i></span>
                                    {t("inbasket.sent")} <span className="content-count"
                                                               style={{backgroundColor: '#6fcf97b8'}}>{this.state.sentCount}</span>
                                </a>

                            </ul>
                        </div>
                    </CardBody>
                </Card>
            </div>
        )
    }

}

export default (translate("translations")(InbasketMailLegend))
