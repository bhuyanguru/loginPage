import _ from "lodash";
import React from 'react';
import {Badge, Modal, ModalBody, ModalHeader} from 'reactstrap';
import ApiUtils from "../../api/ApiUtils"
import {NotificationController} from "../../api/controller";
import conf_prop from "../../properties/properties";


const connectImg = 'https://cdn.thinktalentws48.click/nextv3/notification/new-connect-post.png';

class NotificationView extends React.Component {

    constructor(props) {
        super(props);
        const currentUCM = _.isEmpty(ApiUtils.getLocalStorage("userClientMapper")) ? {} : (ApiUtils.getLocalStorage("userClientMapper"));
        // console.log("currentUCM_notification", currentUCM);
        this.state = {
            currentUCM: currentUCM,
            page: 0,
            page_size: 20,
            isOpen: false,
            feedNotifications: [],
            taskNotifications: [],
            insertUserNotifications: [],
            count_notification: 0,
            insertReadTimeStamp: []
        };
        this.toggleModal = this.toggleModal.bind(this);
        this.findUnreadNotificationCountByUcm = this.findUnreadNotificationCountByUcm.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);


    }


    toggleModal() {
        this.setState({
            isOpen: !this.state.isOpen
        })
    }


    findUnreadNotificationCountByUcm() {

        NotificationController.findCountByUcm(this.state.currentUCM.ucmId_ENCRYPTED).then(
            result => {
                this.setState({
                    count_notification: result.count,
                })


            }).catch(error =>{

            console.warn(error)
            console.error(error)
        });


    }

    handleSubmit() {


        NotificationController.updateNotificationReadTimeStamp(this.state.currentUCM.ucmId_ENCRYPTED).then(
            result => {
                //
                this.setState({
                    isLoaded: true,
                    insertReadTimeStamp: result
                });

                this.findUnreadNotificationCountByUcm(true);
            }).catch(error => console.error(error));

    }

    componentDidMount() {
        this.findUnreadNotificationCountByUcm();

    }


    render() {


        return (
            <div>
                <div onClick={this.toggleModal}>
                    <i className=" mdi mdi-bell font-22" onClick={this.handleSubmit}></i>
                    {this.state.count_notification > 0 &&
                    <sup style={{left: "-7px"}}><Badge color="danger"
                                                       style={{borderRadius: "10px"}}>{this.state.count_notification === 0 ? ' ' : this.state.count_notification}</Badge></sup>

                    }
                </div>

                <Modal size="lg" style={{maxWidth: '1600px', width: '70%'}} isOpen={this.state.isOpen}
                       toggle={this.toggleModal} backdrop={false}>
                    <ModalHeader toggle={this.toggleModal}>
                        <i className=" mdi mdi-bell font-22"></i> Notifications {this.state.count_notification > 0 &&
                    <Badge
                        color="danger">{this.state.count_notification === 0 ? ' ' : this.state.count_notification}</Badge>}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


                    </ModalHeader>


                    <ModalBody>
                        <div className="pt-0 pl-0 pr-2 next_notification_scroll" style={{height: '437px'}}>


                            <iframe frameBorder="0" style={{height: "100%"}} width="100%"
                                    src={`${conf_prop.get("landingDomainUrl")}/notification/user-notification`}/>

                        </div>
                    </ModalBody>

                </Modal>
            </div>
        );
    }
}

export default NotificationView;
