import classNames from "classnames";
import update from "immutability-helper";
import _ from 'lodash';
import React from "react";
import {Redirect} from 'react-router-dom';
import Select from 'react-select';

import {Button, Card, CardBody, Col, Input, Modal, ModalBody, ModalHeader, Row} from "reactstrap";
import InbasketUserMailResponseUtil
    from "../../component/inbasket/inbasket-user/inheritance/inbasket-user-mail-response-util";

import {translate} from "react-i18next";
import conf_prop from "../../properties/properties";
import {findProjectUserByPumId} from "../../service";
import ReactSummernote from "react-summernote";
import {summernoteFullToolbar} from "../../component/utils/summer-note";
import Loader from "react-loader-spinner";
import SunEditor from "suneditor-react";
import 'suneditor/dist/css/suneditor.min.css';
import ButtonWithLoader from "../../component/utils/button-with-loader";
import ButtonOutLineWithLoader from "../../component/utils/button-outline-with-loader";
import {basicSunEditorOptions, basicSunEditorOptionsWithoutLink} from "../../config/suneditor-config";

const route_path = conf_prop.get("route_path");

class InbasketUserResponseReplyView extends InbasketUserMailResponseUtil {
    constructor(props) {
        super(props);
        // console.log(props);
        const {pumId_ENCRYPTED, responseAction} = this.props;

        const projectusermapperresponse = props.responseReply;

        const projectusermapperresponseMailerGroup = _.groupBy(projectusermapperresponse.projectUserResponseMailerMappers, function (x) {
            return x.relation;
        });


        //console.log(responseAction);


        this.state = {
            pumId: pumId_ENCRYPTED,
            pumId_ENCRYPTED: pumId_ENCRYPTED,
            theme: 'snow',
            isLoaded: false,
            template: {},
            buttonDisabled: true,
            sendButtonDisabled: true,
            draftButtonDisabled: true,
            templatemailers: [],
            projectusermapperresponseMailerGroup: projectusermapperresponseMailerGroup,
            ccMailers: this.getValidArray(projectusermapperresponseMailerGroup.CC),
            toMailers: this.getValidArray(projectusermapperresponseMailerGroup.TO),
            bccMailers: this.getValidArray(projectusermapperresponseMailerGroup.BCC),
            newResponse: {},
            mailermappers: [],
            discardModal: false,
            subject: "",
            showReply: false,
            writeTime: 0,
            readTime: 0,
            responseAction: responseAction,
            responseaction: responseAction,

            projectusermapperresponse: projectusermapperresponse
        };


        this.toggleReply = this.toggleReply.bind(this);
        this.findProjectUserByPumId = findProjectUserByPumId.bind(this);
        this.discardDraftModal = this.discardDraftModal.bind(this);
        this.getSunEditorInstance = this.getSunEditorInstance.bind(this);
        this.editorRef = React.createRef();
    }

    discardDraftModal() {

        this.setState({
            discardModal: !this.state.discardModal
        });
    }


    getValidArray(mailers) {
        if (!_.isEmpty(mailers)) {
            const templateMailers = mailers.map(x => {
                const templateMailer = x.templateMailer;

                templateMailer.label = `${templateMailer.mailerName} <${templateMailer.mailerEmail}>`;
                templateMailer.value = templateMailer.mailerId;
                return templateMailer;
            });
            // console.log(mailers);
            return templateMailers;
        } else {
            return [];
        }
        // return _.isEmpty(arr) ? [] : arr;
    }


    toggleReply(responseAction) {
        document.getElementById('responseReplyInputBox').scrollIntoView({
            behavior: 'smooth', block: 'end'
        });
        clearInterval(this.readTimeIntervalId);

        this.writeTimeIntervalId = setInterval(this.setWriteTime, 1000);

        let subjectPrefix = "";
        switch (responseAction) {
            case "REPLY":
                subjectPrefix = "Re";
                break;
            case "REPLY_ALL":
                subjectPrefix = "Re";
                break;
            case "FORWARD":
                subjectPrefix = "Fw";
                break;

        }
        if (responseAction === 'FORWARD') {

            const response = "<br>" + "-------------Forward Message------------" + this.state.projectusermapperresponse.response
            this.editorRef.current.setContents(response);
            this.setState({
                responseaction: responseAction,
                showReply: true,
                toMailers: [],
                ccMailers: [],
                bccMailers: [],
                newResponse: update(this.state.newResponse, {
                    subject: {$set: `${subjectPrefix}: ${this.state.projectusermapperresponse.subject}`},
                    response: {$set: `${response}`}
                })
            })
        } else if (responseAction === 'REPLY') {
            this.setState({
                responseaction: responseAction,
                showReply: true,
                ccMailers: [],
                toMailers: this.getValidArray(this.state.projectusermapperresponseMailerGroup.TO),
                bccMailers: [],

                newResponse: update(this.state.newResponse, {
                    subject: {$set: `${subjectPrefix}: ${this.state.projectusermapperresponse.subject}`},
                    response: {$set: null}
                })
            })
        } else if (responseAction === 'REPLY_ALL') {
            this.setState({
                responseaction: responseAction,
                showReply: true,
                ccMailers: this.getValidArray(this.state.projectusermapperresponseMailerGroup.CC),
                toMailers: this.getValidArray(this.state.projectusermapperresponseMailerGroup.TO),
                bccMailers: this.getValidArray(this.state.projectusermapperresponseMailerGroup.BCC),

                newResponse: update(this.state.newResponse, {
                    subject: {$set: `${subjectPrefix}: ${this.state.projectusermapperresponse.subject}`},
                    response: {$set: null}
                })
            })
        }


        // this.writeIntervalId = setInterval(this.setWriteTime, 1000);

    }

    // The sunEditor parameter will be set to the core suneditor instance when this function is called
    getSunEditorInstance (sunEditor)  {
        this.editorRef.current = sunEditor;
    }

    async componentDidMount() {
        await this.findProjectUserByPumId();
        this.templateMailerBytemplate();
        this.readTimeIntervalId = setInterval(this.setReadTime, 1000);

    }

    componentDidUpdate(prevProps: Readonly<P>, prevState: Readonly<S>, snapshot: SS): void {
        const responseAction = this.props.responseAction;
        // console.log(prevState.responseAction,responseAction);

        if (prevState.responseAction !== responseAction) {
            this.setState({
                responseAction: responseAction
            });
            // this.state.responseAction = responseAction;
            this.toggleReply(responseAction);

        }
    }

    componentWillMount() {
        clearInterval(this.readTimeIntervalId);
        clearInterval(this.writeTimeIntervalId);
    }


    render() {
        const {t, i18n} = this.props;
        if (this.state.sentRedirect) {
            return <Redirect to={`${route_path}/user/sent/${this.state.pumId_ENCRYPTED}`}/>
        } else if (this.state.draftRedirect) {
            return <Redirect to={`${route_path}/user/draft/${this.state.pumId_ENCRYPTED}`}/>
        }

        return (
            <div>
                {/* {this.state.writeTime} */}
                <Row className="">
                    <Col md={12}>
                        {' '}
                        <Button className="next_outline_btn mr-2 mob_next_btn"
                                onClick={() => this.toggleReply("REPLY")}><i
                            className="fas fa-reply mr-1"></i> {t("inbasket.reply")} </Button>
                        {' '} {' '} {' '} <Button className="next_outline_btn mr-2 mob_next_btn"
                                                  onClick={() => this.toggleReply("REPLY_ALL")}><i
                        className="fas fa-reply-all mr-1 "></i> {t("inbasket.replyall")}</Button>{' '}{' '}<Button
                        onClick={() => this.toggleReply("FORWARD")}
                        className="next_outline_btn mob_next_btn">{t("inbasket.forward")}<i
                        className="mdi mdi-forward ml-1"></i></Button>
                    </Col>
                </Row>

                <div className={classNames("p-3", {"d-none": !this.state.showReply})} id="responseReplyInputBox">
                    <Card className="bordered_card">
                        <CardBody>
                            <Row className="mb-1">
                                <Col md={1}>
                                    <div className="text-left">
                                        {this.state.responseaction === "REPLY" && <i className="fas fa-reply"></i>}
                                        {this.state.responseaction === "REPLY_ALL" &&
                                        <i className="fas fa-reply-all"></i>}
                                        {this.state.responseaction === "FORWARD" && <i className="mdi mdi-forward"></i>}
                                    </div>
                                </Col>

                                <Col md={10}></Col>
                                <Col md={1}>
                                    <div className="text-right user-discard-icon d-none" style={{cursor: 'pointer'}}>
                                        <i className="fas fa-trash-alt" title="Discard draft"
                                           onClick={this.discardDraftModal}></i></div>
                                </Col>

                            </Row>
                            <Row>
                                <Col className="text-right compose-text" md={1}>
                                    <label className="mt-2">{t("inbasket.composemail.to")}</label>
                                </Col>
                                <Col md={10}>
                                    <Select
                                        placeholder={t("inbasket.select.placeholder")}
                                        value={this.state.toMailers}
                                        isMulti
                                        name="mailerName"
                                        options={this.state.templatemailers}
                                        className="basic-multi-select"
                                        classNamePrefix="next_select"
                                        onChange={(templatemailers) => this.onToMailerchange(templatemailers, "TO")}
                                    />
                                </Col>
                            </Row>
                            <Row className="mt-3">
                                <Col className="text-right compose-text" md={1}>
                                    <label className="mt-2">{t("inbasket.composemail.cc")}</label>
                                </Col>
                                <Col md={10}>
                                    <Select
                                        placeholder={t("inbasket.select.placeholder")}
                                        value={this.state.ccMailers}
                                        isMulti
                                        name="colors"
                                        options={this.state.templatemailers}
                                        className="basic-multi-select"
                                        classNamePrefix="next_select"
                                        onChange={(templatemailers) => this.onCcMailerchange(templatemailers, "CC")}
                                    />
                                </Col>
                            </Row>
                            <Row className="mt-3">
                                <Col className="text-right compose-text" md={1}>
                                    <label className="mt-2">{t("inbasket.composemail.bcc")}</label>
                                </Col>
                                <Col md={10}>
                                    <Select
                                        placeholder={t("inbasket.select.placeholder")}
                                        value={this.state.bccMailers}
                                        isMulti
                                        name="colors"
                                        options={this.state.templatemailers}
                                        className="basic-multi-select"
                                        classNamePrefix="next_select"
                                        onChange={(templatemailers) => this.onBccMailerchange(templatemailers, "BCC")}
                                    />
                                </Col>
                            </Row>
                            <Row className="mt-3">
                                <Col className="text-right compose-text" md={1}>
                                    <label className="mt-2">{t("inbasket.composemail.subject")}</label>
                                </Col>
                                <Col md={10}>
                                    <Input type="text" className="input-text-next" name="subject"
                                           value={this.state.newResponse.subject}
                                           onChange={this.onSubjectChange}></Input>
                                </Col>
                            </Row>
                            <Row className="mt-3">
                                <Col md={1}>

                                </Col>
                                <Col md={10} className={"comment_summernote"}>
                                    <SunEditor
                                       // defaultValue={this.state.newResponse.response}
                                        setContents={this.state.newResponse.response}
                                        // hideToolbar={true}
                                        setOptions={{
                                            mode: 'classic',
                                            height: "200px",
                                            resizingBar: true,
                                            showPathLabel: false,
                                            "buttonList": [basicSunEditorOptionsWithoutLink]
                                        }}
                                        getSunEditorInstance={this.getSunEditorInstance}
                                        onChange={this.onUpdateResponseTextChange}
                                        onCopy={this.handleCopy}
                                        onPaste={this.handlePaste}
                                        // onBlur={(event, editorContents) => this.onNoteBlur(event, editorContents, statement)}
                                        setDefaultStyle="font-family: Poppins , sans-serif; font-size: 14px;"
                                    />

                                </Col>
                            </Row>
                            <Row className="mt-5 ">
                                <Col md={1}></Col>
                                <Col md={10}>



                                    <ButtonWithLoader loading={!this.state.sendButtonDisabled} disabled={!this.state.sendButtonDisabled}
                                                      onClick={() => this.onSaveResponse("sent", "SENT", this.state.responseAction)}
                                                      text={t("inbasket.mailsend")}/> {''}

                                    <ButtonOutLineWithLoader loading={!this.state.draftButtonDisabled} disabled={!this.state.draftButtonDisabled}
                                                             onClick={() => this.onSaveResponse("sent", "DRAFT", this.state.responseAction)}
                                                             text={t("inbasket.maildraft")}/>

                                </Col>
                            </Row>


                            <Modal
                                isOpen={this.state.discardModal}
                                toggle={this.discardDraftModal}
                                backdrop={true}
                                // className="discard-draft-modal"
                                size="md"
                            >
                                <ModalHeader toggle={this.discardDraftModal}>
                                    <b>{t("inbasket.maildiscard.conformbox.title")}</b>
                                </ModalHeader>
                                <ModalBody>
                                    <div className="text-center p-5">
                                        <h6>{t("inbasket.maildiscard.conformbox.msg")}
                                        </h6>
                                    </div>
                                    <Row>
                                        <Col md={5}></Col>
                                        <Col md={7} className="text-right">
                                            <Button className="next_cancel_btn next_btn_lg mr-2"
                                                    onClick={this.discardDraftModal}>{t("inbasket.maildiscard.conformbox.cancel")}</Button>
                                            <Button className="next_accent2_btn next_btn_lg"
                                                    onClick={() => this.onDiscardChange("SENT")}>
                                                {t("inbasket.maildiscard.conformbox.confirm")}
                                            </Button>
                                        </Col>
                                    </Row>


                                </ModalBody>

                            </Modal>
                        </CardBody>
                    </Card>
                </div>
            </div>
        );
    }
}

export default (translate("translations")(InbasketUserResponseReplyView));
