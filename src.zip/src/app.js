import React from 'react';
import indexRoutes from './routes/index';
import {Router, Switch} from "react-router-dom";
import {Provider} from "react-redux";
import {configureStore} from "./redux/store";
import {history} from './jwt/_helpers';
import {PrivateRoute} from './routes/PrivateRoutes';
import {ReactNotifications} from 'react-notifications-component';
import LoadingOverlay from 'react-loading-overlay';
import {translate} from "react-i18next";

class App extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            currentUser: null,
            online: navigator.onLine
        };
        this.onOffline = this.onOffline.bind(this)
    }

    onOffline() {
        window.scrollTo(0, 0);
    }

    componentDidMount() {
        window.addEventListener('online', () =>

            this.setState({online: true}));
        window.addEventListener('offline', () =>

            this.setState({

                online: false
            }));
    }


    render() {


        const index_routes = indexRoutes;
        const {t, i18n} = this.props;
        return (
            <div>
                <ReactNotifications/>
                <LoadingOverlay onClick={this.onOffline}
                                active={!this.state.online}
                                spinner

                                text={<div>
                                    <div>{t(`inbasket.user.no.internet`)}</div>
                                    <div>{t(`inbasket.user.offline`)} </div>
                                </div>}
                >
                    <Provider store={configureStore()}>
                        <Router basename="/user" onUpdate={() => window.userpilot.reload()} history={history}>
                            <Switch>
                                {/*<Route path="/login/user-keycloak" component={Blanklayout}/>;*/}
                                {/* <Route path="/user/authorized" component={Blanklayout} />; */}
                                {index_routes.map((prop, key) => {
                                    return <PrivateRoute path={prop.path} key={key} component={prop.component}/>;
                                })
                                }
                            </Switch>
                        </Router>
                    </Provider>
                </LoadingOverlay>
            </div>
        )
    }
}

export default translate("translations")(App);
