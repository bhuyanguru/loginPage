import React from 'react'
import conf_prop from "../../../properties/properties";
import * as faceapi from "face-api.js";
import {translate} from "react-i18next";
import "./proctor.css";
import * as PropTypes from "prop-types";
import {WebcamController} from "../../../api/controller";
import _ from "lodash";
import {InbasketProjectUserMapperController} from "../../../api/inbasket";
import InbasketPumBrowserTrackController from "../../../api/inbasket/inbasket-pumbrowsertrack-controller";
import AESEncryption from "../../../properties/encryption";

const route_path = conf_prop.get("route_path");


class WebcamProctor extends React.Component {

    constructor(props) {

        super(props);
        const pumId_ENCRYPTED = props.file_id;
        const pumId = parseInt(AESEncryption.decrypt(pumId_ENCRYPTED));
        const url = this.props.url;
        const folder_path = conf_prop.get("proctor_path");
        this.state = {
            pumId_ENCRYPTED: pumId_ENCRYPTED, pumId: pumId, url: url, proctoringData: {}, folder_path: folder_path
        };


        this.startVideo = this.startVideo.bind(this);
        this.createImage = this.createImage.bind(this);
        this.imageSendToS3 = this.imageSendToS3.bind(this);
        this.initProctoring = this.initProctoring.bind(this);
        this.startBrowserTrack = this.startBrowserTrack.bind(this);
        this.insertPumBrowserTrack = this.insertPumBrowserTrack.bind(this);


    }

    startVideo() {
        const video = this.video;
        navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;

        navigator.getUserMedia({video: {}}, stream => video.srcObject = stream, err => console.error(err))
    }

    imageSendToS3(image_data) {
        WebcamController.insertProctorImage(image_data).then(result => {

        }).catch(error => console.error(error))
    }

    createImage(video, imageCanvas, faceCount) {
        var ctx = imageCanvas.getContext('2d').drawImage(video, 0, 0, imageCanvas.width, imageCanvas.height);
        var dataURL = imageCanvas.toDataURL('image/png');

        const image_data = {
            base64_img: dataURL,
            file_name: this.state.pumId_ENCRYPTED,
            folder_path: this.state.folder_path,
            content_type: "image/png",
            faceCount: faceCount
        };

        this.imageSendToS3(image_data)
    }


    initProctoring() {
        this.video = document.getElementById('proctor-webcam');
        this.imageCanvas = document.getElementById('proctor-image');
        const video = this.video;
        const imageCanvas = this.imageCanvas;

        const model_path = `${conf_prop.get("cdn_path")}/models`;
// const model_path = `${route_path}/models`;
        Promise.all([faceapi.nets.tinyFaceDetector.loadFromUri(model_path), faceapi.nets.faceLandmark68Net.loadFromUri(model_path), faceapi.nets.faceRecognitionNet.loadFromUri(model_path), faceapi.nets.faceExpressionNet.loadFromUri(model_path)]).then(this.startVideo);


        video.addEventListener('play', () => {
            const canvas = faceapi.createCanvasFromMedia(video);
            document.getElementById('proctor-section').append(canvas);
            const displaySize = {width: video.width, height: video.height};
            faceapi.matchDimensions(canvas, displaySize);
            this.interval = setInterval(async () => {
                const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceExpressions();
                const randomTime = _.random(1, 60);
                console.info("randomTime", randomTime);
                setTimeout(async () => {
                    const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceExpressions();
                    // console.log(detections.length);

                    const faceCount = detections.length;
                    this.createImage(video, imageCanvas, faceCount);

                }, 1000 * randomTime);


                const resizedDetections = faceapi.resizeResults(detections, displaySize);
                // console.log(resizedDetections);
                canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height)
                faceapi.draw.drawDetections(canvas, resizedDetections)
                faceapi.draw.drawFaceLandmarks(canvas, resizedDetections);
                faceapi.draw.drawFaceExpressions(canvas, resizedDetections)
            }, 1000 * 30)
        });

        /*this.imageInterval = setInterval(() => {
            /!* const randomTime = _.random(1, 30);
             setTimeout(() => {
                 this.createImage(video, imageCanvas);
             }, 1000 * randomTime);*!/

        }, 1000 * 60 * 2)*/
    }

    insertPumBrowserTrack(action) {
        const pumBrowserTrack = {projectUserMapper: {pumId: this.state.pumId}, genDate: new Date(), action: action}
        InbasketPumBrowserTrackController.insertPumBrowserTrack(pumBrowserTrack).then(result => {
            console.log(result);
        }).catch(error => console.error(error));
    }

    startBrowserTrack() {
        window.addEventListener('blur', () => this.insertPumBrowserTrack("BLUR_OUT"));
        window.addEventListener('focus', () => this.insertPumBrowserTrack("FOCUS_IN"));

        /*$(document).ready(function () {
            $(window).bind("blur", function () {
                console.log(new Date(), "BLUR_OUT");
                ;
            });
            $(window).bind("focus", function () {
                console.log(new Date(), "FOCUS_IN");
                this.insertPumBrowserTrack("FOCUS_IN");
            });
        });*/
    }

    componentDidMount() {
        InbasketProjectUserMapperController.getIntegrationProctoring(this.props.file_id).then(proctoringData => {
            this.setState({
                proctoringData: proctoringData
            })
            if (proctoringData.proctoringStatus === "Y") {
                this.initProctoring();
                this.startBrowserTrack();
            }
        }).catch(error => console.error(error));

    }

    componentWillUnmount() {
        clearInterval(this.interval);
        // clearInterval(this.imageInterval);
        window.removeEventListener('blur', this.insertPumBrowserTrack);
        window.removeEventListener('focus', this.insertPumBrowserTrack);
    }


    render() {

        const {t, i18n} = this.props;


        const {url} = this.state;

        return (

            <div id="proctor-section" className="text-center" style={{visibility: "hidden", height: "0px"}}>

                <video id="proctor-webcam" width="720" height="560" autoPlay muted/>
                <canvas className={"d-none"} width="720" height="560" id="proctor-image"/>
            </div>)
    }

}

export default translate("translations")(WebcamProctor);

WebcamProctor.propTypes = {
    file_id: PropTypes.string, folder_path: PropTypes.string,
};

