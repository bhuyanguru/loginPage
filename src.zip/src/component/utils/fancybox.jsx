import '@fancyapps/fancybox/dist/jquery.fancybox';
import $ from 'jquery';
import React from 'react';
import '@fancyapps/fancybox/dist/jquery.fancybox.min.css';
import PropTypes from 'prop-types';

export default class FancyBox extends React.Component {
    constructor(props) {
        super(props);


    }


    componentDidMount() {


        $("[data-fancybox]").fancybox({
            buttons: ['slideshow',
                'zoom',
                'fullscreen',
                'close'],
            thumb: {
                autostart: true
            },
            keyboard: false,
            arrow: false,
            protect: true,

            modal: false,
        });

    }


    render() {

        const {url, mimeType, name} = this.props;
        return (
            <div>

                {mimeType.includes("image") && (
                    <a href={url}
                       data-fancybox="images" data-caption={name}>
                        <div className="feed-icon bg-light-secondary"><i
                            className="mr-2 mdi mdi-file-multiple"/>{name}</div>
                    </a>
                )}

                {mimeType.includes("vimeo") && (
                    <a data-fancybox href={url} data-caption={name}>
                        <div className="feed-icon bg-light-secondary"><i
                            className="mr-2 mdi mdi-file-multiple"/>{name}</div>
                    </a>
                )}

                {mimeType.includes("youtube") && (
                    <a data-fancybox href={url} data-caption={name}>
                        <div className="feed-icon bg-light-secondary"><i
                            className="mr-2 mdi mdi-file-multiple"/>{name}</div>
                    </a>
                )}

                {mimeType.includes("pdf") && (
                    <div>

                        <a data-fancybox data-type="iframe" data-src={url}

                        >
                            {name}
                        </a>
                        {/* <a data-fancybox data-src={`#pdf-material-${name.replace(".", "-")}`}>
                            <div className="feed-icon bg-light-secondary"><i
                                className="mr-2 mdi mdi-file-multiple"/>{name}
                            </div>
                        </a>
                        <div style={{display: "none"}} id={`pdf-material-${name.replace(".", "-")}`}>
                            <PDFReader url={url}/>

                        </div>*/}
                    </div>
                )}

                {mimeType.includes("html") && (
                    <div>

                        <a data-fancybox data-src={`#html-content-${name.replace(".", "-")}`}>
                            <div className="feed-icon bg-light-secondary"><i
                                className="mr-2 icon-eye"/>View
                            </div>
                        </a>
                        <div style={{display: "none"}} id={`html-content-${name.replace(".", "-")}`}>
                            <div dangerouslySetInnerHTML={{__html: url}}/>

                        </div>
                    </div>
                )}


            </div>

        )
    }


}

FancyBox.propTypes = {
    name: PropTypes.string,
    url: PropTypes.string,
    mimeType: PropTypes.string

};



