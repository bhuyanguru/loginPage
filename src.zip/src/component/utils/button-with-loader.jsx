import React from "react";
import {Button} from "reactstrap";
import Loader from "react-loader-spinner";
import {translate} from "react-i18next";
import PropTypes from 'prop-types';

class ButtonWithLoader extends React.Component {
    constructor(props) {
        super(props);


        this.state = {}
    }

    render() {
        const {loading, text} = this.props;
        if (loading) {
            return (

                <Button type="button" className={`next_btn ${this.props.className}`} disabled>
                    <div className="next_btn_with_loader">

                        <Loader type="Oval" color="#ffffff" height={20} width={20}/>

                        <div className="btnWithLoader">
                            <span> {text} </span>
                        </div>

                    </div>
                </Button>

            )
        } else {
            return (
                <Button type="button" disabled={this.props.disabled} className={`next_btn ${this.props.className}`} onClick={this.props.onClick}>
                    <span> {text} </span>
                </Button>
            )
        }


    }


}

ButtonWithLoader.propTypes = {
    loading: PropTypes.bool.isRequired,
    disabled: PropTypes.bool,
    text: PropTypes.string.isRequired,
    onClick: PropTypes.func.isRequired,
};


export default translate("translations")(ButtonWithLoader);