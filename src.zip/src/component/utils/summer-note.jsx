import React, {Component} from 'react';
import ReactSummernote from 'react-summernote';
// import './../../../node_modules/react-summernote/dist/react-summernote.css'; // import styles
import 'react-summernote/dist/react-summernote.css'
// Import bootstrap(v3 or v4) dependencies
import 'bootstrap/js/dist/modal';
import 'bootstrap/js/dist/dropdown';
import 'bootstrap/js/dist/tooltip';
// import 'bootstrap/dist/css/bootstrap.css';
import update from 'immutability-helper';

export const summernoteToolbar = [];
export const summernoteFullToolbar = [
    // ['style', ['style']],
    ['font', ['bold', 'italic', 'underline']],
    // ['fontname', ['fontname']],
    ['para', ['ul', 'ol', 'paragraph']],
    // ['table', ['table']],
    // ['insert', ['link', 'picture', 'video']],
    // ['view', ['fullscreen', 'codeview']]
];



class SummerNote extends Component {

    constructor(props) {
        super(props);


    }

    onChange(content) {
        this.props.setState({
            [this.props.updateState]: update([this.props.updateState], {[this.props.name]: {$set: content}})
        });

    }


    render() {
        return (
            <ReactSummernote


                value={this.props.placeholder}
                name={this.props.name}
                options={{
                    lang: 'en-EN',
                    height: 70,
                    dialogsInBody: true,
                    popover: {
                        image: [],
                        link: [],
                        air: []
                    },
                    toolbar: [
                        // ['style', ['style']],
                        ['font', ['bold', 'italic', 'underline']],
                        // ['fontname', ['fontname']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        // ['table', ['table']],
                        // ['insert', ['link', 'picture', 'video']],
                        // ['view', ['fullscreen', 'codeview']]
                    ]
                }}
                onChange={this.onChange}

            />

        );
    }
}

export default SummerNote;
