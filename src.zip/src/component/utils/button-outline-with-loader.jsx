import React from "react";
import { Button } from "reactstrap";
import Loader from "react-loader-spinner";
import { translate } from "react-i18next";
import PropTypes from 'prop-types';

class ButtonOutLineWithLoader extends React.Component {
    constructor(props) {
        super(props);


        this.state = {}
    }

    render() {
        const { loading, text } = this.props;
        if (loading) {
            return (

                <Button type="button" className={`next_outline_btn ${ this.props.className }`} disabled>
                    <div className="next_btn_with_loader">

                        <Loader type="Oval" color="#6835FF" height={20} width={20} />

                        <div  className="btnWithLoader" >
                            <span > {text} </span>
                        </div>

                    </div>
                </Button>

            )
        } else {
            return (
                <Button disabled={this.props.disabled} type="button" className={`next_outline_btn ${ this.props.className }`} onClick={this.props.onClick}>
                    <span > {text} </span>
                </Button>
            )
        }


    }


}
ButtonOutLineWithLoader.propTypes = {
    loading: PropTypes.bool.isRequired,
    disabled: PropTypes.bool,
    text: PropTypes.string.isRequired,
    onClick: PropTypes.func.isRequired

}


export default translate("translations")(ButtonOutLineWithLoader);