export {default as WebcamProctor} from "./proctor/webcam-proctor";


export {default as FancyBox} from './fancybox';
