import React from 'react';
import ReactPlayer from "react-player";

export default class ReactVideoPlayer extends React.Component {

    constructor(props) {
        super(props);
        const mediaElement = props.mediaElement;
        const userCourseElementMapper = props.userCourseElementMapper;
        this.state = {
            userCourseElementMapper: userCourseElementMapper,
            mediaElement: mediaElement,
            url: mediaElement.mediaContent,
            playerstate: {},
            playing: false,
            ended: false,
            duration: 0,
            courseElements: [],
            courseElement: {}
        };

        this.player = null;
        this.load = this.load.bind(this);
        this.handleProgress = this.handleProgress.bind(this);
        this.handleEnded = this.handleEnded.bind(this);
        this.handleDuration = this.handleDuration.bind(this);
        this.handlePlay = this.handlePlay.bind(this);
        this.handleStop = this.handleStop.bind(this);
        this.onSeekDuartion = this.onSeekDuartion.bind(this);
    }

    handleProgress(playerstate) {
        // console.log('onProgress', playerstate);
        // We only want to update time slider if we are not currently seeking
        if (!this.state.seeking) {
            this.setState({
                playerstate: playerstate
            });
            this.props.storeMediaElementBackUp(playerstate);
        }
    }

    handleEnded() {
        // console.log('onEnded');
        this.setState({ended: true})
    }

    handleDuration(duration) {
        // console.log('onDuration', duration);
        this.setState({duration})
    }


    // handleClickFullscreen(){
    //     screenfull.request(findDOMNode(this.player))
    // }

    load(url) {
        this.setState({
            url: url,
            ended: false

        })
    }

    ref = player => {
        this.player = player
    };


    onSeekDuartion(backupTime) {
        // console.log('onSeekDuartion');
        setTimeout(() => {
            this.player.seekTo(backupTime, "seconds");
            this.handlePlay();
        }, 5000)


    }


    handlePlay() {
        // console.log('onPlay');
        this.setState({playing: !this.state.playing})
    }

    handleStop() {
        this.setState({url: null, playing: false})
    }


    componentDidMount() {
        this.load(this.props.mediaElement.mediaContent);
        const userCourseElementMapper = this.state.userCourseElementMapper;
        if (userCourseElementMapper.mediaElementBackUp !== 0) {
            this.onSeekDuartion(userCourseElementMapper.mediaElementBackUp);
        }
    }


    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.mediaElement.mediaId !== this.props.mediaElement.mediaId) {
            const mediaElement = this.props.mediaElement;
            const userCourseElementMapper = this.props.userCourseElementMapper;
            this.setState({
                mediaElement: mediaElement,
                userCourseElementMapper: userCourseElementMapper
            });


            this.handleStop();
            this.load(this.props.mediaElement.mediaContent);
            if (userCourseElementMapper.mediaElementBackUp !== 0) {
                this.onSeekDuartion(userCourseElementMapper.mediaElementBackUp);
            }
        }
    }


    render() {
        return (
            <div>
                {/* <div className="text-center">
                    <LoaderSpinner isLoaded={this.state.isLoaded}></LoaderSpinner>
                </div>
            <div className={classNames({ "d-none": !this.state.isLoaded })}> */}
                <ReactPlayer
                    url={this.state.url}
                    ref={this.ref}
                    className='react-player'
                    width='100%'
                    height='400px'
                    pip={true}
                    playing={this.state.playing}
                    light={false}
                    controls
                    onPlay={() => this.setState({playing: false})}
                    onEnded={this.handleEnded}
                    onError={e => console.log('onError', e)}
                    onProgress={this.handleProgress}
                    onDuration={this.handleDuration}
                    fullscreen={"true"}
                    config={{transparent: true}}
                />
                {/* </div> */}
            </div>
        )

    }
}



