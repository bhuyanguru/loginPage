import _ from 'lodash';
import React from "react";
import InbasketProjectUserMapperResponseController
    from '../../../../api/inbasket/inbasket-projectusermapperresponse-controller';

export default class InbasketUserMailUtil extends React.Component {
    constructor(props) {

        super(props);

        this.findUserResponse = this.findUserResponse.bind(this);
    }

    async findUserResponse(responseType) {

        await InbasketProjectUserMapperResponseController.getProjectUserMapperResponse(this.state.pumId_ENCRYPTED, responseType)
            .then(
                projectusermapperresponses => {

                    const projectusermapperresponseRelationGroups = projectusermapperresponses.map(projectusermapperresponse => {
                        const relationGroup = _.groupBy(projectusermapperresponse.projectUserResponseMailerMappers, function (response) {
                            return response.relation;
                        });
                        projectusermapperresponse.relationGroup = relationGroup;
                        return projectusermapperresponse;
                    });



                    this.setState({
                        isLoaded: true,
                        submitExercise:_.isEmpty(projectusermapperresponses) ? true : false,
                        projectusermapperresponses: projectusermapperresponses,
                        projectusermapperresponseRelationGroups: projectusermapperresponseRelationGroups

                    });
                }).catch(error => {
                    this.setState({
                        isLoaded: true,
                        error: error
                    });
                    console.error(error);
                });
    }
}
