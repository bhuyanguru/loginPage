import update from 'immutability-helper';
import _ from 'lodash';
import React from "react";
import {toastify} from "../../../utils/toastify";
import InbasketProjectUserMapperResponseController
    from '../../../../api/inbasket/inbasket-projectusermapperresponse-controller';
import InbasketTemplateMailerController from '../../../../api/inbasket/inbasket-templatemailer-controller';

export default class InbasketUserMailResponseUtil extends React.Component {

    constructor(props) {
        super(props);
        this.onToMailerchange = this.onToMailerchange.bind(this);
        this.onCcMailerchange = this.onCcMailerchange.bind(this);
        this.onBccMailerchange = this.onBccMailerchange.bind(this);
        this.onUpdateResponseTextChange = this.onUpdateResponseTextChange.bind(this);
        this.onSaveResponse = this.onSaveResponse.bind(this);
        this.setWriteTime = this.setWriteTime.bind(this);
        this.setReadTime = this.setReadTime.bind(this);
        this.onDiscardChange = this.onDiscardChange.bind(this);
        this.onSubjectChange = this.onSubjectChange.bind(this);
        this.templateMailerBytemplate = this.templateMailerBytemplate.bind(this);

    }

    async templateMailerBytemplate() {


        await InbasketTemplateMailerController.getTemplateMail(this.state.template.templateId_ENCRYPTED)
            .then(
                result => {

                    const templatemailers = result.map(x => {
                        x.label = `${x.mailerName}<${x.mailerEmail}>`;
                        x.value = x.mailerId;
                        return x
                    });

                    this.setState({
                        templatemailers: templatemailers
                    });



                }).catch(error => {
                    this.setState({
                        isLoaded: true,
                        error: error
                    });
                    console.error(error);
                });


    }

    onToMailerchange(templatemailers, relation) {


        this.setState({toMailers: templatemailers})


    }

    onCcMailerchange(templatemailers, relation) {


        this.setState({ccMailers: templatemailers})

    }

    onBccMailerchange(templatemailers, relation) {


        this.setState({bccMailers: templatemailers})

    }


    onSubjectChange(e) {
        this.setState({
            newResponse: update(this.state.newResponse, {[e.target.name]: {$set: e.target.value}})
        });
        // console.log(this.state.newResponse);
    }

    onUpdateResponseTextChange(content) {

        this.setState({
            newResponse: update(this.state.newResponse, {"response": {$set: content}})
        });
        // console.log(this.state.newResponse);
    }

    async onDiscardChange(type) {
        const {t, i18n} = this.props;
        // let result = await confirm({
        //     title: (
        //         <p>
        //             {t("inbasket.maildiscard.conformbox.title")}
        //         </p>
        //     ),
        //     message: t("inbasket.maildiscard.conformbox.msg"),
        //     confirmText: t("inbasket.maildiscard.conformbox.confirm"),
        //     confirmColor: "info",
        //     cancelColor: "danger",
        //     cancelText: t("inbasket.maildiscard.conformbox.cancel")
        // });
        // if(result) {
            if(type==="SENT"){
                this.setState({sentRedirect: true});
            }else if(type==="DRAFT"){
                this.setState({draftRedirect: true});
            }else if(type==="INBOX"){
                this.setState({inboxRedirect: true});
            }
            // this.setState({inboxRedirect: true});
            toastify("error", t("inbasket.alert.discard.message"), t("inbasket.alert.discard.message"));
        this.setState({
            discardModal: !this.state.discardModal
        });
        // }


    }

    onSaveResponse(mailtype,responseType, responseAction) {
        if(responseType != "DRAFT"){
            this.setState({

                sendButtonDisabled: false,


            })
        }else{
            this.setState({


                draftButtonDisabled: false,

            })
        }

        const {t, i18n} = this.props;
        if (_.isEmpty(this.state.toMailers) && responseType != "DRAFT") {
            this.setState({sendButtonDisabled: true})
            toastify("error", t("inbasket.alert.atleastone.recipient.message"), t("inbasket.alert.atleastone.recipient.message"));


        } else {

            const toMailers = _.isEmpty(this.state.toMailers) ? [] : this.state.toMailers.map(templateMailer => {

                return {
                    templateMailer: templateMailer,
                    relation: "TO"
                }


            });
            const ccMailers = _.isEmpty(this.state.ccMailers) ? [] : this.state.ccMailers.map(templateMailer => {

                return {
                    templateMailer: templateMailer,
                    relation: "CC"
                }


            });
            const bccMailers = _.isEmpty(this.state.bccMailers) ? [] : this.state.bccMailers.map(templateMailer => {

                return {
                    templateMailer: templateMailer,
                    relation: "BCC"
                }


            });


            // console.log(_.isUndefined(this.state.projectusermapperDraftresponse) ? null : this.state.projectusermapperDraftresponse.pumrId)
            const newResponse = {
                projectUserResponseMailerMappers: _.concat(toMailers, ccMailers, bccMailers),
                pumrId: _.isUndefined(this.state.projectusermapperDraftresponse) ? null : this.state.projectusermapperDraftresponse.pumrId,
                projectUserMapper: {pumId: this.state.decryptedPumId},
                readTime: this.state.readTime,
                writeTime: this.state.writeTime,
                responseAction: responseAction, responseType: responseType,
                subject: this.state.newResponse.subject,
                response: this.state.newResponse.response,
                templateContent: _.isUndefined(this.state.templateContentId) ? null : {templateContentId: this.state.templateContentId}
            };

            if (_.isEmpty(this.state.newResponse.subject) || _.size(this.state.newResponse.response) === 0 || this.state.newResponse.response == '<p><br></p>') {
                const {t, i18n} = this.props;

                if(responseType != "DRAFT"){
                    this.setState({sendButtonDisabled: true})
                }else{
                    this.setState({draftButtonDisabled: true})
                }

                toastify("error", t("inbasket.alert.subandres.notempty.message"), t("inbasket.alert.subandres.notempty.message"));
            } else {

               /* console.log(newResponse)*/

                InbasketProjectUserMapperResponseController.insertProjectUserMapperResponse(newResponse).then(
                    result => {

                        if (newResponse.responseType === 'SENT') {


                            toastify("success", t("inbasket.alert.sent.message"), t("inbasket.alert.sent.message"));
                        } else if (newResponse.responseType === 'DRAFT') {

                            toastify("success", t("inbasket.alert.draftsaved.message"), t("inbasket.alert.draftsaved.message"));

                        }else{

                        }

                        if(mailtype === "inbox"){
                            this.setState({inboxRedirect: true})
                        }else if(mailtype === "sent"){
                            this.setState({sentRedirect: true})
                        }if(mailtype === "draft"){
                            this.setState({draftRedirect: true})
                        }

                    }).catch(error => {
                    console.error(error)
                    if (error.name === 'TypeError' && error.message === 'Failed to fetch') {
                        toastify("error", t("inbasket.user.error.msg.network.fail"), t("inbasket.user.error.msg.network.fail"));

                    } else if (error.message === 'Access Denied') {
                        toastify("error", t("inbasket.user.error.msg.403"), t("inbasket.user.error.msg.403"));

                    }

                });
            }

            // console.log(newResponse)
        }

        //
    }

    setWriteTime() {

        this.setState({
            writeTime: this.state.writeTime + 1
        })

    }

    setReadTime() {

        this.setState({
            readTime: this.state.readTime + 1
        })

    }


}
