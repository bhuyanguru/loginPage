import React from "react";
import {translate} from "react-i18next";

class ErrorBoundary401 extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        const {t, i18n} = this.props;
        return (
            <div className={'ErrorBoundary401_body'}>
                <div className="ErrorBoundary401_container">

                    <div className='ErrorBoundary401_hover'>
                        <div className='ErrorBoundary401_background'>
                            <div className='ErrorBoundary401_door'>{t("inbasket.errorboundary401.text")}
                            </div>
                            <div className='ErrorBoundary401_rug'></div>
                        </div>
                        <div className='ErrorBoundary401_foreground'>
                            <div className='ErrorBoundary401_bouncer'>
                                <div className='ErrorBoundary401_head'>
                                    <div className='ErrorBoundary401_neck'></div>
                                    <div className='ErrorBoundary401_eye ErrorBoundary401_eye_left'></div>
                                    <div className='ErrorBoundary401_eye ErrorBoundary401_eye_right'></div>
                                    <div className='ErrorBoundary401_ear'></div>
                                </div>
                                <div className='ErrorBoundary401_body'></div>
                                <div className='ErrorBoundary401_arm'></div>
                            </div>
                            <div className='ErrorBoundary401_poles'>
                                <div className='ErrorBoundary401_pole ErrorBoundary401_left'></div>
                                <div className='ErrorBoundary401_pole ErrorBoundary401_right'></div>
                                <div className='ErrorBoundary401_rope'></div>
                            </div>
                        </div>
                    </div>


                </div>

            </div>

        );
    }

}

export default translate("translations")(ErrorBoundary401);