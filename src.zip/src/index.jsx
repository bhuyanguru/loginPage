import 'react-app-polyfill/ie9';
import 'react-app-polyfill/stable';
import "core-js/stable";
import "regenerator-runtime/runtime";
import React, {Suspense} from 'react';
import ReactDOM from 'react-dom';

import './assets/scss/style.scss';
import "./assets/dist/css/style.min.css";
import {I18nextProvider} from "react-i18next";
import i18n from "./i18n";
import $ from 'jquery';
import SuspenseLoaderSpinner from "./views/loader/suspense-loader-spinner";
import ErrorBoundary from "./ErrorBoundary";
import {DevSupport} from "@react-buddy/ide-toolbox";
import {ComponentPreviews, useInitial} from "./dev";
// setup fake backend
// import App from "./app";

window.jQuery = $;

// configureFakeBackend();

// sentryInit();

const App = require('./app').default;

ReactDOM.render(
    <Suspense fallback={<SuspenseLoaderSpinner/>}>
        <I18nextProvider i18n={i18n}>
            <ErrorBoundary>
                <DevSupport ComponentPreviews={ComponentPreviews}
                            useInitialHook={useInitial}
                >
                    <App/>
                </DevSupport>
            </ErrorBoundary>
        </I18nextProvider>
    </Suspense>, document.getElementById('root')
);
