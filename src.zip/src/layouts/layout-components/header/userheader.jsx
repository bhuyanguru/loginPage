import React from 'react';
import {connect} from 'react-redux';
import _ from "lodash";
import confirm from "reactstrap-confirm";
import classNames from "classnames";
import {
    Collapse,
    DropdownItem,
    DropdownMenu,
    DropdownToggle,
    Nav,
    Navbar,
    NavbarBrand,
    NavItem,
    NavLink,
    UncontrolledDropdown
} from 'reactstrap';
import userphoto from '../../../assets/images/icons/user.png';
/*--------------------------------------------------------------------------------*/
/* Import images which are need for the HEADER                                    */
/*--------------------------------------------------------------------------------*/
// import logodarkicon from '../../../assets/images/logo-icon.png';
import ApiUtils from "../../../api/ApiUtils";
import conf_prop from "../../../properties/properties";
import {logo} from "../../../js/properties";
import {translate} from "react-i18next";
import {mapDispatchToProps} from "../../../redux/redux-util";
import UserInfoController from "../../../api/controller/userinfo-controller";
import {findMasterAccessList} from "../../../service";
// import {NotificationView} from "../../../views/parsials";
import * as Sentry from "@sentry/react";

import NotificationView from '../../../views/partials/notification';

const route_path = conf_prop.get("route_path");
const mapStateToProps = state => ({
    ...state
});

class UserHeader extends React.Component {
    constructor(props) {
        super(props);
        this.toggle = this.toggle.bind(this);
        this.searchtoggle = this.searchtoggle.bind(this);
        this.showMobilemenu = this.showMobilemenu.bind(this);
        this.sidebarHandler = this.sidebarHandler.bind(this);
        this.handleSwitchAccount = this.handleSwitchAccount.bind(this);
        this.updateLastUcm = this.updateLastUcm.bind(this);
        this.countDown = this.countDown.bind(this);
        this.findMasterAccessList = findMasterAccessList.bind(this);


        const userInfo = _.isNull(ApiUtils.getLocalStorage("userInfo")) ? {name: ""} : ApiUtils.getLocalStorage("userInfo");
        let userClientMapper = _.isNull(ApiUtils.getLocalStorage("userClientMapper")) ? {
            name: "", client: {name: ""}
        } : ApiUtils.getLocalStorage("userClientMapper");
        userClientMapper.label = userClientMapper.client.name;
        userClientMapper.value = userClientMapper.ucmId;
        const userClientMappers = _.isEmpty(userInfo.userClientMappers) ? [] : userInfo.userClientMappers.map(userClientMapper => {
            userClientMapper.label = userClientMapper.client.name;
            userClientMapper.value = userClientMapper.ucmId;
            return userClientMapper;
        });
        // console.log("userClientMappers", userClientMappers)

        const clientLogo = _.isEmpty(userClientMapper) ? logo : `${conf_prop.get("nextServiceUrl")}/rest/client/logo/${userClientMapper.client.clientId_ENCRYPTED}`;
        const userNotificatoionHideFlag = _.isEmpty(userClientMapper.client.clientAccesses.map(x => x.masterAccessList).find(x => x.accessKey === "USER_NOTIFICATION"))
        this.state = {
            isOpen: false,
            collapse: false,
            userInfo: userInfo,
            userClientMappers: userClientMappers,
            switchAccountModal: false,
            userClientMapper: userClientMapper,
            clientLogo: clientLogo,
            userNotificatoionHideFlag: userNotificatoionHideFlag
        };
    }

    /*--------------------------------------------------------------------------------*/
    /*To open NAVBAR in MOBILE VIEW                                                   */

    /*--------------------------------------------------------------------------------*/
    async updateLastUcm(ucmId_ENCRYPTED) {
        await UserInfoController.updateLastUcmId(ucmId_ENCRYPTED).then(result => {
            this.setState(prevState => ({
                isLoaded: true
            }));

        }).catch(error => console.error(error));
    }

    toggle() {
        this.setState({
            isOpen: !this.state.isOpen
        });
    }

    searchtoggle() {
        this.setState({
            collapse: !this.state.collapse
        })
    }


    async handleSwitchAccount(userClientMapper) {
        // console.log("userClientMapper", userClientMapper);
        // console.log("ucmId_ENCRYPTED", userClientMapper.ucmId_ENCRYPTED);
        await this.findMasterAccessList(userClientMapper.ucmId_ENCRYPTED);
        await this.updateLastUcm(userClientMapper.ucmId_ENCRYPTED);

        ApiUtils.setLocalStorage("userClientMapper", userClientMapper);
        this.setState({"userClientMapper": userClientMapper});

        window.location.reload()

    }


    /*--------------------------------------------------------------------------------*/
    /*To open SIDEBAR-MENU in MOBILE VIEW                                             */

    /*--------------------------------------------------------------------------------*/
    showMobilemenu() {
        document.getElementById('main-wrapper').classList.toggle('show-sidebar');
    }

    sidebarHandler() {
        let element = document.getElementById('main-wrapper');
        switch (this.props.settings.activeSidebarType) {
            case 'full':
            case 'iconbar':
                element.classList.toggle('mini-sidebar');
                if (element.classList.contains('mini-sidebar')) {
                    element.setAttribute('data-sidebartype', 'mini-sidebar');
                } else {
                    element.setAttribute('data-sidebartype', this.props.settings.activeSidebarType);
                }
                break;

            case 'overlay':
            case 'mini-sidebar':
                element.classList.toggle('full');
                if (element.classList.contains('full')) {
                    element.setAttribute('data-sidebartype', 'full');
                } else {
                    element.setAttribute('data-sidebartype', this.props.settings.activeSidebarType);
                }
                break;
            default:
        }
    };

    async countDown() {
        const {t, i18n} = this.props;
        const idleTime = localStorage.getItem("idleTime") - conf_prop.get("idleCountDown");
        localStorage.setItem("idleTime", idleTime);
        this.setState({
            endtime: idleTime
        });
        if (idleTime <= conf_prop.get("idleCountDown")) {
            const flag = await confirm({
                title: (<>
                    {t(`header.session.alert.header`)}
                </>),
                message: t(`header.session.alert.message`),
                confirmText: t(`header.session.alert.confirm.button`),
                cancelText: t(`header.session.alert.cancel.button`),
                confirmColor: "primary",
                cancelColor: "link text-danger"
            });
            if (flag) {
                window.location.reload();
            } else {
                window.location = `${conf_prop.get("oauthServiceUrl")}/logout`;
            }


        }
        if (idleTime < 1) {
            window.location = `${conf_prop.get("oauthServiceUrl")}/logout`;
        }


    }

    componentDidMount() {
        const {userInfo, userClientMapper} = this.state;
        Sentry.setUser({email: userInfo.email, id: userInfo.userId});
        this.idletimer = setInterval(this.countDown, conf_prop.get("idleCountDown") * 1000);


        if (!_.isEmpty(userClientMapper) && !_.isEmpty(userClientMapper.client.siteTitle)) {
            document.title = userClientMapper.client.siteTitle;
        }

        if (_.isArray(conf_prop.get("embedJavascript"))) {
            conf_prop.get("embedJavascript").forEach(x => {

                if (!_.isEmpty(x.innerHTML)) {
                    const script = document.createElement("script");
                    script.innerHTML = x.innerHTML;
                    document.body.appendChild(script);
                } else if (!_.isEmpty(x.src)) {
                    const script = document.createElement("script");
                    script.src = x.src;
                    // script.defer = true;
                    script.async = true;
                    document.body.appendChild(script);
                }


            });
        }


    }

    componentWillUnmount() {
        clearInterval(this.idletimer);
    }

    render() {

        const {t, i18n} = this.props;
        const {clientLogo, userNotificatoionHideFlag} = this.state;

        return (<header className="topbar navbarbg" data-navbarbg={this.props.settings.activeNavbarBg}>
                <Navbar
                    className={"top-navbar " + (this.props.settings.activeNavbarBg === "skin6" ? 'navbar-light' : 'navbar-dark')}
                    expand="md">
                    <div className="navbar-header" id="logobg" data-logobg={this.props.settings.activeLogoBg}>
                        {/*--------------------------------------------------------------------------------*/}
                        {/* Mobile View Toggler  [visible only after 768px screen]                         */}
                        {/*--------------------------------------------------------------------------------*/}
                        <span className="nav-toggler d-block d-md-none" onClick={this.showMobilemenu}>
							<i className="ti-menu ti-close"/>
						</span>
                        {/*--------------------------------------------------------------------------------*/}
                        {/* Logos Or Icon will be goes here for Light Layout && Dark Layout                */}
                        {/*--------------------------------------------------------------------------------*/}
                        <NavbarBrand>
                            <b className="logo-icon ieonly">
                                <img src={`${conf_prop.get("serviceUrl")}/next-service/rest/client/favicon.ico`}
                                     alt="homepage" className="dark-logo small-logo"/>
                                <img
                                    src={clientLogo}
                                    alt="homepage"
                                    className="light-logo"
                                />
                            </b>
                            <span className="logo-text ml-3">
								<img src={clientLogo} alt="homepage" className="dark-logo img-fluid"/>
								<img
                                    src={clientLogo}
                                    className="light-logo"
                                    alt="homepage"
                                />
							</span>
                        </NavbarBrand>
                        {/*--------------------------------------------------------------------------------*/}
                        {/* Mobile View Toggler  [visible only after 768px screen]                         */}
                        {/*--------------------------------------------------------------------------------*/}
                        <span className="topbartoggler d-block d-md-none" onClick={this.toggle}>
							<i className="ti-more"/>
						</span>
                    </div>
                    <Collapse className="navbarbg" isOpen={this.state.isOpen} navbar
                              data-navbarbg={this.props.settings.activeNavbarBg}>
                        <Nav className="float-left" navbar>
                            <NavItem>
                                <NavLink href="#" className="d-none d-md-block" onClick={this.sidebarHandler}>
                                    <i className="ti-menu"/>
                                </NavLink>
                            </NavItem>
                        </Nav>
                        <Nav className="ml-auto float-right" navbar>

                            <UncontrolledDropdown nav inNavbar
                                                  className={classNames({"d-none": userNotificatoionHideFlag})}>
                                <DropdownToggle nav caret>
                                    <NotificationView></NotificationView>
                                </DropdownToggle>
                            </UncontrolledDropdown>

                            <UncontrolledDropdown nav inNavbar>

                                <DropdownToggle nav caret className="pro-pic">
                                    <img
                                        // src={this.state.userInfo.photo}
                                        src={userphoto}
                                        alt="user"
                                        className="rounded-circle"
                                        width="31"
                                        height="31"
                                    />
                                </DropdownToggle>
                                <DropdownMenu right className="user-dd">
                                    <div className="d-flex no-block align-items-center p-3 bg-info text-white mb-2">
                                        <div className="">
                                            <img
                                                // src={this.state.userInfo.photo}
                                                src={userphoto}
                                                alt="user"
                                                className="rounded-circle next_header_profile_img"
                                                width="60"
                                                height="60"
                                            />
                                        </div>
                                        <div className="ml-2">
                                            <h4 className="mb-0 text-white">{this.state.userInfo.name}</h4>
                                            <p className=" mb-0">{this.state.userInfo.email}</p>
                                        </div>
                                    </div>
                                    {/* {!_.isEmpty(this.state.userInfo.clientAdmins) &&

                                    <DropdownItem tag="a" href={`/client-admin/login/user-keycloak`}>
                                        <i className="fa fa-user mr-1 ml-1"/> Client Admin Account

                                    </DropdownItem>
                                    }


                                    <DropdownItem divider/> */}


                                    <DropdownItem tag="a" href={`${conf_prop.get("oauthServiceUrl")}/logout`}>
                                        <i className="fa fa-power-off mr-1 ml-1"/> {t("user.logout")}

                                    </DropdownItem>

                                </DropdownMenu>
                            </UncontrolledDropdown>
                            {/*--------------------------------------------------------------------------------*/}
                            {/* End Profile Dropdown                                                           */}
                            {/*--------------------------------------------------------------------------------*/}
                        </Nav>
                    </Collapse>
                </Navbar>


            </header>


        );
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(translate("translations", {useSuspense: false})(UserHeader));
