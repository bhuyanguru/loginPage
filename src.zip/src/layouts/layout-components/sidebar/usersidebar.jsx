import React from 'react';
import {connect} from 'react-redux';
import {Nav, UncontrolledCollapse} from 'reactstrap';
import PerfectScrollbar from 'react-perfect-scrollbar';
import ApiUtils from "../../../api/ApiUtils";
// import profile from '../../../assets/images/users/avatar-person.svg';
import {translate} from "react-i18next";
import {getNavigationList} from "./navigation-service"

const mapStateToProps = state => ({
    ...state
});

class UserSidebar extends React.Component {

    constructor(props) {
        super(props);
        this.expandLogo = this.expandLogo.bind(this);
        this.toggle = this.toggle.bind(this);
        this.activeRoute.bind(this);

        const userClientMapper = ApiUtils.getLocalStorage("userClientMapper");
        this.state = {
            collapse: false,
            routes: [],
            userClientMapper: userClientMapper
        };

        this.getNavigationList = getNavigationList.bind(this);
        this.executeNavigationEvent = this.executeNavigationEvent.bind(this);
    }

    /*--------------------------------------------------------------------------------*/
    /*To Expand SITE_LOGO With Sidebar-Menu on Hover                                  */

    /*--------------------------------------------------------------------------------*/
    expandLogo() {
        document.getElementById("logobg").classList.toggle("expand-logo");
    }

    toggle() {
        this.setState(state => ({collapse: !state.collapse}));
    }

    /*--------------------------------------------------------------------------------*/
    /*Verifies if routeName is the one active (in browser input)                      */

    /*--------------------------------------------------------------------------------*/
    activeRoute(routeName) {
        return this.props.location.pathname.indexOf(routeName) > -1 ? 'selected' : '';
    }

    executeNavigationEvent(navigationEvent) {
        console.log(navigationEvent);
        Function(navigationEvent)()
    }

    async componentDidMount() {
        await this.getNavigationList();
    }

    render() {
        return (
            <aside className="left-sidebar d-print-none" id="sidebarbg"
                   data-sidebarbg={this.props.settings.activeSidebarBg}
                   onMouseEnter={this.expandLogo} onMouseLeave={this.expandLogo}>
                <div className="scroll-sidebar">
                    <PerfectScrollbar className="sidebar-nav">
                        {/*--------------------------------------------------------------------------------*/}
                        {/* Sidebar Menus will go here                                                */}
                        {/*--------------------------------------------------------------------------------*/}
                        <Nav id="sidebarnav">

                            {this.state.routes.filter(x => x.sidebar).map((prop, key) => {
                                if (prop.redirect) {
                                    return null;
                                } else if (prop.navlabel) {
                                    return (
                                        <li className="nav-small-cap" key={key}>
                                            <i className={`${prop.icon} d-print-none`}></i>
                                            <span className="hide-menu">{prop.name}</span>
                                        </li>
                                    );
                                } else if (prop.collapse) {
                                    let firstdd = {};
                                    firstdd[prop["state"]] = !this.state[prop.state];
                                    return (
                                        /*--------------------------------------------------------------------------------*/
                                        /* Menus wiil be here                                                        */
                                        /*--------------------------------------------------------------------------------*/
                                        <li className={this.activeRoute(prop.path) + ' sidebar-item'} key={key}>

                                            <span className="sidebar-link has-arrow" id={`toggler_${key}`}>
												<i className={`${prop.icon} d-print-none`}/>
												<span className="hide-menu">{prop.name}
                                                    <span className={prop.badges}>{prop.badgeno}</span>
												</span>
											</span>
                                            <UncontrolledCollapse toggler={`toggler_${key}`}>
                                                <ul className="first-level">
                                                    {/*{JSON.stringify(prop.child)}*/}
                                                    {prop.child.filter(x => x.sidebar).map((prop, key) => {
                                                        if (prop.redirect) return null;
                                                        return (
                                                            <li className={this.activeRoute(prop.path) + ' sidebar-item'}
                                                                key={key}>
                                                                {prop.type === 'LINK' ? (
                                                                    <a href={prop.path}
                                                                       activeClassName="active"
                                                                       className="sidebar-link d-print-none">
                                                                        <i className={`${prop.icon} d-print-none`}/>
                                                                        <span
                                                                            className="hide-menu">{prop.name}</span>
                                                                    </a>
                                                                ) : (
                                                                    <a
                                                                        activeClassName="active"
                                                                        className="sidebar-link d-print-none"
                                                                        onClick={() => this.executeNavigationEvent(prop.event)}
                                                                    >
                                                                        <i className={`${prop.icon} d-print-none`}/>
                                                                        <span
                                                                            className="hide-menu">{prop.name}</span>
                                                                    </a>
                                                                )}

                                                            </li>
                                                        );
                                                    })}
                                                </ul>
                                            </UncontrolledCollapse>

                                            {/*--------------------------------------------------------------------------------*/}
                                            {/* Sub-Menus wiil be here                                                    */}
                                            {/*--------------------------------------------------------------------------------*/}

                                        </li>
                                    );
                                } else {
                                    return (
                                        /*--------------------------------------------------------------------------------*/
                                        /* Adding Sidebar Item                                                            */
                                        /*--------------------------------------------------------------------------------*/
                                        <li className={this.activeRoute(prop.path) + (prop.pro ? ' active active-pro' : '') + ' sidebar-item'}
                                            key={key}>


                                            {prop.type === 'LINK' ? (
                                                <a href={prop.path} className="sidebar-link" activeClassName="active">
                                                    <i className={`${prop.icon} d-print-none`}/>
                                                    <span className="hide-menu">{prop.name}</span>
                                                </a>
                                            ) : (

                                                <a className="sidebar-link" activeClassName="active"
                                                   onClick={() => this.executeNavigationEvent(prop.event)}
                                                >
                                                    <i className={`${prop.icon} d-print-none`}/>
                                                    <span className="hide-menu">{prop.name}</span>
                                                </a>
                                            )}
                                        </li>
                                    );
                                }
                            })}
                        </Nav>
                    </PerfectScrollbar>
                </div>
            </aside>
        );
    }
}

export default connect(mapStateToProps)(translate("translations", {useSuspense: false})(UserSidebar));
