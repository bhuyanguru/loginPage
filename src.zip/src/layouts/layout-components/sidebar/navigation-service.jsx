import {NavigationController} from "../../../api/controller";
import _ from "lodash";
import ApiUtils from "../../../api/ApiUtils";

export async function getNavigationListWithGroup() {
    const {t, i18n} = this.props;
    await NavigationController.findByUserClientMapper(this.state.userClientMapper.ucmId_ENCRYPTED).then(result => {
        const navigations = result.filter(x => x.userType === "USER");
        const navigationGroup = _.groupBy(_.sortBy(navigations, ['navigationOrder']), function (x) {
            return x.navigationGroup;
        });

        const routes = _.keys(navigationGroup).map(x => {
            const inner_routes = _.sortBy(navigationGroup[x], ['navigationOrder']).map(data => {
                return {
                    path: data.navigationPath,
                    name: t(data.navigationName),
                    icon: data.navigationIcon,
                    sidebar: true
                }
            });
            return {
                path: "#",
                name: t(x),
                icon: 'mdi mdi-account-circle',
                child: inner_routes,
                collapse: true,
                sidebar: true

            }
        });
        console.dir(navigations);
        this.setState({
            navigations: navigations,
            routes: routes
        })
    }).catch(error => console.error(error));
}

export async function getNavigationList() {
    const {t, i18n} = this.props;
    await NavigationController.findByUserClientMapper(this.state.userClientMapper.ucmId_ENCRYPTED).then(result => {
        const navigations = result.filter(x => x.userType === "USER");


        const routes = _.sortBy(navigations, ['navigationOrder']).map(navigation => {

            return {
                path: navigation.navigationPath,
                name: t(navigation.navigationName),
                icon: navigation.navigationIcon,
                type: navigation.navigationType,
                event: navigation.navigationEvent,
                sidebar: true

            }
        });
        console.dir(navigations);
        this.setState({
            navigations: navigations,
            routes: routes
        })
    }).catch(error => console.error(error));
}

export async function getClientNavigationList() {
    const {t, i18n} = this.props;
    const clientAdmin = ApiUtils.getLocalStorage("clientAdmin");
    await NavigationController.findByClientAdmin(this.state.clientAdmin.clientAdminId_ENCRYPTED).then(navigations => {


        const routes = _.sortBy(navigations, ['navigationOrder']).map(navigation => {

            return {
                ...navigation,
                path: navigation.navigationPath,
                name: t(navigation.navigationName),
                icon: navigation.navigationIcon,
                sidebar: !_.isEmpty(clientAdmin)

            }
        }).filter(x => x.sidebar)
        // console.dir(navigations);
        this.setState({
            navigations: navigations,
            routes: routes
        })
    }).catch(error => console.error(error));
}