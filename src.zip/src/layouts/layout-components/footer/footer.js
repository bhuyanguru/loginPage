import React from 'react';
import {translate} from "react-i18next";
import {Col, Row} from "reactstrap";

class Footer extends React.Component {

    constructor(props) {
        super(props);

        this.state = {


        };




    }



    componentDidMount() {


    }


    render() {
        const {t, i18n} = this.props;

        return (
            <footer className="footermain">

                <Row>



                    <Col md={12} className="text-center">
                        &copy; {new Date().getFullYear()} |
                        {/* eslint-disable-next-line react/jsx-no-target-blank */}
                        <a style={{color: "#212529"}} rel="noopener noreferrer" target="_blank"
                           href={t(`footer.site.link`)}> {t(`footer.site.name`)}</a>


                    </Col>



                </Row>


            </footer>
        );
    }
}

export default (translate("translations", {useSuspense: false})(Footer));

