import InbasketProjectUserMapperController from "../api/inbasket/inbasket-projectusermapper-controller";
import _ from "lodash";

export async function findProjectUserContentReadCountByPumId(){
    InbasketProjectUserMapperController.getPumContentReadCount(this.state.pumId_ENCRYPTED) .then(
        projectUserMapperContentReadCount => {

            //console.log(projectUserMapperContentReadCount)

            this.setState({

                pumContentReadCount: !_.isEmpty(projectUserMapperContentReadCount)? projectUserMapperContentReadCount[0].count:0,
                sentCount : !_.isEmpty(projectUserMapperContentReadCount)? projectUserMapperContentReadCount[0].sentCount:0,
                draftCount : !_.isEmpty(projectUserMapperContentReadCount)? projectUserMapperContentReadCount[0].draftCount:0,

            });

        }).catch(error => console.error(error));
}
