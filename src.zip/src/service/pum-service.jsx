import InbasketProjectUserMapperController from "../api/inbasket/inbasket-projectusermapper-controller";
import InbasketTemplateInstructionController from "../api/inbasket/inbasket-templateinstruction-controller";
import React from "react";
import conf_prop from "../properties/properties";

const route_path = conf_prop.get("route_path");

export async function findProjectUserByPumId() {

    await InbasketProjectUserMapperController.getProjectClient(this.state.pumId_ENCRYPTED)
        .then(
           async projectUserMapper => {

                // getTemplateInstruction(projectUserMapper.project.clientTemplateMapper.template.templateId_ENCRYPTED)

            await InbasketTemplateInstructionController.findByTemplate(projectUserMapper.project.clientTemplateMapper.template.templateId_ENCRYPTED)
                    .then(
                        templateInstruction => {
                            this.setState({


                                instruction: templateInstruction

                            });

                        }).catch(error => console.error(error));


                this.setState({

                    projectUserMapper: projectUserMapper,
                    template: projectUserMapper.project.clientTemplateMapper.template,
                    decryptedPumId: projectUserMapper.pumId,
                    pumId: projectUserMapper.pumId,
                    pumId_ENCRYPTED: projectUserMapper.pumId_ENCRYPTED,
                    // templateInstruction: templateInst
                });


            }).catch(error => {
            console.error(error)
           this.setState({
                isError: true
            });
        });


}


