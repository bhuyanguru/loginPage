import _ from "lodash";
import InbasketProjectUserMapperController from "../api/inbasket/inbasket-projectusermapper-controller";
import ApiUtils from "../api/ApiUtils";
import conf_prop from "../properties/properties";


export async function redirectTool() {
    const redirectJsonData = ApiUtils.getLocalStorage("redirectJsonData");

    await InbasketProjectUserMapperController.getIntegrationRedirect(this.state.pumId_ENCRYPTED).then(result => {
        let redirectData = result;
        let redirectUrl = result.redirectUrl;


        if (!_.isEmpty(redirectJsonData)) {
            redirectData.redirectUrl = redirectJsonData.redirectUrl;
            redirectData.integrationName = redirectJsonData.integrationName
        } else {
            if (!_.isEmpty(result)) {
                redirectData.redirectUrl = redirectUrl.includes('/vdc-user/') ? `${redirectUrl}?activestep=1` : redirectUrl;
                redirectData.integrationName = redirectData.integrationName


            } else {
                redirectData.itemName = "Task";
                redirectData.integrationName = "TASK";
                redirectData.redirectUrl = `${conf_prop.get("landingDomainUrl")}/user/task-list`;
            }

        }
        this.setState({

            redirectData: redirectData
        })


    }).catch(error => console.error(error));


}