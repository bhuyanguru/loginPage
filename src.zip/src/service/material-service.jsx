import {InbasketTemplateMaterialController} from "../api/inbasket";
import conf_prop from "../properties/properties";
import _ from "lodash";

export async function findTemplateMaterialByTempId() {
    await InbasketTemplateMaterialController.getTemplateMaterial(this.state.template.templateId_ENCRYPTED)
        .then(
            result => {
                // console.log(templateMaterials)

                const templateMaterials =  result.map(x => {
                    x.materialLink = conf_prop.get("inbasketServiceUrl") + "/rest/template-material/display/" + x.materialId_ENCRYPTED;
                    return x
                })

                this.setState({
                    isLoaded: true,
                    templateMaterials:_.orderBy(templateMaterials,"materialOrder"),
                    templateMaterial: _.first(_.orderBy(templateMaterials,"materialOrder"))

                });

            }).catch(error => {
                this.setState({
                    isLoaded: true,
                    error: error
                });
                console.error(error);
            });
}
