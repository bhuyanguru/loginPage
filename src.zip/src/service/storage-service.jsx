export function removeLocalStorage() {
    localStorage.removeItem("projectUserMapper");
    localStorage.removeItem("templatemailers");
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key.includes("timebackup")) {
            localStorage.removeItem(key);
        }
        if (key.includes("timeInstructionBackup")) {
            localStorage.removeItem(key);
        }
    }
}
