export function clearTimer(pumId_ENCRYPTED) {
    localStorage.removeItem(`timeInstructionBackup-${this.state.pumId_ENCRYPTED}`)
    localStorage.removeItem(`timebackup-${this.state.pumId_ENCRYPTED}`)
}