import {MasterAccessListController} from "../api/controller";
import ApiUtils from "../api/ApiUtils";


export async function findMasterAccessList(ucmId_ENCRYPTED) {
    await MasterAccessListController.findClientAccessByUcm(ucmId_ENCRYPTED).then(
        result => {
            const accessKeys = result.map(x => x.accessKey);
            ApiUtils.setLocalStorage("masterAccessList", accessKeys);

        }).catch(error => {
            console.error(error);
        });
}