import AppUtils from "../api/ApiUtils";
import {OauthController} from "../api/controller";
import conf_prop from "../properties/properties";


export function update_bearer_token() {
    // localStorage.setItem("idleTime", 15 * 60);
    const accessToken = AppUtils.getCookie("accessToken");
    // console.log(accessToken);
    OauthController.update_token({bearer_token: accessToken}).then(result => {
        AppUtils.setCookie("accessToken", result.bearer_token);
        localStorage.setItem("idleTime", conf_prop.get("idleTime"));
    }).catch(error => console.error(error));
}